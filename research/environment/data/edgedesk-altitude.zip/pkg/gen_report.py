"""Render the HTML report straight from model outputs (no hand-typed numbers)."""
import sys, json, html, pandas as pd

O, OUT = sys.argv[1], sys.argv[2]
r = json.load(open(f'{O}/results.json'))
M = {(m['model'], m['outcome']): m for m in r['models']}
W = r['wild']; cov = r['coverage']; boot = r['boot_cover']
dg = pd.read_csv(f'{O}/desc_grp.csv', index_col=0)
dgr = pd.read_csv(f'{O}/desc_grp_ratio6.csv')
pd_ = pd.read_csv(f'{O}/pbp_desc_grp.csv', index_col=0)
hosts = pd.read_csv(f'{O}/hosts_ge3000.csv').sort_values('elev', ascending=False)
loo = pd.DataFrame(r['loo'])

def c(model, outcome, term):
    m = M[(model, outcome)]; b, se = m['coefs'][term]; return b, se, m
def ci(b, se, k=1.0):
    return f'{b*k:+.2f} [{(b-1.96*se)*k:+.2f}, {(b+1.96*se)*k:+.2f}]'
def p(model, outcome, term):
    v = W.get(f'{model}|{outcome}|{term}'); return '' if v is None else f'{v:.2f}'
def pct(x): return f'{100*x:.1f}%'
esc = html.escape

# ---------- margin table ----------
margin_rows = [('v_margin', 'Full-game margin (pts)'), ('v_margin_1h', 'First-half margin (pts)'),
               ('v_margin_2h', 'Second-half margin (pts)'), ('v_margin_q4', 'Fourth-quarter margin (pts)'),
               ('v_ats', 'Margin vs closing spread (pts)')]
def margin_table():
    rows = []
    for o, lab in margin_rows:
        raw_b, raw_se, _ = c('raw', o, 'g2')
        b2, s2, m = c('FE+controls', o, 'g2'); b1, s1, _ = c('FE+controls', o, 'g1')
        h2, hs2, _ = c('FE+controls+hostHFA', o, 'g2')
        rows.append(f'<tr><th scope="row">{lab}</th><td class="num">{m["n"]:,}</td>'
                    f'<td class="num">{ci(raw_b, raw_se)}</td>'
                    f'<td class="num">{ci(b1, s1)}<span class="p">p={p("FE+controls", o, "g1")}</span></td>'
                    f'<td class="num strong">{ci(b2, s2)}<span class="p">p={p("FE+controls", o, "g2")}</span></td>'
                    f'<td class="num">{ci(h2, hs2)}</td></tr>')
    return '\n'.join(rows)

# ---------- unit outcomes table ----------
unit_rows = [('d3rate', '3rd-down conversion rate allowed', 100, 'pp'),
             ('d3rate_2h', '3rd-down rate allowed, 2nd half', 100, 'pp'),
             ('expl_rate_2h', 'Explosive plays allowed per play, 2nd half', 100, 'pp'),
             ('expl_2h', 'Explosive plays allowed, 2nd half (count)', 1, ''),
             ('plays_faced', 'Defensive plays faced (snap proxy)', 1, ''),
             ('pen', 'Accepted penalties committed (2014+)', 1, ''),
             ('pen_2h', 'Accepted penalties, 2nd half (2014+)', 1, ''),
             ('to_lost', 'Turnovers lost', 1, '')]
def unit_table():
    rows = []
    for o, lab, k, u in unit_rows:
        b1, s1, m = c('FE+controls', o, 'g1_v'); b2, s2, _ = c('FE+controls', o, 'g2_v'); b6, s6, _ = c('FE+controls+ratio6', o, 'r6_v')
        rows.append(f'<tr><th scope="row">{lab}</th><td class="num">{m["n"]//2:,}</td>'
                    f'<td class="num">{ci(b1, s1, k)}</td><td class="num strong">{ci(b2, s2, k)}</td>'
                    f'<td class="num">{ci(b6, s6, k)}</td></tr>')
    return '\n'.join(rows)

# ---------- forest plot (>=3000 and 1000-2999, FE+controls) ----------
fp = [('v_margin', 'Full game'), ('v_margin_1h', '1st half'), ('v_margin_2h', '2nd half'), ('v_margin_q4', '4th quarter'), ('v_ats', 'vs closing spread')]
def forest():
    W_, rowh, left, right = 640, 34, 150, 24
    H = 40 + rowh * len(fp) + 30
    lo, hi = -4.5, 2.0
    X = lambda v: left + (v - lo) / (hi - lo) * (W_ - left - right)
    s = [f'<svg viewBox="0 0 {W_} {H}" role="img" aria-label="Adjusted visitor margin effects with 95% intervals" class="forest">']
    for t in range(-4, 3):
        s.append(f'<line x1="{X(t):.1f}" x2="{X(t):.1f}" y1="28" y2="{H-26}" class="{"zero" if t == 0 else "grid"}"/>')
        s.append(f'<text x="{X(t):.1f}" y="{H-8}" class="tick" text-anchor="middle">{t:+d}</text>')
    s.append(f'<text x="{left}" y="16" class="axl">Points vs visitors with &lt;1,000 ft gain (negative = visitor worse)</text>')
    for i, (o, lab) in enumerate(fp):
        y = 44 + i * rowh
        s.append(f'<text x="{left-12}" y="{y+4}" text-anchor="end" class="lab">{lab}</text>')
        for term, dy, cls in [('g1', -6, 'mid'), ('g2', 6, 'high')]:
            b, se, _ = c('FE+controls', o, term)
            s.append(f'<line x1="{X(b-1.96*se):.1f}" x2="{X(b+1.96*se):.1f}" y1="{y+dy}" y2="{y+dy}" class="ci {cls}"/>')
            s.append(f'<circle cx="{X(b):.1f}" cy="{y+dy}" r="4.5" class="pt {cls}"/>')
    s.append('</svg>')
    return ''.join(s)

def desc_table():
    rows = []
    labs = {'<1000': 'Under 1,000 ft', '1000-2999': '1,000–2,999 ft', '>=3000': '3,000 ft or more'}
    cls = {'<1000': 'low', '1000-2999': 'mid', '>=3000': 'high'}
    for g_ in ['<1000', '1000-2999', '>=3000']:
        d = dg.loc[g_]; b = boot[g_]; q = pd_.loc[g_]
        rows.append(f'<tr><th scope="row"><span class="sw {cls[g_]}"></span>{labs[g_]}</th>'
                    f'<td class="num">{int(d.n):,}</td><td class="num">{d.v_margin:+.1f}</td><td class="num">{pct(d.v_win)}</td>'
                    f'<td class="num">{int(d.n_lines):,}</td><td class="num">{pct(b[0])} <span class="sub">[{pct(b[1])}, {pct(b[2])}]</span></td>'
                    f'<td class="num">{int(q.n):,}</td><td class="num">{q.m2h:+.1f}</td><td class="num">{q.mq4:+.1f}</td>'
                    f'<td class="num">{pct(q.vis_def_3rd_rate)}</td></tr>')
    return '\n'.join(rows)

def ratio_table():
    rows = []
    labs = {'<1000': 'Under 1,000 ft', '1000-2999': '1,000–2,999 ft', '>=3000': '3,000 ft or more'}
    for _, d in dgr.iterrows():
        rows.append(f'<tr><th scope="row">{labs[d.grp]}</th><td>{"Yes" if d.ratio6 else "No"}</td><td class="num">{int(d.n):,}</td>'
                    f'<td class="num">{d.v_margin:+.1f}</td><td class="num">{int(d.n_lines):,}</td>'
                    f'<td class="num">{pct(d.v_cover) if d.n_lines else "–"}</td></tr>')
    return '\n'.join(rows)

def host_table():
    rows = []
    for _, h in hosts.iterrows():
        cv = pct(h.cover) if h.n_lines else '–'
        rows.append(f'<tr><th scope="row">{esc(h.g_venue)}</th><td class="num">{h.elev:,.0f}</td><td class="num">{int(h.n)}</td>'
                    f'<td class="num">{h.v_margin:+.1f}</td><td class="num">{int(h.n_lines)}</td><td class="num">{cv}</td></tr>')
    return '\n'.join(rows)

g2 = c('FE+controls', 'v_margin', 'g2'); g2a = c('FE+controls_2001_2025', 'v_margin', 'g2')
g2h = c('FE+controls', 'v_margin_2h', 'g2'); g2q = c('FE+controls', 'v_margin_q4', 'g2'); g2ats = c('FE+controls', 'v_ats', 'g2')
r6m = c('FE+controls+ratio6', 'v_margin', 'r6'); r6only = c('FE+controls_ratio6_only', 'v_margin', 'r6')
lin2h = c('FE+controls_linear_gain', 'v_margin_2h', 'gain_k')
looM = loo[loo.outcome == 'v_margin'].b
raw_g2 = c('raw', 'v_margin', 'g2')
hfa = c('FE+controls', 'v_margin', 'intercept')
n_hosts = len(hosts)

subs = {
 'N_MAIN': f'{cov["games_main"]:,}', 'N_ALL': f'{cov["games_all"]:,}', 'N_PBP': f'{cov["pbp_games_main"]:,}', 'N_LINES': f'{cov["lines_main"]:,}',
 'N_HIGH': f'{int(dg.loc[">=3000"].n):,}', 'N_MID': f'{int(dg.loc["1000-2999"].n):,}', 'N_HOSTS': str(n_hosts),
 'G2_FULL': ci(g2[0], g2[1]), 'G2_FULL_P': p('FE+controls', 'v_margin', 'g2'),
 'G2_ALL': ci(g2a[0], g2a[1]), 'G2_2H': ci(g2h[0], g2h[1]), 'G2_Q4': ci(g2q[0], g2q[1]), 'G2_ATS': ci(g2ats[0], g2ats[1]),
 'G2_ATS_P': p('FE+controls', 'v_ats', 'g2'), 'RAW_G2': f'{raw_g2[0]:+.1f}',
 'COVER_HIGH': pct(boot['>=3000'][0]), 'COVER_HIGH_CI': f'{pct(boot[">=3000"][1])} to {pct(boot[">=3000"][2])}', 'COVER_HIGH_N': f'{boot[">=3000"][3]:,}',
 'COVER_LOW': pct(boot['<1000'][0]),
 'R6_M': ci(r6m[0], r6m[1]), 'R6_ONLY': ci(r6only[0], r6only[1]),
 'LIN2H': ci(lin2h[0], lin2h[1]), 'LOO_MIN': f'{looM.min():+.2f}', 'LOO_MAX': f'{looM.max():+.2f}',
 'HFA': f'{-hfa[0]:.2f}', 'R6_N': f'{int(dgr[dgr.ratio6].n.sum()):,}',
 'R6_LOW_N': f'{int(dgr[(dgr.grp=="<1000") & dgr.ratio6].n.iloc[0]):,}',
 'MARGIN_TABLE': margin_table(), 'UNIT_TABLE': unit_table(), 'FOREST': forest(), 'DESC_TABLE': desc_table(),
 'RATIO_TABLE': ratio_table(), 'HOST_TABLE': host_table(), 'PEN_N': f'{cov["pen_games_kept"]:,}',
}
tpl = open(sys.argv[3]).read()
for k, v in subs.items():
    tpl = tpl.replace('{{' + k + '}}', v)
assert '{{' not in tpl, tpl[tpl.index('{{'):tpl.index('{{') + 40]
open(OUT, 'w').write(tpl)
print('ok')
