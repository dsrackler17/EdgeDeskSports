"""Build the game-level analysis panel.

Sources (all public, via sportsdataverse / CollegeFootballData mirrors):
  schedules 2001-2021  : game results, venue_id, neutral flag, pregame Elo
  team_info 2001-2019  : venue elevation (m), lat/lon, capacity, dome, timezone
  ESPN PBP 2004-2025   : quarter scores and play-level metrics (agg_pbp.py)
  SBR odds archive     : spreads 2006-2019 (Pinnacle preferred, else median of books)
Elevation gaps are filled ONLY from venues.csv overrides that carry a cited source.
"""
import sys, numpy as np, pandas as pd

S = sys.argv[1]; D = S + '/dl'; OUT = sys.argv[2]; OVR = sys.argv[3]

# ---------- venues ----------
ti = pd.read_parquet(S + '/teaminfo_2001_2019.parquet')
ven = (ti.groupby('venue_id').agg(venue=('venue_name', 'last'), elev_ft=('elev_ft', 'median'),
        lat=('latitude', 'median'), lon=('longitude', 'median'), capacity=('capacity', 'median'),
        dome=('dome', 'last'), tz=('timezone', 'last')).reset_index())
ven['elev_src'] = 'CFBD venue table'
ovr = pd.read_csv(OVR)  # venue_id,venue,elev_ft,lat,lon,capacity,dome,tz,elev_src
ven = pd.concat([ven[~ven.venue_id.isin(ovr.venue_id)], ovr], ignore_index=True)

# ---------- FBS membership ----------
fbs = {y: set(ti[ti.season == y].team_id.astype(int)) for y in range(2001, 2020)}
alt20 = pd.read_parquet(D + '/ti/alt_2020.parquet')
fbs[2020] = set(alt20.team_id.astype(int)); fbs[2021] = fbs[2020]
for y in range(2022, 2026):
    fbs[y] = fbs[2021]  # teams joining FBS after 2021 excluded (no verified venue in this dataset)

# ---------- schedules 2001-2021 ----------
sch = pd.concat([pd.read_csv(f'{D}/sched/{y}.csv', low_memory=False) for y in range(2001, 2022)], ignore_index=True)
sch['date'] = pd.to_datetime(sch.start_date, utc=True).dt.tz_convert('America/Chicago').dt.date
sch['date'] = pd.to_datetime(sch.date)
for c in ['venue_id', 'home_id', 'away_id', 'home_points', 'away_points', 'home_pregame_elo', 'away_pregame_elo']:
    sch[c] = pd.to_numeric(sch[c], errors='coerce')
sch = sch.dropna(subset=['home_points', 'away_points'])

# rest: days since previous game for each team (any opponent)
long = pd.concat([sch[['game_id', 'season', 'date', 'home_id']].rename(columns={'home_id': 'team'}),
                  sch[['game_id', 'season', 'date', 'away_id']].rename(columns={'away_id': 'team'})])
long = long.sort_values(['team', 'date'])
long['prev'] = long.groupby(['team', 'season']).date.shift()
long['rest'] = (long.date - long.prev).dt.days
rest = long.set_index(['game_id', 'team']).rest

# team home venue per season = modal venue of its non-neutral home games
hv = (sch[(sch.neutral_site != True) & sch.venue_id.notna()].groupby(['season', 'home_id']).venue_id
      .agg(lambda s: s.mode().iloc[0]).rename('home_venue').reset_index().rename(columns={'home_id': 'team'}))

def attach(g):
    g = g.merge(ven.add_prefix('g_'), left_on='venue_id', right_on='g_venue_id', how='left')
    g = g.merge(hv.rename(columns={'team': 'away_id', 'home_venue': 'v_home_venue'}), on=['season', 'away_id'], how='left')
    g = g.merge(ven[['venue_id', 'elev_ft', 'lat', 'lon', 'tz']].add_prefix('vh_'), left_on='v_home_venue', right_on='vh_venue_id', how='left')
    return g

g = sch[sch.neutral_site != True].copy()
g = g[[a in fbs[s] and b in fbs[s] for a, b, s in zip(g.home_id, g.away_id, g.season)]]
g = attach(g)
g['home_rest'] = [rest.get((i, t), np.nan) for i, t in zip(g.game_id, g.home_id)]
g['away_rest'] = [rest.get((i, t), np.nan) for i, t in zip(g.game_id, g.away_id)]
g['sample'] = 'verified_venue_2001_2021'

# ---------- 2022-2025 from PBP (sensitivity; venue = home team's 2021 stadium) ----------
pbp = pd.read_parquet(S + '/pbp_games.parquet')
nn = pbp[(pbp.season >= 2022)].dropna(subset=['home_id', 'away_id', 'home_final', 'away_final']).copy()
nn['home_id'] = nn.home_id.astype(int); nn['away_id'] = nn.away_id.astype(int)
nn = nn[[a in fbs[s] and b in fbs[s] for a, b, s in zip(nn.home_id, nn.away_id, nn.season)]]
nn = nn[nn.seasonType.astype(str).isin(['2', 'regular', '2.0'])]  # regular season only (bowls are neutral)
# recurring neutral-site matchups: pairs played at a non-home venue in every meeting 2015-2021
rec = sch[sch.season >= 2015].assign(pair=lambda d: [tuple(sorted((a, b))) for a, b in zip(d.home_id, d.away_id)])
pn = rec.groupby('pair').neutral_site.agg(['mean', 'size'])
neutral_pairs = set(pn[(pn['mean'] == 1) & (pn['size'] >= 3)].index)
nn = nn[[tuple(sorted((a, b))) not in neutral_pairs for a, b in zip(nn.home_id, nn.away_id)]]
h21 = hv[hv.season == 2021][['team', 'home_venue']]
nn = nn.merge(h21.rename(columns={'team': 'home_id', 'home_venue': 'venue_id'}), on='home_id', how='left')
nn = nn.rename(columns={'home_final': 'home_points', 'away_final': 'away_points'})
nn = nn[['game_id', 'season', 'week', 'home_id', 'away_id', 'home_points', 'away_points', 'venue_id']]
nn['v_season'] = nn.season; nn['season'] = 2021
nn = attach(nn); nn['season'] = nn.v_season; nn = nn.drop(columns='v_season')
nn['sample'] = 'inferred_venue_2022_2025'
g = pd.concat([g, nn], ignore_index=True)

# ---------- treatment ----------
g = g.dropna(subset=['g_elev_ft', 'vh_elev_ft'])
g['gain_ft'] = g.g_elev_ft - g.vh_elev_ft
g['grp'] = pd.cut(g.gain_ft, [-np.inf, 1000, 3000, np.inf], right=False, labels=['<1000', '1000-2999', '>=3000'])
g['ratio6'] = g.g_elev_ft >= 6 * g.vh_elev_ft.clip(lower=1)
g['ratio'] = g.g_elev_ft / g.vh_elev_ft.clip(lower=1)

# ---------- controls ----------
R = 3958.8
la1, lo1, la2, lo2 = map(np.radians, [g.vh_lat, g.vh_lon, g.g_lat, g.g_lon])
a = np.sin((la2 - la1) / 2) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((lo2 - lo1) / 2) ** 2
g['travel_mi'] = 2 * R * np.arcsin(np.sqrt(a))
tzoff = {'America/New_York': -5, 'America/Detroit': -5, 'America/Indiana/Indianapolis': -5, 'America/Kentucky/Louisville': -5,
         'America/Chicago': -6, 'America/Denver': -7, 'America/Boise': -7, 'America/Phoenix': -7,
         'America/Los_Angeles': -8, 'Pacific/Honolulu': -10}
g['tz_cross'] = (g.g_tz.map(tzoff) - g.vh_tz.map(tzoff)).abs()
g['dome'] = g.g_dome.fillna(False).astype(bool)
g['log_cap'] = np.log(g.g_capacity)
g['rest_diff'] = (g.home_rest.clip(upper=21) - g.away_rest.clip(upper=21))
g['month'] = pd.to_datetime(g.start_date, errors='coerce').dt.month if 'start_date' in g else np.nan

# ---------- outcomes from PBP ----------
keep = ['game_id', 'n_plays', 'h_cum1', 'a_cum1', 'h_cum2', 'a_cum2', 'h_cum3', 'a_cum3', 'h_cum4', 'a_cum4',
        'h_pbp_final', 'a_pbp_final', 'home_final', 'away_final', 'pen_attr_offense_share', 'pen_total'] + \
       [c for c in pbp.columns if c.startswith(('vd_', 'hd_', 'v_', 'h_to', 'h_pen'))]
g = g.merge(pbp[keep], on='game_id', how='left')
g['pbp_ok'] = (g.h_cum4.notna() & (g.h_pbp_final == g.home_points) & (g.a_pbp_final == g.away_points)
               & (g.vd_plays >= 30) & (g.hd_plays >= 30))
g['v_margin'] = g.away_points - g.home_points
g['v_margin_2h'] = (g.a_pbp_final - g.a_cum2) - (g.h_pbp_final - g.h_cum2)
g['v_margin_q4'] = (g.a_cum4 - g.a_cum3) - (g.h_cum4 - g.h_cum3)
g['v_margin_1h'] = g.a_cum2 - g.h_cum2

# ---------- closing spreads (SBR archive) ----------
b = pd.read_parquet(D + '/bet/lines.parquet', columns=['game_id', 'season', 'abbr', 'lines', 'book', 'market_type', 'game_desc', 'date_time'])
b = b[(b.market_type == 'spread') & b.lines.notna()].copy()
noid = b[b.game_id.isna()].copy(); b = b[b.game_id.notna()].copy(); b['game_id'] = b.game_id.astype('int64')
# abbr -> team id by maximal overlap with schedule participants, per season
part = pd.concat([sch[['game_id', 'season', 'home_id']].rename(columns={'home_id': 'tid'}),
                  sch[['game_id', 'season', 'away_id']].rename(columns={'away_id': 'tid'})])
ab = b[['game_id', 'season', 'abbr']].drop_duplicates().merge(part, on=['game_id', 'season'])
cnt = ab.groupby(['season', 'abbr', 'tid']).size().rename('n').reset_index()
tot = ab[['game_id', 'season', 'abbr']].drop_duplicates().groupby(['season', 'abbr']).size().rename('N')
cnt = cnt.merge(tot, on=['season', 'abbr']).sort_values('n').groupby(['season', 'abbr']).tail(1)
cnt = cnt[cnt.n >= 0.9 * cnt.N]
# recover archive rows lacking a game_id: match "Away@Home" names to the schedule within +/-1 day
# (difflib similarity on school names), then identify the home row by the abbreviation map
import difflib
ALIAS = {'brigham young': 'byu', 'miami (fl)': 'miami', 'miami (oh)': 'miami (oh)', 'louisiana-lafayette': 'louisiana',
         'ul-lafayette': 'louisiana', 'louisiana-monroe': 'louisiana monroe', 'southern miss': 'southern mississippi',
         'texas christian': 'tcu', 'southern methodist': 'smu', 'central florida': 'ucf', 'hawaii': "hawai'i",
         'nevada-las vegas': 'unlv', 'texas-el paso': 'utep', 'texas-san antonio': 'ut san antonio', 'utsa': 'ut san antonio',
         'north carolina state': 'nc state', 'massachusetts': 'umass', 'san jose state': 'san josé state'}
norm = lambda x: ALIAS.get(str(x).lower().strip(), str(x).lower().strip())
sim = lambda a, b_: difflib.SequenceMatcher(None, norm(a), str(b_).lower()).ratio()
amap = cnt[['season', 'abbr', 'tid']]
aall = cnt.groupby('abbr').tid.agg(lambda s: s.mode().iloc[0]).to_dict()
akey = {(int(r.season), r.abbr): int(r.tid) for r in amap.itertuples()}
gd = noid.drop_duplicates(['game_desc', 'date_time'])[['game_desc', 'date_time', 'season']].copy()
gd['ldate'] = pd.to_datetime(gd.date_time, errors='coerce').dt.normalize()
sk = sch[['game_id', 'date', 'home_id', 'away_id', 'home_team', 'away_team']]
byday = {d: grp for d, grp in sk.groupby('date')}
hits = []
for r in gd.itertuples():
    parts = str(r.game_desc).split('@')
    if len(parts) != 2 or pd.isna(r.ldate):
        continue
    best = None
    for dd in [r.ldate, r.ldate - pd.Timedelta(days=1), r.ldate + pd.Timedelta(days=1)]:
        for c in byday.get(dd, sk.iloc[:0]).itertuples():
            sc = min(sim(parts[0], c.away_team), sim(parts[1], c.home_team))
            if best is None or sc > best[0]:
                best = (sc, c.game_id, c.home_id, c.away_id)
    if best and best[0] >= 0.75:
        hits.append((r.game_desc, r.date_time, best[1], best[2], best[3]))
hits = pd.DataFrame(hits, columns=['game_desc', 'date_time', 'game_id', 'home_id_m', 'away_id_m']).drop_duplicates('game_id')
noid = noid.drop(columns=['game_id']).merge(hits, on=['game_desc', 'date_time'])
def home_abbr(grp):
    ab = list(grp.abbr.unique())
    if len(ab) != 2: return None
    s_ = int(grp.season.iloc[0]); h, a = int(grp.home_id_m.iloc[0]), int(grp.away_id_m.iloc[0])
    t = {x: akey.get((s_, x), aall.get(x)) for x in ab}
    for x, y_ in [(ab[0], ab[1]), (ab[1], ab[0])]:
        if t[x] == h or t[y_] == a: return x
    return None
ha = noid.groupby('game_id').apply(home_abbr).dropna().rename('home_abbr')
noid = noid.merge(ha, left_on='game_id', right_index=True)
noid = noid[noid.abbr == noid.home_abbr].copy(); noid['tid'] = noid.home_id_m; noid['home_id'] = noid.home_id_m
print('lines recovered without archive game_id:', noid.game_id.nunique())
b = b.merge(cnt[['season', 'abbr', 'tid']], on=['season', 'abbr'])
b = b.merge(sch[['game_id', 'home_id']], on='game_id'); b = b[b.tid == b.home_id]
b = pd.concat([b, noid[b.columns]], ignore_index=True)
pin = b[b.book == 'PINNACLE'].groupby('game_id').lines.median().rename('pin')
med = b.groupby('game_id').lines.median().rename('med')
nb = b.groupby('game_id').book.nunique().rename('n_books')
ln = pd.concat([pin, med, nb], axis=1); ln['home_spread'] = ln.pin.fillna(ln.med)
ln['line_src'] = np.where(ln.pin.notna(), 'Pinnacle', 'median of books')
g = g.merge(ln[['home_spread', 'line_src', 'n_books']].reset_index(), on='game_id', how='left')
g['v_ats'] = -(g.home_points - g.away_points + g.home_spread)  # visitor margin vs the number
g['v_cover'] = np.where(g.v_ats > 0, 1.0, np.where(g.v_ats < 0, 0.0, np.nan))

g.to_parquet(OUT)
print(g.shape)
print(g.groupby(['sample', 'grp'], observed=True).size())
print('ratio6:', g.groupby(['sample', 'ratio6']).size().to_dict())
print('pbp_ok share by sample:', g.groupby('sample').pbp_ok.mean().round(3).to_dict())
print('lines matched:', g.home_spread.notna().sum(), g[g.home_spread.notna()].groupby('grp', observed=True).size().to_dict())
