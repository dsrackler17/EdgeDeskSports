"""Altitude effect models.

Margin-type outcomes (visitor full-game, 2H, Q4 margin; visitor ATS margin):
  one row per game; team strength absorbed by SIGNED team-season fixed effects
  (+1 home team-season, -1 visitor team-season), partialled out by Frisch-Waugh-Lovell
  with sparse LSQR; intercept = generic home-field advantage. SEs clustered by host venue.

Unit outcomes (3rd-down conversions allowed, 2H explosives allowed, defensive plays faced,
penalties, turnovers): two rows per game (each team as the 'focus' team), offense/defense
team-season FEs via pyfixest; altitude enters as visitor x group. SEs clustered by host venue.
"""
import sys, json, numpy as np, pandas as pd, scipy.sparse as sp
from scipy.sparse.linalg import lsqr
import pyfixest as pf

PANEL, OUTDIR = sys.argv[1], sys.argv[2]
g = pd.read_parquet(PANEL)
g['g1'] = (g.grp == '1000-2999').astype(float)
g['g2'] = (g.grp == '>=3000').astype(float)
g['r6'] = g.ratio6.astype(float)
g['gain_k'] = g.gain_ft.clip(lower=0) / 1000.0
g['log_travel'] = np.log1p(g.travel_mi)
g['dome'] = g.dome.astype(float)
g['month'] = g.month.fillna(0).astype(int)
# pace: season-average scrimmage plays per game of each team (both sides), from PBP
pl = pd.concat([g[['season', 'home_id', 'n_plays']].rename(columns={'home_id': 't'}),
                g[['season', 'away_id', 'n_plays']].rename(columns={'away_id': 't'})])
pace = pl.groupby(['season', 't']).n_plays.mean()
g['pace'] = [np.nanmean([pace.get((s, h), np.nan), pace.get((s, a), np.nan)]) for s, h, a in zip(g.season, g.home_id, g.away_id)]

RES = []

def cluster_ols(y, X, cl, k_absorbed):
    n, k = X.shape
    XtX_inv = np.linalg.pinv(X.T @ X)
    b = XtX_inv @ X.T @ y
    u = y - X @ b
    meat = np.zeros((k, k)); G = 0
    for c in np.unique(cl):
        m = cl == c; s = X[m].T @ u[m]; meat += np.outer(s, s); G += 1
    adj = G / (G - 1) * (n - 1) / max(n - k - k_absorbed, 1)
    V = adj * XtX_inv @ meat @ XtX_inv
    return b, np.sqrt(np.diag(V)), G

def wild_p(y, X, j, cl, B=999, seed=11):
    """Wild cluster bootstrap-t p-value (Rademacher, null imposed) for coefficient j."""
    rng = np.random.default_rng(seed)
    ucl, inv = np.unique(cl, return_inverse=True); G = len(ucl)
    def tstat(yy):
        XtX_inv = np.linalg.pinv(X.T @ X); b = XtX_inv @ X.T @ yy; u = yy - X @ b
        S = np.zeros((G, X.shape[1])); np.add.at(S, inv, X * u[:, None])
        V = XtX_inv @ (S.T @ S) @ XtX_inv
        return b[j] / np.sqrt(V[j, j])
    t0 = tstat(y)
    Xr = np.delete(X, j, axis=1); br = np.linalg.lstsq(Xr, y, rcond=None)[0]; fit = Xr @ br; ur = y - fit
    ts = np.array([tstat(fit + ur * rng.choice([-1.0, 1.0], G)[inv]) for _ in range(B)])
    return float((np.abs(ts) >= abs(t0)).mean())

WILD = {}

def signed_fe(d, yvar, xvars, label, fe=True, wild=False, extra=None):
    d = d.dropna(subset=[yvar] + xvars).reset_index(drop=True)
    y = d[yvar].to_numpy(float)
    X = d[xvars].to_numpy(float)
    X = X - X.mean(axis=0)  # centre so the intercept is home-field edge at average controls
    if extra is not None:   # e.g. host-venue dummies (venue-specific home edge)
        E = pd.get_dummies(d[extra], drop_first=True, dtype=float).to_numpy()
        X = np.column_stack([X, E])
    X = np.column_stack([np.ones(len(d)), X])
    ka = 0
    if fe:
        hts = (d.home_id.astype(int).astype(str) + '_' + d.season.astype(str))
        ats = (d.away_id.astype(int).astype(str) + '_' + d.season.astype(str))
        cats = pd.Index(pd.unique(pd.concat([hts, ats])))
        r = np.arange(len(d))
        Z = sp.csr_matrix((np.r_[np.ones(len(d)), -np.ones(len(d))],
                           (np.r_[r, r], np.r_[cats.get_indexer(hts), cats.get_indexer(ats)])), shape=(len(d), len(cats)))
        def resid(v):
            return v - Z @ lsqr(Z, v, atol=1e-10, btol=1e-10, iter_lim=20000)[0]
        y = resid(y); X = np.column_stack([resid(X[:, j]) for j in range(X.shape[1])])
        ka = len(cats) - 1
    b, se, G = cluster_ols(y, X, d.venue_id.to_numpy(), ka)
    if wild:
        for nm in ['g1', 'g2', 'r6']:
            if nm in xvars:
                WILD[f'{label}|{yvar}|{nm}'] = wild_p(y, X, 1 + xvars.index(nm), d.venue_id.to_numpy())
    names = ['intercept'] + xvars
    out = {}
    for nm, bb, ss in zip(names, b, se):
        out[nm] = (bb, ss)
    RES.append(dict(model=label, outcome=yvar, n=len(d), clusters=G,
                    n_g1=int(d.g1.sum()) if 'g1' in d else None, n_g2=int(d.g2.sum()) if 'g2' in d else None,
                    n_r6=int(d.r6.sum()), coefs={k: [float(v[0]), float(v[1])] for k, v in out.items()}))
    return out

controls = ['log_travel', 'tz_cross', 'rest_diff', 'dome', 'log_cap', 'pace']
season_d = pd.get_dummies(g.season, prefix='yr', drop_first=True, dtype=float)
month_d = pd.get_dummies(g.month, prefix='mo', drop_first=True, dtype=float)
g = pd.concat([g, season_d, month_d], axis=1)
yr, mo = list(season_d.columns), list(month_d.columns)

main = g[g['sample'] == 'verified_venue_2001_2021'].copy()
allg = g.copy()
pbp = main[main.pbp_ok]

specs = {
    'raw': ['g1', 'g2'],
    'controls_noFE': ['g1', 'g2'] + controls + yr + mo,
    'FE+controls': ['g1', 'g2'] + controls + yr + mo,
    'FE+controls+ratio6': ['g1', 'g2', 'r6'] + controls + yr + mo,
    'FE+controls_ratio6_only': ['r6'] + controls + yr + mo,
    'FE+controls_linear_gain': ['gain_k'] + controls + yr + mo,
    'FE+controls_linear_gain+ratio6': ['gain_k', 'r6'] + controls + yr + mo,
}
for yv, d in [('v_margin', main), ('v_margin_2h', pbp), ('v_margin_q4', pbp), ('v_margin_1h', pbp), ('v_ats', main)]:
    for nm, xs in specs.items():
        signed_fe(d, yv, xs, nm, fe=nm.startswith('FE'), wild=nm in ('FE+controls', 'FE+controls+ratio6'))
    # venue-specific home edge: altitude identified only from which visitors come to a given host
    signed_fe(d, yv, specs['FE+controls'], 'FE+controls+hostHFA', fe=True, extra='venue_id')
# all-years sensitivity (2022-2025 venues inferred; rest/month unavailable there -> fewer controls)
for yv in ['v_margin', 'v_margin_2h', 'v_margin_q4']:
    d = allg if yv == 'v_margin' else allg[allg.pbp_ok]
    signed_fe(d, yv, ['g1', 'g2', 'log_travel', 'tz_cross', 'dome', 'log_cap', 'pace'] + yr, 'FE+controls_2001_2025', fe=True)

# host-venue leave-one-out for the >=3000 coefficient (full-game and 2H margin)
loo = []
hosts = main[main.g2 == 1].groupby('venue_id').size().sort_values(ascending=False)
for v in hosts.index:
    for yv, d in [('v_margin', main), ('v_margin_2h', pbp)]:
        o = signed_fe(d[d.venue_id != v], yv, specs['FE+controls'], f'LOO_drop_{int(v)}', fe=True)
        loo.append(dict(venue_id=int(v), outcome=yv, b=o['g2'][0], se=o['g2'][1]))
        RES.pop()

# ---------- unit outcomes: long format ----------
def mk_long(d):
    base = ['game_id', 'season', 'venue_id', 'g1', 'g2', 'r6', 'log_travel', 'tz_cross', 'rest_diff', 'dome', 'log_cap', 'pace', 'month']
    v = d[base].copy(); v['vis'] = 1.0
    v['team'] = d.away_id.astype(int).astype(str) + '_' + d.season.astype(str)
    v['opp'] = d.home_id.astype(int).astype(str) + '_' + d.season.astype(str)
    v['d3att'], v['d3conv'] = d.vd_3att, d.vd_3conv
    v['d3att_2h'], v['d3conv_2h'] = d.vd_3att_2h, d.vd_3conv_2h
    v['expl_2h'], v['plays_2h'], v['plays_faced'] = d.vd_expl_2h, d.vd_plays_2h, d.vd_plays
    v['pen'], v['pen_2h'], v['to_lost'] = d.v_pen, d.v_pen_2h, d.v_to
    h = d[base].copy(); h['vis'] = 0.0
    h['team'] = d.home_id.astype(int).astype(str) + '_' + d.season.astype(str)
    h['opp'] = d.away_id.astype(int).astype(str) + '_' + d.season.astype(str)
    h['d3att'], h['d3conv'] = d.hd_3att, d.hd_3conv
    h['d3att_2h'], h['d3conv_2h'] = d.hd_3att_2h, d.hd_3conv_2h
    h['expl_2h'], h['plays_2h'], h['plays_faced'] = d.hd_expl_2h, d.hd_plays_2h, d.hd_plays
    h['pen'], h['pen_2h'], h['to_lost'] = d.h_pen, d.h_pen_2h, d.h_to
    h['rest_diff'] = -h.rest_diff
    L = pd.concat([v, h], ignore_index=True)
    for c in ['g1', 'g2', 'r6', 'log_travel', 'tz_cross', 'dome', 'log_cap']:
        L[c + '_v'] = L[c] * L.vis
    L['d3rate'] = L.d3conv / L.d3att.replace(0, np.nan)
    L['d3rate_2h'] = L.d3conv_2h / L.d3att_2h.replace(0, np.nan)
    L['expl_rate_2h'] = L.expl_2h / L.plays_2h.replace(0, np.nan)
    L['month'] = L.month.astype(int)
    return L

L = mk_long(pbp)
# reliability guard on penalty attribution: drop games where attribution looks broken
# ESPN penalty-team attribution defaults to the offense before 2014 (offense share ~0.85 vs ~0.58 after),
# so penalty models use 2014+ only.
pen_ok = set(pbp.loc[pbp.season >= 2014, 'game_id'])
unit = [('d3rate', 'd3att', 'team+opp'), ('d3rate_2h', 'd3att_2h', 'team+opp'),
        ('expl_rate_2h', 'plays_2h', 'team+opp'), ('expl_2h', None, 'team+opp'),
        ('plays_faced', None, 'team+opp'), ('pen', None, 'team+opp'), ('pen_2h', None, 'team+opp'),
        ('to_lost', None, 'team+opp')]
# NOTE: in long rows, 'team' is the DEFENSE for d3/expl/plays_faced, and the offending/losing team for pen/to.
ctrl_v = 'log_travel_v + tz_cross_v + rest_diff + dome_v + log_cap_v + pace + C(month)'
for yv, w, _ in unit:
    d = L.dropna(subset=[yv, 'pace', 'log_cap_v', 'rest_diff'])
    if yv.startswith('pen'):
        d = d[d.game_id.isin(pen_ok)]
    for nm, rhs in [('FE+controls', f'vis + g1_v + g2_v + {ctrl_v}'),
                    ('FE+controls+ratio6', f'vis + g1_v + g2_v + r6_v + {ctrl_v}')]:
        fit = pf.feols(f'{yv} ~ {rhs} | team + opp', data=d, vcov={'CRV1': 'venue_id'},
                       weights=w if w else None)
        tb = fit.tidy()
        RES.append(dict(model=nm, outcome=yv, n=int(fit._N), clusters=int(d.venue_id.nunique()),
                        n_g1=int(d.g1_v.sum()), n_g2=int(d.g2_v.sum()), n_r6=int(d.r6_v.sum()),
                        coefs={k: [float(tb.loc[k, 'Estimate']), float(tb.loc[k, 'Std. Error'])] for k in tb.index}))

# ---------- descriptive tables ----------
def desc(d, by):
    out = d.groupby(by, observed=True).agg(n=('game_id', 'size'), v_margin=('v_margin', 'mean'),
        v_win=('v_margin', lambda s: (s > 0).mean()), n_lines=('v_ats', lambda s: s.notna().sum()),
        v_cover=('v_cover', 'mean'), v_ats=('v_ats', 'mean'))
    return out
D1 = desc(main, 'grp'); D2 = desc(main, 'ratio6'); D3 = desc(main, ['grp', 'ratio6'])
P1 = pbp.groupby('grp', observed=True).agg(n=('game_id', 'size'), m1h=('v_margin_1h', 'mean'), m2h=('v_margin_2h', 'mean'),
        mq4=('v_margin_q4', 'mean'),
        d3=('vd_3conv', 'sum'), d3a=('vd_3att', 'sum'), h3=('hd_3conv', 'sum'), h3a=('hd_3att', 'sum'),
        vexpl2h=('vd_expl_2h', 'mean'), vplays=('vd_plays', 'mean'), vto=('v_to', 'mean'), vpen=('v_pen', 'mean'))
P1['vis_def_3rd_rate'] = P1.d3 / P1.d3a; P1['home_def_3rd_rate'] = P1.h3 / P1.h3a
hostlist = main[main.g2 == 1].groupby(['venue_id', 'g_venue']).agg(n=('game_id', 'size'), elev=('g_elev_ft', 'first'),
        v_margin=('v_margin', 'mean'), cover=('v_cover', 'mean'), n_lines=('v_ats', lambda s: s.notna().sum())).reset_index()

# cluster bootstrap CIs (by host venue) for raw cover rates per group
rng = np.random.default_rng(7)
ml = main.dropna(subset=['v_cover'])
boot = {}
for grp in ['<1000', '1000-2999', '>=3000']:
    d = ml[ml.grp == grp]; vs = d.venue_id.unique(); bys = {v: d[d.venue_id == v].v_cover.to_numpy() for v in vs}
    stats = []
    for _ in range(2000):
        pick = rng.choice(vs, len(vs)); arr = np.concatenate([bys[v] for v in pick]); stats.append(arr.mean())
    boot[grp] = [float(d.v_cover.mean()), float(np.percentile(stats, 2.5)), float(np.percentile(stats, 97.5)), int(len(d)), int(len(vs))]

cov = dict(
    games_main=int(len(main)), games_all=int(len(allg)),
    pbp_games_main=int(len(pbp)), lines_main=int(main.v_ats.notna().sum()),
    line_src=main.line_src.value_counts().to_dict(),
    seasons_main=[int(main.season.min()), int(main.season.max())],
    pbp_seasons=[int(pbp.season.min()), int(pbp.season.max())],
    line_seasons=[int(main[main.v_ats.notna()].season.min()), int(main[main.v_ats.notna()].season.max())],
    by_sample_grp=g.groupby(['sample', 'grp'], observed=True).size().astype(int).reset_index().values.tolist(),
    ratio6_by_grp=main.groupby(['grp', 'ratio6'], observed=True).size().astype(int).reset_index().values.tolist(),
    pen_games_kept=int(len(pen_ok)),
)
with open(OUTDIR + '/results.json', 'w') as f:
    json.dump(dict(models=RES, loo=loo, wild=WILD, coverage=cov, boot_cover=boot), f, default=str, indent=1)
D1.to_csv(OUTDIR + '/desc_grp.csv'); D2.to_csv(OUTDIR + '/desc_ratio6.csv'); D3.to_csv(OUTDIR + '/desc_grp_ratio6.csv')
P1.to_csv(OUTDIR + '/pbp_desc_grp.csv'); hostlist.to_csv(OUTDIR + '/hosts_ge3000.csv', index=False)
main.to_csv(OUTDIR + '/panel_main.csv.gz', index=False)
print('done', len(RES))
