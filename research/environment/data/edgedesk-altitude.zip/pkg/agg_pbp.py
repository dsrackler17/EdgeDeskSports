"""Aggregate ESPN play-by-play (sportsdataverse espn_cfb_pbp release) to game level.

Outputs one row per game with quarter scores and visitor-defense / visitor-offense metrics.
Definitions:
  scrimmage play: rush, pass or sack, excluding kneel-downs and no-play penalties
  3rd-down conversion: 3rd-down scrimmage play with yards gained >= distance or a TD
  explosive: rush >= 15 yds or pass/reception >= 20 yds (yards on the play, statYardage)
  defensive plays faced (snap proxy): opponent scrimmage plays; NOT player snap counts
  penalties: accepted (not declined, not offsetting) flags, attributed via penalized_team
  turnovers: is_turnover plays, attributed to turnover_team (team that lost the ball)
"""
import sys, pandas as pd, numpy as np

D = sys.argv[1]
OUT = sys.argv[2]
cols = ['season','game_id','period','pos_team_id','def_pos_team_id','homeTeamId','awayTeamId',
        'start.down','start.distance','statYardage','rush','pass','sack','touchdown','kneel_down',
        'penalty_flag','penalty_declined','penalty_offset','penalty_no_play','penalized_team',
        'yds_penalty','is_turnover','turnover_team','end.homeScore','end.awayScore',
        'homeFinalScore','awayFinalScore','seasonType','week','status_type_completed','type.text']
rows = []
for y in range(2004, 2026):
    p = pd.read_parquet(f'{D}/espn_{y}.parquet', columns=cols)
    p = p[p.period.between(1, 4) | (p.period > 4)]
    for c in ['pos_team_id','def_pos_team_id','homeTeamId','awayTeamId','penalized_team','turnover_team']:
        p[c] = pd.to_numeric(p[c], errors='coerce')
    p['sy'] = pd.to_numeric(p.statYardage, errors='coerce').fillna(0)
    nop = p.penalty_no_play.fillna(False).astype(bool)
    p['scrim'] = (p.rush.fillna(False).astype(bool) | p['pass'].fillna(False).astype(bool) | p.sack.fillna(False).astype(bool)) & ~nop & ~p.kneel_down.fillna(False).astype(bool)
    p['d3'] = p.scrim & (p['start.down'] == 3)
    p['d3c'] = p.d3 & ((p.sy >= p['start.distance']) | p.touchdown.fillna(False).astype(bool))
    p['expl'] = p.scrim & ((p.rush.fillna(False).astype(bool) & (p.sy >= 15)) | (p['pass'].fillna(False).astype(bool) & (p.sy >= 20)))
    p['h2'] = p.period >= 3
    p['q4'] = p.period == 4
    p['pen'] = p.penalty_flag.fillna(False).astype(bool) & ~p.penalty_declined.fillna(False).astype(bool) & ~p.penalty_offset.fillna(False).astype(bool)
    p['to'] = p.is_turnover.fillna(False).astype(bool)
    p['home_off'] = p.pos_team_id == p.homeTeamId
    p['away_off'] = p.pos_team_id == p.awayTeamId
    g = p.groupby('game_id')
    base = g.agg(season=('season','first'), seasonType=('seasonType','first'), week=('week','first'),
                 home_id=('homeTeamId','first'), away_id=('awayTeamId','first'),
                 home_final=('homeFinalScore','first'), away_final=('awayFinalScore','first'),
                 completed=('status_type_completed','first'), n_plays=('scrim','sum'))
    # quarter-end cumulative scores
    for q in [1,2,3,4]:
        s = p[p.period <= q].groupby('game_id')[['end.homeScore','end.awayScore']].max()
        base[f'h_cum{q}'] = s['end.homeScore']; base[f'a_cum{q}'] = s['end.awayScore']
    s = p.groupby('game_id')[['end.homeScore','end.awayScore']].max()
    base['h_pbp_final'] = s['end.homeScore']; base['a_pbp_final'] = s['end.awayScore']
    def cnt(mask, name):
        base[name] = p[mask].groupby('game_id').size()
    H, A = p.home_off, p.away_off
    # visitor DEFENSE (home offense)
    cnt(H & p.d3, 'vd_3att'); cnt(H & p.d3c, 'vd_3conv')
    cnt(H & p.d3 & p.h2, 'vd_3att_2h'); cnt(H & p.d3c & p.h2, 'vd_3conv_2h')
    cnt(H & p.expl, 'vd_expl'); cnt(H & p.expl & p.h2, 'vd_expl_2h'); cnt(H & p.expl & p.q4, 'vd_expl_q4')
    cnt(H & p.scrim, 'vd_plays'); cnt(H & p.scrim & p.h2, 'vd_plays_2h')
    # home defense (away offense), for symmetric comparison
    cnt(A & p.d3, 'hd_3att'); cnt(A & p.d3c, 'hd_3conv')
    cnt(A & p.d3 & p.h2, 'hd_3att_2h'); cnt(A & p.d3c & p.h2, 'hd_3conv_2h')
    cnt(A & p.expl, 'hd_expl'); cnt(A & p.expl & p.h2, 'hd_expl_2h')
    cnt(A & p.scrim, 'hd_plays'); cnt(A & p.scrim & p.h2, 'hd_plays_2h')
    # turnovers lost and penalties, by team
    vt = p.turnover_team == p.awayTeamId; ht = p.turnover_team == p.homeTeamId
    cnt(p.to & vt, 'v_to'); cnt(p.to & ht, 'h_to'); cnt(p.to & vt & p.h2, 'v_to_2h'); cnt(p.to & ht & p.h2, 'h_to_2h')
    vp = p.pen & (p.penalized_team == p.awayTeamId); hp = p.pen & (p.penalized_team == p.homeTeamId)
    cnt(vp, 'v_pen'); cnt(hp, 'h_pen'); cnt(vp & p.h2, 'v_pen_2h'); cnt(hp & p.h2, 'h_pen_2h')
    # penalty attribution sanity: share of accepted flags attributed to offense
    pp = p[p.pen]
    base['pen_attr_offense_share'] = (pp.penalized_team == pp.pos_team_id).groupby(pp.game_id).mean()
    cnt(p.pen, 'pen_total')
    rows.append(base.reset_index())
    print(y, len(base), flush=True)
out = pd.concat(rows, ignore_index=True)
cntcols = [c for c in out.columns if c.startswith(('vd_','hd_','v_','h_to','h_pen')) ]
out[cntcols] = out[cntcols].fillna(0)
out.to_parquet(OUT)
print(out.shape)
