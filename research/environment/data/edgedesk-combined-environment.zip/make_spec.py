"""Combined-model results -> study spec JSON (programmatic numbers)."""
import sys, json
R = json.load(open(sys.argv[1])); OUT = sys.argv[2]
NAMES = {'altitude': 'Altitude', 'travel-circadian': 'Travel & circadian', 'wind-offensive-identity': 'Wind & offensive identity',
         'rest-recovery': 'Rest & recovery', 'defensive-fatigue': 'Defensive fatigue', 'weather-adaptation': 'Weather adaptation',
         'officiating-tendencies': 'Officiating tendencies'}
def f2(x): return f'{x:+.2f}'
def pct(x): return '–' if x is None else f'{100*x:.1f}%'
def verdict(r):
    lo, hi = r['mse_gain_ci']
    if lo > 0: return 'Improves on the line'
    if hi < 0: return 'Worse than the line'
    return 'No clear change'
def rows(key):
    res = R[key]['results']; out = []
    for k in ['all'] + [f'only:{m}' for m in R[key]['modules']]:
        r = res[k]; lab = 'All modules together' if k == 'all' else NAMES.get(k.split(':', 1)[1], k)
        out.append([lab, f'{r["n"]:,}', f'{r["rmse_market"]:.3f}', f'{r["rmse_model"]:.3f}',
                    f'{f2(r["mse_gain"])} [{f2(r["mse_gain_ci"][0])}, {f2(r["mse_gain_ci"][1])}]',
                    f'{r["bets"]:,}', f'{pct(r["hit"])}' + (f' [{pct(r["hit_ci"][0])}, {pct(r["hit_ci"][1])}]' if r['hit_ci'] else ''), verdict(r)])
    return out
def loo(key):
    res = R[key]['results']; a = res['all']['mse_gain']; out = []
    for m in R[key]['modules']:
        r = res.get(f'all_minus:{m}')
        if r: out.append([NAMES.get(m, m), f2(a - r['mse_gain'])])
    return out
cols = ['Feature set', 'Test games', 'Market RMSE', 'Model RMSE', 'MSE gain vs line [95% CI]', 'Bets (|adj| ≥ 1 pt)', 'Hit rate [95% CI]', 'Result']
ns, cs, nt = R['NFL|res_spread'], R['CFB|res_spread'], R['NFL|res_total']
def winners(key):
    return [NAMES.get(m, m) for m in R[key]['modules'] if R[key]['results'][f'only:{m}']['mse_gain_ci'][0] > 0]
wn_s, wc_s, wn_t = winners('NFL|res_spread'), winners('CFB|res_spread'), winners('NFL|res_total')
ov = R['overlap']
al = lambda key: R[key]['results']['all']
fnd = [
  f'NFL spreads, {ns["test_seasons"][0]}–{ns["test_seasons"][1]}: all modules together change squared error vs the line by {f2(al("NFL|res_spread")["mse_gain"])} (95% CI {f2(al("NFL|res_spread")["mse_gain_ci"][0])} to {f2(al("NFL|res_spread")["mse_gain_ci"][1])}). ' + ('Modules that beat the line on their own: ' + ', '.join(wn_s) + '.' if wn_s else 'No single module beats the line on its own.'),
  f'CFB spreads, {cs["test_seasons"][0]}–{cs["test_seasons"][1]}: all modules together {f2(al("CFB|res_spread")["mse_gain"])} (95% CI {f2(al("CFB|res_spread")["mse_gain_ci"][0])} to {f2(al("CFB|res_spread")["mse_gain_ci"][1])}). ' + ('Beat the line alone: ' + ', '.join(wc_s) + '.' if wc_s else 'No single module beats the line on its own.'),
  f'NFL totals: all modules together {f2(al("NFL|res_total")["mse_gain"])} (95% CI {f2(al("NFL|res_total")["mse_gain_ci"][0])} to {f2(al("NFL|res_total")["mse_gain_ci"][1])}). ' + ('Beat the total alone: ' + ', '.join(wn_t) + '.' if wn_t else 'No single module beats the total on its own.'),
  f'Adding modules one by one would double count: in the 1% of NFL games where stacked single-module adjustments are largest, they average {ov["NFL"]["top1pct_mean_abs_stacked"]:.2f} points against {ov["NFL"]["top1pct_mean_abs_joint"]:.2f} from the joint fit.',
  'Every adjustment is scored only on seasons the model never saw, with the penalty chosen inside the training seasons.']
wt = R['NFL|res_total']['results'].get('only:weather-adaptation')
if wt and wt['mse_gain_ci'][0] > 0:
    fnd.insert(3, f'The one candidate: weather adaptation on NFL totals hit {pct(wt["hit"])} of {wt["bets"]} out-of-sample bets (95% CI {pct(wt["hit_ci"][0])} to {pct(wt["hit_ci"][1])}). It uses weather recorded at kickoff, which the market only saw as a forecast, so this is an upper bound until it is retested on archived forecasts. It is also one of {sum(len(R[k]["modules"]) for k in ["NFL|res_spread","CFB|res_spread","NFL|res_total"])} single-module tests run here.')
spec = {
 'slug': 'combined-environment', 'module': 'Combined Environment Model', 'status': 'experimental', 'status_label': 'Validation report',
 'title': 'One environmental adjustment, tested against the close',
 'question': 'When travel, rest, weather, wind, fatigue, officiating and altitude are fit together, does anything improve on the closing number out of sample?',
 'lede': 'The seven studies are fit jointly so overlapping effects are not counted twice, then scored season by season on games the model never saw. The bar is simple: beat the betting line, not a weaker baseline.',
 'scope': f'NFL {ns["test_seasons"][0]}–{ns["test_seasons"][1]} test seasons · CFB {cs["test_seasons"][0]}–{cs["test_seasons"][1]}', 'updated': '2026-10-17',
 'findings': fnd,
 'sections': [
  {'h': 'How the test works', 'p': [
    'The target is the market residual: final home margin minus the margin the closing spread implied (and, for NFL totals, total points minus the closing total). A feature only helps if it predicts that residual.',
    'For each test season the model trains on every earlier season, picks a ridge penalty by time-ordered validation inside those training seasons, and predicts the test season. Features are pre-game knowable only; game-time weather is the one exception and is labeled as an upper bound because forecasts are noisier than the reading.',
    'MSE gain is the market’s squared error minus the model’s, per game. Positive means the adjustment beat the line. Intervals bootstrap over season-weeks. The betting check takes the model’s side whenever its adjustment is at least one point; 52.4% is break-even at -110.']},
  {'h': 'NFL spreads', 'table': {'cols': cols, 'rows': rows('NFL|res_spread'), 'num': [1, 2, 3, 4, 5, 6], 'caption': 'Rolling-origin out-of-sample results. nflverse spread_line as the market.'}},
  {'h': 'NFL totals', 'table': {'cols': cols, 'rows': rows('NFL|res_total'), 'num': [1, 2, 3, 4, 5, 6], 'caption': 'Same procedure against the nflverse total_line.'}},
  {'h': 'CFB spreads', 'table': {'cols': cols, 'rows': rows('CFB|res_spread'), 'num': [1, 2, 3, 4, 5, 6], 'caption': 'SBR archive closing spreads, 2006–2019; test seasons 2011–2019.'}},
  {'h': 'What each module adds inside the joint model', 'p': ['Drop one module from the joint fit and see how much worse it gets. Positive means the module carried value the others did not.'],
   'tables': [{'cols': ['Module (NFL spreads)', 'Contribution to MSE gain'], 'rows': loo('NFL|res_spread'), 'num': [1]},
              {'cols': ['Module (NFL totals)', 'Contribution to MSE gain'], 'rows': loo('NFL|res_total'), 'num': [1]},
              {'cols': ['Module (CFB spreads)', 'Contribution to MSE gain'], 'rows': loo('CFB|res_spread'), 'num': [1]}]}],
 'model_verdict': 'Nothing here changes EdgeDesk spreads. The weather-on-totals result is registered as a research candidate: it must be rebuilt on archived game-day forecasts and pass a preregistered forward window against closing totals before it can touch a fair total. Only a module whose out-of-sample interval sits above zero against the closing line is eligible to touch EdgeDesk fair numbers, and even then it enters as a registered research model with its own validation report and a preregistered evaluation window, not as a direct change to live spreads. Everything else stays as observed context on game research pages.',
 'data': [['Spread target', 'Home margin minus market-implied margin.'], ['NFL market', 'nflverse spread_line and total_line, 1999–2025 (capture time undocumented).'],
          ['CFB market', 'SBR odds archive close, 2006–2019, verified venues.'], ['Model', 'Ridge regression on standardized features with missing-value flags; rolling-origin season splits; penalty from time-ordered inner validation.']],
 'gaps': [['EdgeDesk model history', 'EdgeDesk has no multi-season archive of its own historical fair lines, so the baseline is the closing market line, which is the stronger benchmark.'],
          ['Forecast weather', 'Historical game forecasts were not available; actual game weather overstates what was knowable pre-game.'],
          ['CFB weather and officials', 'No historical CFB weather or crew data was reachable, so those modules are NFL only.']],
 'sources': [['nflverse data', 'https://github.com/nflverse/nflverse-data'], ['CollegeFootballData via cfbfastR-data', 'https://github.com/sportsdataverse/cfbfastR-data']],
 'zip': 'edgedesk-combined-environment.zip'}
json.dump(spec, open(OUT, 'w'), indent=1); print('ok')
