# EdgeDesk combined environment model

Rolling-origin out-of-sample test of seven environment modules (altitude, travel and circadian, wind and offensive identity, rest and recovery, defensive fatigue, weather adaptation, officiating) against market lines.

- Target: market residual (home margin minus market-implied margin; NFL total minus total line).
- Train on all seasons before t, test on t. Ridge penalty picked by time-ordered validation inside training seasons.
- Features: each study's pre-game feature file (game-time weather is the exception, an upper bound).
- Files: combined_model.py (run: `python3 combined_model.py <scratch dir> <features dir> <out dir>`), combined_results.json, combined_panel.csv.gz.
- Market lines: nflverse spread_line / total_line (NFL 1999-2025), SBR archive close (CFB 2006-2019). Capture times are undocumented.
