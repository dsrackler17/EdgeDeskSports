"""Phase 3-4: combined environmental adjustment, tested out of sample against the market.

Baseline = the market line (NFL nflverse spread_line/total_line; CFB SBR-archive close).
Target  = market residual: home margin minus market-implied home margin (and, NFL only, total minus total line).
A module "adds value" only if adding it improves out-of-sample residual prediction across a
rolling-origin season split (train on all seasons before t, test on season t), with the ridge
penalty chosen by time-ordered CV inside the training seasons only. Features are restricted to
pre-game-knowable columns from each study's feature file. No outcome columns enter X.

Outputs results JSON + CSVs to OUT.
"""
import sys, os, json, glob, numpy as np, pandas as pd

S, FEAT, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(20261017)

# ---------- outcomes ----------
n = pd.read_parquet(f'{S}/shared/nfl_games.parquet')
nfl = pd.DataFrame({'sport': 'NFL', 'game_id': n.game_id.astype(str), 'season': n.season, 'week': n.week,
                    'mkt_home': n.spread_line, 'margin': n.result, 'total': n.total, 'total_line': n.total_line,
                    'neutral': (n.location == 'Neutral').astype(float)})
c = pd.read_parquet(f'{S}/panel.parquet')
c = c[c['sample'] == 'verified_venue_2001_2021']
cfb = pd.DataFrame({'sport': 'CFB', 'game_id': c.game_id.astype('int64').astype(str), 'season': c.season, 'week': c.week,
                    'mkt_home': -c.home_spread, 'margin': c.home_points - c.away_points, 'total': np.nan, 'total_line': np.nan, 'neutral': 0.0})
Y = pd.concat([nfl, cfb], ignore_index=True)
Y = Y[Y.mkt_home.notna() & Y.margin.notna()].copy()
Y['res_spread'] = Y.margin - Y.mkt_home
Y['res_total'] = Y.total - Y.total_line

# ---------- features ----------
mods = {}
for f in sorted(glob.glob(f'{FEAT}/*.parquet')):
    name = os.path.basename(f).replace('.parquet', '')
    d = pd.read_parquet(f)
    d['game_id'] = d.game_id.astype(str)
    d = d.drop(columns=[x for x in ['season'] if x in d.columns])
    cols = [x for x in d.columns if x not in ('sport', 'game_id') and pd.api.types.is_numeric_dtype(d[x])]
    bad = [x for x in cols if any(k in x.lower() for k in ['result', 'score', 'margin', 'ats', 'cover', 'over_', 'outcome', 'final'])]
    cols = [x for x in cols if x not in bad]
    d = d[['sport', 'game_id'] + cols].drop_duplicates(['sport', 'game_id'])
    d = d.rename(columns={x: f'{name}__{x}' for x in cols})
    mods[name] = [f'{name}__{x}' for x in cols]
    Y = Y.merge(d, on=['sport', 'game_id'], how='left')
print({k: len(v) for k, v in mods.items()})

def design(tr, te, cols):
    """Impute with training means + missing flags; standardize with training stats."""
    Xtr, Xte, names = [], [], []
    for col in cols:
        a, b = tr[col].astype(float), te[col].astype(float)
        if a.notna().sum() < 30 or a.std() == 0 or np.isnan(a.std()):
            continue
        mu, sd = a.mean(), a.std()
        Xtr.append(((a.fillna(mu) - mu) / sd).to_numpy()); Xte.append(((b.fillna(mu) - mu) / sd).to_numpy()); names.append(col)
        if a.isna().mean() > 0.02:
            Xtr.append(a.isna().astype(float).to_numpy() - a.isna().mean()); Xte.append(b.isna().astype(float).to_numpy() - a.isna().mean()); names.append(col + '__na')
    if not names:
        return np.zeros((len(tr), 0)), np.zeros((len(te), 0)), []
    return np.column_stack(Xtr), np.column_stack(Xte), names

def ridge(X, y, lam):
    k = X.shape[1]
    return np.linalg.solve(X.T @ X + lam * np.eye(k), X.T @ (y - y.mean())), y.mean()

LAMS = [1, 10, 100, 1000, 10000, 100000]
def fit_predict(tr, te, cols, target):
    trv = tr[tr[target].notna()]
    Xtr, Xte, names = design(trv, te, cols)
    if Xtr.shape[1] == 0:
        return np.full(len(te), 0.0), {}, None
    y = trv[target].to_numpy()
    # time-ordered inner CV on training seasons (last 3 training seasons as folds)
    seasons = sorted(trv.season.unique()); folds = seasons[-3:] if len(seasons) > 4 else seasons[-1:]
    best, bl = None, None
    for lam in LAMS:
        err = 0.0
        for fs in folds:
            a, b = trv.season < fs, trv.season == fs
            if a.sum() < 200 or b.sum() == 0:
                continue
            Xa, Xb, _ = design(trv[a], trv[b], names_raw(names))
            w, b0 = ridge(Xa, y[a.to_numpy()], lam)
            err += ((y[b.to_numpy()] - (b0 + Xb @ w)) ** 2).sum()
        if best is None or err < best:
            best, bl = err, lam
    w, b0 = ridge(Xtr, y, bl)
    # intercept forced to 0: the market residual's mean is not a feature effect (home edge is already in the line)
    return Xte @ w, dict(zip(names, w)), bl

def names_raw(names):
    return sorted({x.replace('__na', '') for x in names})

def evaluate(sport, target, test_seasons, sets):
    D = Y[(Y.sport == sport) & Y[target].notna()].copy()
    preds = {k: [] for k in sets}; lam_used = {k: [] for k in sets}; coefs = {}
    for t in test_seasons:
        tr, te = D[D.season < t], D[D.season == t]
        if len(tr) < 500 or len(te) == 0:
            continue
        for k, cols in sets.items():
            p, w, lam = fit_predict(tr, te, cols, target)
            preds[k].append(pd.Series(p, index=te.index)); lam_used[k].append(lam)
            if t == test_seasons[-1]:
                coefs[k] = w
    T = D.loc[pd.concat(preds['baseline']).index] if preds['baseline'] else D.iloc[:0]
    out = {}
    y = T[target].to_numpy()
    base_se = y ** 2
    wk = (T.season.astype(str) + '_' + T.week.astype(str)).to_numpy()
    uw = np.unique(wk); inv = np.searchsorted(uw, wk)
    for k in sets:
        p = pd.concat(preds[k]).reindex(T.index).to_numpy()
        se = (y - p) ** 2
        d = base_se - se  # >0 means model beats market
        # cluster bootstrap over season-weeks
        sums = np.bincount(inv, d); cnts = np.bincount(inv)
        bs = []
        for _ in range(2000):
            pick = rng.integers(0, len(uw), len(uw)); bs.append(sums[pick].sum() / cnts[pick].sum())
        # betting test: side with model when |p| >= 1.0 point (spread) / 1.0 (total), exclude pushes
        side = np.where(np.abs(p) >= 1.0, np.sign(p), 0)
        win = (np.sign(y) == side) & (side != 0) & (y != 0)
        played = (side != 0) & (y != 0)
        hit = win.sum() / played.sum() if played.sum() else np.nan
        hs = []
        if played.sum():
            ws = np.bincount(inv, win.astype(float)); ps_ = np.bincount(inv, played.astype(float))
            for _ in range(2000):
                pick = rng.integers(0, len(uw), len(uw)); hs.append(ws[pick].sum() / max(ps_[pick].sum(), 1))
        out[k] = dict(n=int(len(y)), mse_market=float(base_se.mean()), mse_model=float(se.mean()),
                      mse_gain=float(d.mean()), mse_gain_ci=[float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))],
                      rmse_market=float(np.sqrt(base_se.mean())), rmse_model=float(np.sqrt(se.mean())),
                      bets=int(played.sum()), hit=float(hit) if played.sum() else None,
                      hit_ci=[float(np.percentile(hs, 2.5)), float(np.percentile(hs, 97.5))] if hs else None,
                      pred_sd=float(np.std(p)), lambdas=[x for x in lam_used[k] if x is not None])
    return out, coefs

R = {}
for sport, target, seasons in [('NFL', 'res_spread', list(range(2011, 2026))), ('CFB', 'res_spread', list(range(2011, 2020))),
                               ('NFL', 'res_total', list(range(2011, 2026)))]:
    avail = {k: [c_ for c_ in v if Y.loc[Y.sport == sport, c_].notna().mean() > 0.2] for k, v in mods.items()}
    avail = {k: v for k, v in avail.items() if v}
    sets = {'baseline': []}
    for k, v in avail.items():
        sets[f'only:{k}'] = v
    allc = sum(avail.values(), [])
    sets['all'] = allc
    for k in avail:
        sets[f'all_minus:{k}'] = [x for x in allc if not x.startswith(k + '__')]
    res, coefs = evaluate(sport, target, seasons, sets)
    R[f'{sport}|{target}'] = dict(test_seasons=[seasons[0], seasons[-1]], modules=list(avail), results=res,
                                  final_coefs={k: {kk: float(vv) for kk, vv in v.items()} for k, v in coefs.items()})
    print(sport, target, {k: round(v['mse_gain'], 3) for k, v in res.items()})

# ---------- overlap demonstration: stacked single-module estimates vs joint fit (in-sample, all seasons) ----------
def ols(D, cols, target):
    X, _, names = design(D, D.iloc[:1], cols)
    y = D[target].to_numpy()
    w = np.linalg.lstsq(np.column_stack([np.ones(len(D)), X]), y, rcond=None)[0]
    return dict(zip(['_c'] + names, w)), names
overlap = {}
for sport in ['NFL', 'CFB']:
    D = Y[(Y.sport == sport) & Y.res_spread.notna()]
    avail = {k: [c_ for c_ in v if D[c_].notna().mean() > 0.2] for k, v in mods.items()}
    avail = {k: v for k, v in avail.items() if v}
    X, _, names = design(D, D.iloc[:1], sum(avail.values(), []))
    joint = np.column_stack([np.ones(len(D)), X]); wj = np.linalg.lstsq(joint, D.res_spread.to_numpy(), rcond=None)[0]
    pj = X @ wj[1:]
    stacked = np.zeros(len(D))
    for k, v in avail.items():
        Xk, _, nk = design(D, D.iloc[:1], v)
        wk_ = np.linalg.lstsq(np.column_stack([np.ones(len(D)), Xk]), D.res_spread.to_numpy(), rcond=None)[0]
        stacked += Xk @ wk_[1:]
    big = np.abs(stacked) >= np.percentile(np.abs(stacked), 99)
    overlap[sport] = dict(n=int(len(D)), sd_joint=float(pj.std()), sd_stacked=float(stacked.std()),
                          top1pct_mean_abs_stacked=float(np.abs(stacked[big]).mean()), top1pct_mean_abs_joint=float(np.abs(pj[big]).mean()),
                          corr=float(np.corrcoef(pj, stacked)[0, 1]))
R['overlap'] = overlap
json.dump(R, open(f'{OUT}/combined_results.json', 'w'), indent=1, default=str)
Y[['sport', 'game_id', 'season', 'week', 'mkt_home', 'margin', 'res_spread', 'total_line', 'res_total'] + sum(mods.values(), [])].to_csv(f'{OUT}/combined_panel.csv.gz', index=False)
print(json.dumps(overlap, indent=1))
