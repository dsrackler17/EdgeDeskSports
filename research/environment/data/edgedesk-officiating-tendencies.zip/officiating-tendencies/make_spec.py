"""Officiating results -> EdgeDesk study spec JSON. Every number is read from the results files."""
import sys, json, pandas as pd
O, OUT = sys.argv[1], sys.argv[2]
r = json.load(open(f'{O}/results.json')); R = r['res']; mk = r['market']
eb = pd.read_csv(f'{O}/referee_eb_pen_total.csv')
to = pd.read_csv(f'{O}/terciles_over.csv'); ta = pd.read_csv(f'{O}/terciles_ats.csv')
pct = lambda x: f'{100*x:.1f}%'
def ci(b, se, d=2): return f'{b:+.{d}f} [{b-1.96*se:+.{d}f}, {b+1.96*se:+.{d}f}]'

order = ['pen_total', 'pen_yds_total', 'off_hold', 'rtp', 'unr', 'def_hold', 'pre_snap', 'dpi', 'pen_diff']
var_rows = [[R[k]['label'], f'{R[k]["mean"]:.2f}', f'{R[k]["ref_sd"]:.2f}', pct(R[k]['ref_share']), f'{R[k]["perm_p"]:.3f}',
             f'{R[k]["split_r"]:.2f} [{R[k]["split_lo"]:.2f}, {R[k]["split_hi"]:.2f}]', f'{R[k]["yy_r"]:.2f}'] for k in order]

# reliability chart: split-half r with 95% CI per category
W, rowh, left, right = 640, 30, 230, 24
rows = order
H = 40 + rowh * len(rows) + 30
lo, hi = -0.4, 1.0
X = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
svg = [f'<svg viewBox="0 0 {W} {H}" class="forest" role="img" aria-label="Split-half reliability of referee tendencies by penalty type">']
for t in [-0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1.0]:
    svg.append(f'<line x1="{X(t):.1f}" x2="{X(t):.1f}" y1="28" y2="{H-26}" class="{"zero" if t == 0 else "grid"}"/>')
    svg.append(f'<text x="{X(t):.1f}" y="{H-8}" class="tick" text-anchor="middle">{t:.1f}</text>')
svg.append(f'<text x="{left}" y="16" class="axl">Odd-season vs even-season referee tendency, correlation</text>')
for i, k in enumerate(rows):
    y = 44 + i * rowh; v = R[k]; cls = '' if v['split_lo'] > 0 else ' b'
    svg.append(f'<text x="{left-12}" y="{y+4}" text-anchor="end" class="lab">{v["label"]}</text>')
    svg.append(f'<line x1="{X(v["split_lo"]):.1f}" x2="{X(v["split_hi"]):.1f}" y1="{y}" y2="{y}" class="ci{cls}"/>')
    svg.append(f'<circle cx="{X(v["split_r"]):.1f}" cy="{y}" r="4.5" class="pt{cls}"/>')
svg.append('</svg>')

top = eb.sort_values('eb', ascending=False).head(5); bot = eb.sort_values('eb').head(5)
eb_rows = [[x.referee, f'{int(x.first)}–{int(x.last)}', str(int(x['size'])), f'{x["mean"]:+.2f}', ci(x.eb, x.eb_se)]
           for _, x in pd.concat([top, bot.iloc[::-1]]).iterrows()]
over_rows = [[x.terc, f'{int(x.n):,}', f'{x.prior:+.2f}', f'{x.pen:.1f}', f'{x.total:.1f}', f'{x.line:.1f}', f'{pct(x.over)} [{pct(x.lo)}, {pct(x.hi)}]'] for _, x in to.iterrows()]
ats_rows = [[x.terc, f'{int(x.n):,}', f'{x.prior:+.3f}', f'{x["diff"]:+.2f}', f'{pct(x.cover)} [{pct(x.lo)}, {pct(x.hi)}]'] for _, x in ta.iterrows()]

pt = R['pen_total']; pdf = R['pen_diff']; m = mk
spec = {
 'slug': 'officiating-tendencies', 'module': 'Officiating Tendencies', 'status': 'null', 'status_label': 'Real for flags, not for scores',
 'title': 'Referee crews change the flag count, not the score',
 'question': 'Do NFL officiating crews introduce measurable variation beyond the teams themselves, and does it reach totals or spreads?',
 'lede': f'Across {r["games"]:,} NFL games from {r["seasons"][0]} to {r["seasons"][1]}, the referee in charge moves the penalty count by a small, repeatable amount. That tendency does not show up in points scored, totals or covers.',
 'scope': f'NFL · {r["seasons"][0]}–{r["seasons"][1]} · {r["n_refs40"]} referees with 40+ games', 'updated': '2026-10-17',
 'findings': [
   f'Crew differences in total flags are real. After removing both teams’ season-level tendencies, the spread between referees is about **{pt["ref_sd"]:.2f} flags per game** (one standard deviation) against a league average of {pt["mean"]:.1f}. Shuffling referee labels within seasons never produces a spread that large (permutation p = {pt["perm_p"]:.3f}).',
   f'The tendency repeats: a referee’s rate in odd seasons correlates {pt["split_r"]:.2f} with his rate in even seasons (95% CI {pt["split_lo"]:.2f} to {pt["split_hi"]:.2f}); season to season it is {pt["yy_r"]:.2f}.',
   f'The repeatable part is mostly offensive holding (split-half r {R["off_hold"]["split_r"]:.2f}), personal fouls ({R["unr"]["split_r"]:.2f}) and roughing the passer ({R["rtp"]["split_r"]:.2f}). Defensive pass interference shows no reliable crew pattern (r {R["dpi"]["split_r"]:.2f}, p = {R["dpi"]["perm_p"]:.2f}).',
   f'No crew treats road teams measurably differently. Home teams draw {abs(r["home_minus_away_mean"]):.2f} fewer flags per game league-wide, but the referee-level spread in that gap is indistinguishable from chance (p = {pdf["perm_p"]:.2f}, split-half r {pdf["split_r"]:.2f}).',
   f'A crew’s prior-season tendency does predict this season’s flags ({ci(m["pen_total~ref_prior_pen_total"]["b"], m["pen_total~ref_prior_pen_total"]["se"])} flags per flag of prior tendency), but not total points ({ci(m["total~ref_prior_pen_total"]["b"], m["total~ref_prior_pen_total"]["se"])}) or the result against the total ({ci(m["over_margin~ref_prior_pen_total"]["b"], m["over_margin~ref_prior_pen_total"]["se"])}).',
   f'Games with high-flag crews went over {pct(to.iloc[2].over)} of the time versus {pct(to.iloc[0].over)} for low-flag crews. Home teams covered {pct(ta.iloc[2].cover)} with crews that historically flag home teams more versus {pct(ta.iloc[0].cover)} with the opposite; neither gap is distinguishable from zero.'],
 'sections': [
   {'h': 'How much of the flag count belongs to the crew',
    'p': ['Each game’s penalty count is first adjusted for both teams’ season-long tendencies and for the season itself, so a crew is not credited for working a lot of undisciplined teams. The remaining variation is split into a referee part and game-to-game noise. The permutation test reshuffles referees within each season 1,000 times to see how much referee spread chance alone produces.'],
    'table': {'cols': ['Outcome', 'League mean / game', 'Referee SD', 'Share of variance', 'Permutation p', 'Split-half r [95% CI]', 'Year-to-year r'],
              'rows': var_rows, 'num': [1, 2, 3, 4, 5, 6],
              'caption': f'Referees with 40+ games ({r["n_refs40"]} referees, {r["games_ref40"]:,} games). Split-half compares each referee’s odd-season and even-season averages (referees with 20+ games in each half). Year-to-year uses referee-seasons with 8+ games.'}},
   {'h': 'Which penalty types repeat', 'svg': ''.join(svg),
    'p': ['A tendency is useful only if it repeats. Teal marks penalty types whose odd/even-season correlation is clearly above zero; amber marks those that could be noise.']},
   {'h': 'Referee tendencies, shrunk toward the league',
    'p': ['Raw career averages overstate differences for referees with few games, so each estimate is pulled toward zero in proportion to its noise (empirical Bayes). These are measured tendencies in flag counts, not judgments about accuracy or fairness.'],
    'table': {'cols': ['Referee', 'Seasons', 'Games', 'Raw vs expected', 'Shrunk estimate [95% CI]'], 'rows': eb_rows, 'num': [2, 3, 4],
              'caption': 'Flags per game relative to what the two teams and the season would predict. Top five and bottom five of 42 referees with 40+ games.'}},
   {'h': 'Does the market miss it?',
    'p': ['For every game from 2001 on, each referee’s tendency is computed from earlier seasons only, as it would have been known when the assignment was announced. Games are then split into thirds by that prior tendency.'],
    'tables': [{'cols': ['Prior flag tendency', 'Games', 'Prior tendency', 'Flags', 'Total points', 'Closing total', 'Over % [95% CI]'], 'rows': over_rows, 'num': [1, 2, 3, 4, 5, 6],
                'caption': 'Pushes excluded. Thirds are formed within each season.'},
               {'cols': ['Prior home-flag tendency', 'Games', 'Prior tendency', 'Home minus away flags', 'Home cover % [95% CI]'], 'rows': ats_rows, 'num': [1, 2, 3, 4],
                'caption': 'Positive tendency means the referee historically flagged home teams more than the teams predicted.'}],
    'after': [f'High-flag crews call about {to.iloc[2].pen - to.iloc[0].pen:.1f} more flags per game than low-flag crews, yet total points move by {to.iloc[2].total - to.iloc[0].total:+.1f} and the closing total by {to.iloc[2].line - to.iloc[0].line:+.1f}. Extra flags do not translate into extra points on average, which is why the market has nothing to price.']},
   {'h': 'Pass-heavy games',
    'p': [f'Pass-defense flags (pass interference, defensive holding, illegal contact, roughing the passer) were compared in games above and below the season’s median dropback rate. Referee effects in the two sets correlate {r["passing"]["corr"]:.2f} across {r["passing"]["n"]} referees, and the spread between referees is somewhat wider in pass-heavy games ({r["passing"]["sd_hi"]:.2f} vs {r["passing"]["sd_lo"]:.2f} flags, raw). Crews that call these fouls tightly do so regardless of game style, with a little more room to show it when there are more dropbacks.']}],
 'model_verdict': 'Not added to the model. Crew flag tendency is real and repeatable, so the assigned referee and his prior-season flag rate can appear as observed context on NFL game research. It does not predict points, totals or covers out of sample, so it does not move any fair line, probability or grade.',
 'data': [['Games', f'{r["games"]:,} NFL regular-season and playoff games {r["seasons"][0]}–{r["seasons"][1]} with a named referee ({r["n_refs"]} referees; {r["n_refs40"]} with 40+ games).'],
          ['Penalties', 'Penalty plays recorded in nflverse play-by-play, attributed to the penalized team; type from the play-by-play penalty_type field.'],
          ['Market lines', f'nflverse spread_line and total_line, tested on {r["market_games"]:,} games where the referee had 16+ earlier games. nflverse does not document capture time; treated as near-close consensus, not a licensed closing feed.'],
          ['Crew', 'The referee identifies the crew. Full seven-person crews exist only from 2015 and rotate partially, so they were not modeled separately.']],
 'gaps': [['College football', 'No public game-level officiating crew data for FBS was available, so this study is NFL only.'],
          ['Declined and offsetting flags', 'Play-by-play does not record every declined or offsetting flag consistently, so counts reflect recorded penalties.'],
          ['Crew members', 'Umpire, line judges and other crew members can matter for specific fouls; only the referee is modeled.']],
 'sources': [['nflverse schedules and lines', 'https://github.com/nflverse/nflverse-data/releases/tag/schedules'],
             ['nflverse play-by-play', 'https://github.com/nflverse/nflverse-data/releases/tag/pbp'],
             ['nflverse officials', 'https://github.com/nflverse/nflverse-data/releases/tag/officials']],
 'zip': 'edgedesk-officiating-tendencies.zip'}
json.dump(spec, open(OUT, 'w'), indent=1)
print('ok')
