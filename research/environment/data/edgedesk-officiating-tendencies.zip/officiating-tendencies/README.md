# EdgeDesk Study 4: Officiating Tendencies (NFL)

Question: do referee crews add measurable variation beyond the teams, and does it reach totals or spreads vs the market?

Files
- officiating.py: builds the game table from nflverse data, residualises penalties on team-season effects, variance components with a within-season permutation null, split-half and year-to-year reliability, empirical Bayes referee estimates, and the prior-season market test.
- make_spec.py: turns results into the EdgeDesk page spec.
- officiating_games.csv.gz: game-level dataset (one row per game).
- results.json, referee_eb_*.csv, terciles_*.csv: raw output.
- features.parquet: pre-game features from PRIOR seasons only (ref_prior_pen_total, ref_prior_pen_diff, ref_prior_games).

Reproduce: python3 officiating.py <scratch dir with shared/ and nfl/> <out dir>
Inputs: nflverse games.csv (referee, lines), nflverse play-by-play 1999-2025, shared team-game table built by research/common/build_nfl.py.
Note: play-by-play uses current franchise codes (LV, LAC, LA); games.csv codes OAK/SD/STL are remapped before joining.
