"""Study 4: NFL officiating tendencies.

Question: do referee crews add measurable variation in penalties beyond the teams, and does a
crew's PRIOR-season tendency move totals or spreads against the market line?

Crew identity = the referee (crew chief). nflverse games.csv names the referee for every game
1999-2025. Penalties = penalty plays recorded in nflverse play-by-play (penalty == 1 with a
penalty_team), attributed to the penalized team.

Usage: python3 officiating.py <S scratch dir> <out dir>
"""
import sys, json, numpy as np, pandas as pd, scipy.sparse as sp
from scipy.sparse.linalg import lsqr

S, OUT = sys.argv[1], sys.argv[2]
rng = np.random.default_rng(20261017)
FIX = {'Bill Vinocich': 'Bill Vinovich', 'Gene Stetatore': 'Gene Steratore'}  # one-off spelling errors

g = pd.read_parquet(f'{S}/shared/nfl_games.parquet')
g = g[g.referee.notna()].copy()
g['referee'] = g.referee.replace(FIX)
# nflverse play-by-play uses current franchise codes; games.csv uses historical ones
REMAP = {'OAK': 'LV', 'SD': 'LAC', 'STL': 'LA'}
g['home_team'] = g.home_team.replace(REMAP); g['away_team'] = g.away_team.replace(REMAP)
tg = pd.read_parquet(f'{S}/shared/nfl_team_games.parquet')

# ---------- penalty types from raw PBP ----------
TYPES = {'dpi': ['Defensive Pass Interference'], 'off_hold': ['Offensive Holding'],
         'def_hold': ['Defensive Holding', 'Illegal Contact'], 'rtp': ['Roughing the Passer'],
         'unr': ['Unnecessary Roughness', 'Unsportsmanlike Conduct', 'Taunting', 'Face Mask', 'Personal Foul'],
         'pre_snap': ['False Start', 'Defensive Offside', 'Neutral Zone Infraction', 'Encroachment', 'Delay of Game']}
rows = []
for y in range(1999, 2026):
    p = pd.read_parquet(f'{S}/nfl/pbp/{y}.parquet', columns=['game_id', 'penalty', 'penalty_type', 'penalty_team', 'home_team'])
    p = p[(p.penalty == 1) & p.penalty_team.notna()]
    d = pd.DataFrame({'game_id': p.game_id, 'home': p.penalty_team == p.home_team})
    for k, v in TYPES.items():
        d[k] = p.penalty_type.isin(v).astype(int)
    rows.append(d.groupby('game_id').agg(**{k: (k, 'sum') for k in TYPES}).reset_index())
ty = pd.concat(rows)
g = g.merge(ty, on='game_id', how='left')
for k in TYPES:
    g[k] = g[k].fillna(0)

h = tg.rename(columns={'team': 'home_team'})[['game_id', 'home_team', 'pen', 'pen_yds', 'plays', 'dropbacks']]
a = tg.rename(columns={'team': 'away_team'})[['game_id', 'away_team', 'pen', 'pen_yds', 'plays', 'dropbacks']]
g = g.merge(h.add_prefix('h_').rename(columns={'h_game_id': 'game_id', 'h_home_team': 'home_team'}), on=['game_id', 'home_team'], how='left')
g = g.merge(a.add_prefix('a_').rename(columns={'a_game_id': 'game_id', 'a_away_team': 'away_team'}), on=['game_id', 'away_team'], how='left')
g = g.dropna(subset=['h_pen', 'a_pen'])
g['pen_total'] = g.h_pen + g.a_pen
g['pen_yds_total'] = g.h_pen_yds + g.a_pen_yds
g['pen_diff'] = g.h_pen - g.a_pen                     # home minus away flags (>0: home flagged more)
g['plays_total'] = g.h_plays + g.a_plays
g['pen_per100'] = 100 * g.pen_total / g.plays_total
g['pass_rate_game'] = (g.h_dropbacks + g.a_dropbacks) / g.plays_total

# ---------- residualise on team-season strength ----------
def resid(d, y, signed=False):
    hts = d.home_team + '_' + d.season.astype(str); ats = d.away_team + '_' + d.season.astype(str)
    cats = pd.Index(pd.unique(pd.concat([hts, ats]))); r = np.arange(len(d))
    sgn = -1.0 if signed else 1.0
    Z = sp.csr_matrix((np.r_[np.ones(len(d)), sgn * np.ones(len(d))], (np.r_[r, r], np.r_[cats.get_indexer(hts), cats.get_indexer(ats)])),
                      shape=(len(d), len(cats)))
    yr = pd.get_dummies(d.season, dtype=float).to_numpy()
    post = (d.game_type != 'REG').astype(float).to_numpy()[:, None]
    X = sp.hstack([Z, sp.csr_matrix(yr), sp.csr_matrix(post)]).tocsr() if not signed else sp.hstack([Z, sp.csr_matrix(np.ones((len(d), 1))), sp.csr_matrix(post)]).tocsr()
    v = d[y].to_numpy(float)
    return v - X @ lsqr(X, v, atol=1e-10, btol=1e-10, iter_lim=50000)[0]

OUTCOMES = {'pen_total': ('Penalties per game, both teams', False), 'pen_yds_total': ('Penalty yards per game', False),
            'pen_diff': ('Home minus away penalties', True), 'dpi': ('Defensive pass interference', False),
            'off_hold': ('Offensive holding', False), 'def_hold': ('Defensive holding / illegal contact', False),
            'rtp': ('Roughing the passer', False), 'unr': ('Personal fouls / conduct', False), 'pre_snap': ('Pre-snap fouls', False)}
for y, (_, sg) in OUTCOMES.items():
    g[f'r_{y}'] = resid(g, y, signed=sg)

MIN = 40
refn = g.referee.value_counts(); keep = refn[refn >= MIN].index
G = g[g.referee.isin(keep)].copy()

def var_comp(d, col):
    m = d.groupby('referee')[col].agg(['mean', 'var', 'size'])
    s2 = d[col].var()  # within variance approx
    within = d.groupby('referee')[col].var().mean()
    obs = m['mean'].var(ddof=1)
    noise = (within / m['size']).mean()
    tau2 = max(obs - noise, 0.0)
    # weighted F-like statistic: between-referee sum of squares
    stat = (m['size'] * (m['mean'] - d[col].mean()) ** 2).sum() / (len(m) - 1) / within
    return tau2, stat, within, m

def perm_p(d, col, B=1000):
    _, s0, _, _ = var_comp(d, col)
    vals = d[col].to_numpy(); seasons = d.season.to_numpy(); refs = d.referee.to_numpy()
    idx_by_season = [np.where(seasons == s)[0] for s in np.unique(seasons)]
    cnt = 0; null = []
    for _ in range(B):
        pr = refs.copy()
        for ix in idx_by_season:
            pr[ix] = refs[rng.permutation(ix)]
        dd = pd.DataFrame({'referee': pr, col: vals})
        m = dd.groupby('referee')[col].agg(['mean', 'size']); within = dd.groupby('referee')[col].var().mean()
        st = (m['size'] * (m['mean'] - vals.mean()) ** 2).sum() / (len(m) - 1) / within
        null.append(st); cnt += st >= s0
    return (cnt + 1) / (B + 1), float(np.percentile(null, 95))

def split_half(d, col):
    d = d.assign(half=np.where(d.season % 2 == 1, 'odd', 'even'))
    m = d.groupby(['referee', 'half'])[col].agg(['mean', 'size']).unstack('half')
    m = m[(m[('size', 'odd')] >= 20) & (m[('size', 'even')] >= 20)]
    x, y = m[('mean', 'odd')].to_numpy(), m[('mean', 'even')].to_numpy()
    r = np.corrcoef(x, y)[0, 1]
    bs = []
    for _ in range(2000):
        i = rng.integers(0, len(x), len(x)); bs.append(np.corrcoef(x[i], y[i])[0, 1])
    return r, np.nanpercentile(bs, 2.5), np.nanpercentile(bs, 97.5), len(x)

def year_to_year(d, col):
    m = d.groupby(['referee', 'season'])[col].agg(['mean', 'size']).reset_index()
    m = m[m['size'] >= 8]
    nx = m.assign(season=m.season - 1).rename(columns={'mean': 'next', 'size': 'nn'})
    j = m.merge(nx, on=['referee', 'season'])
    return np.corrcoef(j['mean'], j['next'])[0, 1], len(j)

res = {}
for y, (lab, _) in OUTCOMES.items():
    col = f'r_{y}'
    tau2, stat, within, m = var_comp(G, col)
    p, null95 = perm_p(G, col, B=1000 if y in ('pen_total', 'pen_diff') else 400)
    sh = split_half(G, col); yy = year_to_year(G, col)
    res[y] = dict(label=lab, mean=float(g[y].mean()), sd_game=float(np.sqrt(within)), ref_sd=float(np.sqrt(tau2)),
                  ref_share=float(tau2 / (tau2 + within)), stat=float(stat), null95=null95, perm_p=float(p),
                  split_r=float(sh[0]), split_lo=float(sh[1]), split_hi=float(sh[2]), split_n=int(sh[3]),
                  yy_r=float(yy[0]), yy_n=int(yy[1]))
    print(y, {k: round(v, 3) if isinstance(v, float) else v for k, v in res[y].items()}, flush=True)

# ---------- empirical Bayes referee estimates (career, for display) ----------
def eb(d, col, tau2):
    m = d.groupby('referee')[col].agg(['mean', 'size', 'var']); w = d.groupby('referee')[col].var().mean()
    se2 = w / m['size']; shrink = tau2 / (tau2 + se2)
    m['eb'] = shrink * m['mean']; m['eb_se'] = np.sqrt(shrink * se2)
    m['first'] = d.groupby('referee').season.min(); m['last'] = d.groupby('referee').season.max()
    return m.sort_values('eb')
ebt = {y: eb(G, f'r_{y}', res[y]['ref_sd'] ** 2) for y in ['pen_total', 'pen_diff', 'dpi']}

# ---------- pass-heavy games: does the crew effect on pass-defense flags grow with dropbacks? ----------
G['pass_def_flags'] = G.dpi + G.def_hold + G.rtp
G['r_pdf'] = resid(G, 'pass_def_flags')
G['hi_pass'] = G.pass_rate_game > G.groupby('season').pass_rate_game.transform('median')
hp = G.groupby(['referee', 'hi_pass']).r_pdf.agg(['mean', 'size']).unstack('hi_pass')
hp = hp[(hp[('size', True)] >= 20) & (hp[('size', False)] >= 20)]
pass_corr = float(np.corrcoef(hp[('mean', True)], hp[('mean', False)])[0, 1])
pass_sd_hi = float(hp[('mean', True)].std()); pass_sd_lo = float(hp[('mean', False)].std())
pass_n = int(len(hp))

# ---------- market test: prior-season referee tendency -> this season ----------
feat = []
for s in range(2001, 2026):
    prior = g[(g.season < s) & g.referee.notna()]
    cur = g[g.season == s][['game_id', 'season', 'referee']]
    out = cur.copy()
    for y, tau_key in [('pen_total', 'pen_total'), ('pen_diff', 'pen_diff')]:
        col = f'r_{y}'
        m = prior.groupby('referee')[col].agg(['mean', 'size'])
        w = prior[col].var()
        tau2 = res[tau_key]['ref_sd'] ** 2   # NOTE: tau from full sample would leak; recompute from prior
        mm = prior[prior.referee.isin(m[m['size'] >= 16].index)]
        if len(mm):
            mg = mm.groupby('referee')[col].agg(['mean', 'size']); wi = mm.groupby('referee')[col].var().mean()
            tau2 = max(mg['mean'].var() - (wi / mg['size']).mean(), 0.0)
        shrink = tau2 / (tau2 + w / m['size'])
        out[f'ref_prior_{y}'] = out.referee.map(shrink * m['mean']).fillna(0.0)
        out['ref_prior_games'] = out.referee.map(m['size']).fillna(0).astype(int)
    feat.append(out)
F = pd.concat(feat, ignore_index=True)
M = g.merge(F.drop(columns=['referee']), on=['game_id', 'season'])
M = M[M.ref_prior_games >= 16]

def ols_cl(y, X, cl):
    X = np.column_stack([np.ones(len(X)), X]); XtX = np.linalg.pinv(X.T @ X); b = XtX @ X.T @ y; u = y - X @ b
    meat = np.zeros((X.shape[1],) * 2); G_ = 0
    for c in np.unique(cl):
        k = cl == c; s_ = X[k].T @ u[k]; meat += np.outer(s_, s_); G_ += 1
    V = G_ / (G_ - 1) * XtX @ meat @ XtX
    return b, np.sqrt(np.diag(V))

mk = {}
for out_col, xcol in [('pen_total', 'ref_prior_pen_total'), ('pen_diff', 'ref_prior_pen_diff'), ('total', 'ref_prior_pen_total'),
                      ('over_margin', 'ref_prior_pen_total'), ('home_ats', 'ref_prior_pen_diff'), ('total_line', 'ref_prior_pen_total')]:
    d = M.dropna(subset=[out_col, xcol])
    b, se = ols_cl(d[out_col].to_numpy(float), d[[xcol]].to_numpy(float), d.referee.to_numpy())
    mk[f'{out_col}~{xcol}'] = dict(b=float(b[1]), se=float(se[1]), n=int(len(d)))
# terciles of prior flag tendency: over rate
d = M.dropna(subset=['over_margin']).copy()
d['terc'] = d.groupby('season').ref_prior_pen_total.transform(lambda s: pd.qcut(s.rank(method='first'), 3, labels=['Low-flag crews', 'Middle', 'High-flag crews']))
terc = d[d.over_margin != 0].groupby('terc', observed=True).agg(n=('game_id', 'size'), over=('over_margin', lambda s: (s > 0).mean()),
        pen=('pen_total', 'mean'), total=('total', 'mean'), line=('total_line', 'mean'), prior=('ref_prior_pen_total', 'mean'))
d2 = M.dropna(subset=['home_ats']).copy()
d2['terc'] = d2.groupby('season').ref_prior_pen_diff.transform(lambda s: pd.qcut(s.rank(method='first'), 3, labels=['Home flagged less', 'Middle', 'Home flagged more']))
terc2 = d2[d2.home_ats != 0].groupby('terc', observed=True).agg(n=('game_id', 'size'), cover=('home_ats', lambda s: (s > 0).mean()),
        diff=('pen_diff', 'mean'), prior=('ref_prior_pen_diff', 'mean'))

# wilson CI helper for tercile rates
def wil(p, n, z=1.96):
    den = 1 + z * z / n; c = (p + z * z / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return c - h, c + h

summary = dict(games=int(len(g)), games_ref40=int(len(G)), n_refs40=int(G.referee.nunique()), n_refs=int(g.referee.nunique()),
               seasons=[int(g.season.min()), int(g.season.max())], res=res, market=mk,
               passing=dict(corr=pass_corr, sd_hi=pass_sd_hi, sd_lo=pass_sd_lo, n=pass_n),
               market_games=int(len(M)), mean_pen=float(g.pen_total.mean()),
               home_minus_away_mean=float(g.pen_diff.mean()))
json.dump(summary, open(f'{OUT}/results.json', 'w'), indent=1)
terc.assign(lo=[wil(p, n)[0] for p, n in zip(terc.over, terc.n)], hi=[wil(p, n)[1] for p, n in zip(terc.over, terc.n)]).to_csv(f'{OUT}/terciles_over.csv')
terc2.assign(lo=[wil(p, n)[0] for p, n in zip(terc2.cover, terc2.n)], hi=[wil(p, n)[1] for p, n in zip(terc2.cover, terc2.n)]).to_csv(f'{OUT}/terciles_ats.csv')
for y, t in ebt.items():
    t.to_csv(f'{OUT}/referee_eb_{y}.csv')
keepcols = ['game_id', 'season', 'week', 'game_type', 'home_team', 'away_team', 'referee', 'h_pen', 'a_pen', 'pen_total', 'pen_yds_total', 'pen_diff',
            'plays_total', 'pass_rate_game'] + list(TYPES) + [f'r_{y}' for y in OUTCOMES] + ['total', 'total_line', 'over_margin', 'spread_line', 'result', 'home_ats']
g[keepcols].to_csv(f'{OUT}/officiating_games.csv.gz', index=False)
F['sport'] = 'NFL'
F[['sport', 'game_id', 'season', 'ref_prior_pen_total', 'ref_prior_pen_diff', 'ref_prior_games']].to_parquet(f'{OUT}/features.parquet')
print(json.dumps(mk, indent=0)); print(terc); print(terc2); print(summary['passing'])
