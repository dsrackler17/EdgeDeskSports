"""Study 1: Travel & Circadian (NFL 1999-2025, CFB 2001-2021).

Treatment definitions (visitor perspective):
  tz_shift      venue UTC offset minus visitor home-stadium UTC offset on game day (DST-aware).
                + = visitor travelled EAST (clock jumps forward), - = WEST.
  ko_body       kickoff hour on the visitor's home clock (24h).
  early_body    ko_body < 11.5  (e.g. 1:00 p.m. ET kickoff for a Pacific team = 10:00 body clock)
  night_local   kickoff at or after 7:00 p.m. Eastern (night window); crossed with east/west travel
                so a west-coast visitor at a night game plays earlier on its body clock
Outcomes (visitor side): margin, 1H/2H/Q4 margin, margin vs market spread (ATS).
Models: signed team-season fixed effects (strength) + controls, partialled with sparse LSQR (FWL).
        ATS models are run both with controls only (market baseline) and with FE.
SEs clustered by home team (NFL) / host venue (CFB); wild-cluster bootstrap p for headline terms.
"""
import sys, json, numpy as np, pandas as pd, scipy.sparse as sp
from scipy.sparse.linalg import lsqr
from zoneinfo import ZoneInfo
import datetime as dt

S = sys.argv[1]; OUT = sys.argv[2]
rng_seed = 11

# ------------------------------------------------------------------ helpers
def cl_vcov(X, u, cl, k_abs):
    n, k = X.shape
    XtX_inv = np.linalg.pinv(X.T @ X)
    ucl, inv = np.unique(cl, return_inverse=True); G = len(ucl)
    Sg = np.zeros((G, k)); np.add.at(Sg, inv, X * u[:, None])
    adj = G / (G - 1) * (n - 1) / max(n - k - k_abs, 1)
    return adj * XtX_inv @ (Sg.T @ Sg) @ XtX_inv, G

def wild_p(y, X, j, cl, B=999):
    rng = np.random.default_rng(rng_seed)
    ucl, inv = np.unique(cl, return_inverse=True); G = len(ucl)
    XtX_inv = np.linalg.pinv(X.T @ X)
    def t(yy):
        b = XtX_inv @ X.T @ yy; u = yy - X @ b
        Sg = np.zeros((G, X.shape[1])); np.add.at(Sg, inv, X * u[:, None])
        V = XtX_inv @ (Sg.T @ Sg) @ XtX_inv
        return b[j] / np.sqrt(V[j, j])
    t0 = t(y)
    Xr = np.delete(X, j, axis=1); fit = Xr @ np.linalg.lstsq(Xr, y, rcond=None)[0]; ur = y - fit
    ts = np.array([t(fit + ur * rng.choice([-1.0, 1.0], G)[inv]) for _ in range(B)])
    return float((np.abs(ts) >= abs(t0)).mean())

def fit(d, y, xs, fe, cl, label, wild_terms=(), contrasts=()):
    d = d.dropna(subset=[y] + xs).reset_index(drop=True)
    Y = d[y].to_numpy(float); X = d[xs].to_numpy(float)
    X = X - X.mean(0); X = np.column_stack([np.ones(len(d)), X]); kabs = 0
    if fe:
        hts = d.home_key.astype(str) + '_' + d.season.astype(str)
        ats = d.away_key.astype(str) + '_' + d.season.astype(str)
        cats = pd.Index(pd.unique(pd.concat([hts, ats]))); r = np.arange(len(d))
        Z = sp.csr_matrix((np.r_[np.ones(len(d)), -np.ones(len(d))], (np.r_[r, r], np.r_[cats.get_indexer(hts), cats.get_indexer(ats)])),
                          shape=(len(d), len(cats)))
        res = lambda v: v - Z @ lsqr(Z, v, atol=1e-8, btol=1e-8, iter_lim=5000)[0]
        Y = res(Y); X = np.column_stack([res(X[:, j]) for j in range(X.shape[1])]); kabs = len(cats) - 1
    b = np.linalg.pinv(X.T @ X) @ X.T @ Y; u = Y - X @ b
    clv = d[cl].to_numpy()
    V, G = cl_vcov(X, u, clv, kabs)
    names = ['intercept'] + xs
    out = dict(label=label, outcome=y, n=int(len(d)), clusters=int(G), fe=fe,
               coefs={nm: [float(b[i]), float(np.sqrt(V[i, i]))] for i, nm in enumerate(names) if not nm.startswith(('yr_', 'wk_'))},
               cell_n={nm: int(d[nm].sum()) for nm in xs if set(np.unique(d[nm])) <= {0, 1}}, wild={}, contrasts={})
    for t in wild_terms:
        if t in xs:
            out['wild'][t] = wild_p(Y, X, 1 + xs.index(t), clv)
    for a, c in contrasts:
        if a in xs and c in xs:
            i, j = 1 + xs.index(a), 1 + xs.index(c)
            diff = b[i] - b[j]; se = np.sqrt(V[i, i] + V[j, j] - 2 * V[i, j])
            out['contrasts'][f'{a}-{c}'] = [float(diff), float(se)]
    return out

def tz_off(tz, day):
    try:
        return ZoneInfo(tz).utcoffset(dt.datetime.combine(day, dt.time(12))).total_seconds() / 3600
    except Exception:
        return np.nan

# ------------------------------------------------------------------ NFL panel
g = pd.read_parquet(f'{S}/shared/nfl_games.parquet')
n = g[g.location == 'Home'].copy()
n['home_key'], n['away_key'] = n.home_team, n.away_team
n['v_margin'] = -n.result
n['v_ats'] = -(n.result - n.spread_line)
n['v_margin_1h'] = -n.home_margin_h1; n['v_margin_2h'] = -n.home_margin_h2; n['v_margin_q4'] = -n.home_margin_q4
n['tz_shift'] = n.away_tz_shift.round()
n['ko_body'] = n.ko_away_body
n['travel_mi'] = n.away_travel_mi
n['rest_diff'] = (n.home_rest.clip(upper=15) - n.away_rest.clip(upper=15))
n['playoff'] = (n.game_type != 'REG').astype(float)
n['div'] = n.div_game.astype(float)
n['indoor'] = n.roof.isin(['dome', 'closed']).astype(float)
n['cluster'] = n.home_team
n['era'] = np.where(n.season >= 2012, 'post', 'pre')
nfl = n

# ------------------------------------------------------------------ CFB panel
p = pd.read_parquet(f'{S}/panel.parquet')
c = p[p['sample'] == 'verified_venue_2001_2021'].copy()
c['ko'] = pd.to_datetime(c.start_date, utc=True)
c['ko_utc_h'] = c.ko.dt.hour + c.ko.dt.minute / 60
days = c.ko.dt.tz_convert('America/New_York').dt.date
c['v_off'] = [tz_off(t, d) for t, d in zip(c.g_tz, days)]
c['a_off'] = [tz_off(t, d) for t, d in zip(c.vh_tz, days)]
c['tz_shift'] = (c.v_off - c.a_off).round()
c['ko_body'] = (c.ko_utc_h + c.a_off) % 24
c['ko_venue_local'] = (c.ko_utc_h + c.v_off) % 24
c['ko_et'] = (c.ko_utc_h + [tz_off('America/New_York', d) for d in days]) % 24
c['utc_midnight'] = (c.ko.dt.hour == 0) & (c.ko.dt.minute == 0)
c['home_key'], c['away_key'] = c.home_id.astype(int), c.away_id.astype(int)
c['travel_mi'] = c.travel_mi
c['rest_diff'] = c.home_rest.clip(upper=21) - c.away_rest.clip(upper=21)
c['playoff'] = 0.0; c['div'] = c.get('conference_game', pd.Series(False, index=c.index)).fillna(False).astype(float)
c['indoor'] = c.dome.astype(float)
c['cluster'] = c.venue_id
c['era'] = np.where(c.season >= 2012, 'post', 'pre')
# keep only rows where the PBP split exists for half outcomes (v_margin_1h etc. are NaN otherwise)
for col in ['v_margin_1h', 'v_margin_2h', 'v_margin_q4']:
    c.loc[~c.pbp_ok.fillna(False).astype(bool), col] = np.nan
cfb = c

# ------------------------------------------------------------------ treatment design
def design(d):
    d = d.copy()
    s = d.tz_shift
    d['east2'] = (s >= 2).astype(float); d['east1'] = (s == 1).astype(float)
    d['west1'] = (s == -1).astype(float); d['west2'] = (s <= -2).astype(float)
    d['early_body'] = (d.ko_body < 11.5).astype(float)
    d['night_body'] = (d.ko_body >= 19.5).astype(float)
    d['night_local'] = (d.ko_et >= 19.0).astype(float)   # national night window: kickoff 7:00 p.m. ET or later
    d['east2_early'] = d.east2 * d.early_body
    d['east2_night'] = d.east2 * d.night_local
    d['west2_night'] = d.west2 * d.night_local
    d['west2_early'] = d.west2 * d.early_body
    # cell design: each travel cell vs same-time-zone games in the same broad window
    day = (1 - d.early_body) * (1 - d.night_local)
    d['east2_day'] = d.east2 * day
    d['west2_day'] = d.west2 * (1 - d.night_local)
    d['night_pair_diff'] = d.east2_night - d.west2_night
    d['night_pair_sum'] = d.east2_night + d.west2_night
    d['log_travel'] = np.log1p(d.travel_mi)
    d['far'] = (d.travel_mi >= 1500).astype(float)
    for y in sorted(d.season.unique())[1:]:
        d[f'yr_{y}'] = (d.season == y).astype(float)
    return d

nfl = design(nfl.dropna(subset=['ko_body', 'tz_shift', 'travel_mi']))
cfb = design(cfb.dropna(subset=['ko_body', 'tz_shift', 'travel_mi']))

TERMS = ['east1', 'west1', 'east2_early', 'east2_day', 'east2_night', 'west2_day', 'west2_night', 'night_local']
PAIR = ['east1', 'west1', 'east2_early', 'east2_day', 'west2_day', 'night_pair_diff', 'night_pair_sum', 'night_local']
CTRL = ['log_travel', 'rest_diff', 'div', 'playoff', 'indoor']
CON = [('east2_night', 'west2_night'), ('east2_early', 'east2_day'), ('east2_day', 'west2_day')]
WT = ['east2_early', 'east2_day', 'east2_night', 'west2_day', 'west2_night']

R = {'models': [], 'cells': {}, 'coverage': {}}
for sport, d in [('NFL', nfl), ('CFB', cfb)]:
    yr = [x for x in d.columns if x.startswith('yr_')]
    ctrl = CTRL if sport == 'NFL' else ['log_travel', 'rest_diff', 'div', 'indoor']
    dd = d if sport == 'NFL' else d.assign(rest_diff=d.rest_diff.fillna(0), rest_missing=d.rest_diff.isna().astype(float))
    if sport == 'CFB':
        ctrl = ctrl + ['rest_missing']
    xs = TERMS + ctrl + yr
    for y in ['v_margin', 'v_margin_1h', 'v_margin_2h', 'v_margin_q4']:
        R['models'].append(dict(sport=sport, spec='FE+controls', **fit(dd, y, xs, True, 'cluster', f'{sport}|FE|{y}',
                                                                       wild_terms=WT if y == 'v_margin' else (), contrasts=CON)))
    print(sport, 'FE done', flush=True)
    R['models'].append(dict(sport=sport, spec='market', **fit(dd, 'v_ats', xs, False, 'cluster', f'{sport}|market|v_ats', wild_terms=WT, contrasts=CON)))
    # night asymmetry as one parameter (coef = half the east-minus-west night gap) for a wild-bootstrap p
    for y, fe, spec in [('v_margin', True, 'pair_FE'), ('v_ats', False, 'pair_market')]:
        R['models'].append(dict(sport=sport, spec=spec, **fit(dd, y, PAIR + ctrl + yr, fe, 'cluster', f'{sport}|{spec}|{y}', wild_terms=['night_pair_diff'])))
    R['models'].append(dict(sport=sport, spec='market+FE', **fit(dd, 'v_ats', xs, True, 'cluster', f'{sport}|marketFE|v_ats', contrasts=CON)))
    # era split (does the effect shrink as markets learn?)
    for era in ['pre', 'post']:
        de = dd[dd.era == era]
        yr_e = [x for x in yr if de[x].sum() > 0]
        for y, fe, spec in [('v_margin', True, 'FE+controls'), ('v_ats', False, 'market')]:
            R['models'].append(dict(sport=sport, spec=f'{spec}|{era}', **fit(de, y, TERMS + ctrl + yr_e, fe, 'cluster', f'{sport}|{spec}|{era}|{y}', contrasts=CON, wild_terms=['east2_early', 'east2_night', 'west2_night'])))
    if sport == 'CFB':  # robustness: drop exact 00:00 UTC kickoffs (possible placeholder times)
        dr = dd[~dd.utc_midnight]
        R['models'].append(dict(sport=sport, spec='FE+controls|no_utc_midnight', **fit(dr, 'v_margin', xs, True, 'cluster', 'CFB|FE|nomid|v_margin', contrasts=CON)))
    # matched-distance east vs west cells (raw, controls only; ATS)
    cells = []
    d2 = dd.copy()
    d2['dbin'] = pd.cut(d2.travel_mi, [0, 500, 1500, 1e9], labels=['<500 mi', '500-1,499 mi', '1,500+ mi'], right=False)
    d2['dir'] = np.select([d2.tz_shift >= 1, d2.tz_shift <= -1], ['east', 'west'], 'none')
    for (b, di), x in d2.groupby(['dbin', 'dir'], observed=True):
        if di == 'none':
            continue
        cells.append(dict(dist=str(b), dir=di, n=int(len(x)), v_margin=float(x.v_margin.mean()), n_lines=int(x.v_ats.notna().sum()),
                          v_ats=float(x.v_ats.mean()), cover=float((x.v_ats > 0).sum() / max(((x.v_ats > 0) | (x.v_ats < 0)).sum(), 1))))
    R['cells'][sport] = cells
    # classic cell: visitor shifted +2/+3 east, by body-clock kickoff band
    band = pd.cut(dd.ko_body, [0, 11.5, 15.5, 19.5, 24], labels=['before 11:30 body', '11:30-15:30', '15:30-19:30', '19:30 or later'], right=False)
    for grp, nm in [(dd.east2 == 1, 'east2'), (dd.west2 == 1, 'west2'), ((dd.tz_shift == 0), 'same_tz')]:
        rows = []
        for bnd, x in dd[grp].groupby(band[grp], observed=True):
            dec = x.v_ats.dropna(); dec = dec[dec != 0]
            rows.append(dict(band=str(bnd), n=int(len(x)), v_margin=float(x.v_margin.mean()), n_lines=int(len(dec)),
                             cover=float((dec > 0).mean()) if len(dec) else None, v_ats=float(x.v_ats.mean())))
        R['cells'][f'{sport}_{nm}_band'] = rows
    R['coverage'][sport] = dict(games=int(len(dd)), seasons=[int(dd.season.min()), int(dd.season.max())],
                                lines=int(dd.v_ats.notna().sum()), half_splits=int(dd.v_margin_2h.notna().sum()),
                                east2=int(dd.east2.sum()), west2=int(dd.west2.sum()), east2_early=int(dd.east2_early.sum()),
                                east2_night=int(dd.east2_night.sum()), west2_night=int(dd.west2_night.sum()))

# ------------------------------------------------------------------ NFL recovery: the game after a long trip
tg = pd.read_parquet(f'{S}/shared/nfl_games.parquet')
tg = tg[tg.game_type == 'REG']
rows = []
for side, opp in [('home', 'away'), ('away', 'home')]:
    x = tg[['game_id', 'season', 'week', 'gameday', f'{side}_team', f'{opp}_team', 'result', 'spread_line', f'{side}_tz_shift', f'{side}_travel_mi', f'{side}_rest', f'{opp}_rest', 'location']].copy()
    x.columns = ['game_id', 'season', 'week', 'gameday', 'team', 'opp', 'result', 'spread_line', 'tz_shift', 'travel_mi', 'rest', 'opp_rest', 'location']
    sgn = 1 if side == 'home' else -1
    x['margin'] = sgn * x.result; x['ats'] = sgn * (x.result - x.spread_line); x['is_home'] = float(side == 'home')
    rows.append(x)
tl = pd.concat(rows).sort_values(['team', 'gameday'])
tl['prev_tz'] = tl.groupby(['team', 'season']).tz_shift.shift().abs()
tl['prev_mi'] = tl.groupby(['team', 'season']).travel_mi.shift()
tl['prev_long'] = ((tl.prev_tz >= 2) | (tl.prev_mi >= 1500)).astype(float)
tl['rest_diff'] = tl.rest.clip(upper=15) - tl.opp_rest.clip(upper=15)
tl = tl.dropna(subset=['prev_tz'])
# team-game FE style: regress ATS (market) and margin with team-season and opponent-season dummies via pyfixest
import pyfixest as pf
tl['ts'] = tl.team + '_' + tl.season.astype(str); tl['os'] = tl.opp + '_' + tl.season.astype(str)
for yv in ['margin', 'ats']:
    fe = ' | ts + os' if yv == 'margin' else ''
    f = pf.feols(f'{yv} ~ prev_long + is_home + rest_diff{fe}', data=tl, vcov={'CRV1': 'team'})
    tb = f.tidy()
    R['models'].append(dict(sport='NFL', spec='recovery', label=f'NFL|recovery|{yv}', outcome=yv, n=int(f._N), clusters=int(tl.team.nunique()), fe=yv == 'margin',
                            coefs={k: [float(tb.loc[k, 'Estimate']), float(tb.loc[k, 'Std. Error'])] for k in tb.index},
                            cell_n={'prev_long': int(tl.prev_long.sum())}, wild={}, contrasts={}))

json.dump(R, open(f'{OUT}/results.json', 'w'), indent=1)
keep = ['game_id', 'season', 'week', 'home_key', 'away_key', 'tz_shift', 'ko_body', 'travel_mi', 'rest_diff', 'v_margin', 'v_ats',
        'v_margin_1h', 'v_margin_2h', 'v_margin_q4', 'east2', 'west2', 'early_body', 'night_body', 'night_local']
pd.concat([nfl[keep].assign(sport='NFL'), cfb[keep].assign(sport='CFB')]).to_csv(f'{OUT}/travel_games.csv.gz', index=False)

# ------------------------------------------------------------------ pre-game feature file (no outcomes)
fn = nfl[['game_id', 'season']].copy(); fn['sport'] = 'NFL'
fn['away_tz_shift'] = nfl.tz_shift; fn['away_travel_mi'] = nfl.travel_mi; fn['home_travel_mi'] = nfl.home_travel_mi
fn['ko_away_body'] = nfl.ko_body; fn['rest_diff'] = nfl.rest_diff
fn['visitor_early_body'] = nfl.early_body; fn['visitor_night_body'] = nfl.night_body
fn['visitor_east2_early'] = nfl.east2_early; fn['night_local'] = nfl.night_local
fc = cfb[['game_id', 'season']].copy(); fc['sport'] = 'CFB'; fc['game_id'] = fc.game_id.astype('int64').astype(str)
fc['away_tz_shift'] = cfb.tz_shift; fc['away_travel_mi'] = cfb.travel_mi; fc['home_travel_mi'] = 0.0
fc['ko_away_body'] = cfb.ko_body; fc['rest_diff'] = cfb.rest_diff
fc['visitor_early_body'] = cfb.early_body; fc['visitor_night_body'] = cfb.night_body; fc['visitor_east2_early'] = cfb.east2_early; fc['night_local'] = cfb.night_local
feat = pd.concat([fn, fc], ignore_index=True); feat['game_id'] = feat.game_id.astype(str)
feat.to_parquet('/home/claude/research/features/travel-circadian.parquet', index=False)
print('done', {k: v for k, v in R['coverage'].items()})
