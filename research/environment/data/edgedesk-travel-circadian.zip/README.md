# EdgeDesk study: Travel & Circadian

Question: does a West Coast team traveling east for an early Eastern kickoff perform differently
from a team traveling the same distance west, and does the betting line already price it?

## Files
- analysis.py: builds the NFL and CFB travel panels and runs every model. Writes out/results.json and out/travel_games.csv.gz.
- make_spec.py: turns the results into the EdgeDesk study page spec. No numbers are typed by hand.
- out/results.json: every coefficient, standard error, cell count, wild-bootstrap p-value and contrast.
- out/travel_games.csv.gz: the game-level dataset with treatments and outcomes.

## Definitions (visitor side)
- tz_shift: venue UTC offset minus the visitor's home-stadium UTC offset on the game date (DST-aware). Positive = travelled east.
- ko_body: kickoff hour on the visitor's home clock. early = before 11:30.
- night: kickoff 7:00 p.m. Eastern or later.
- Cells: east2 = 2-3 zones east (early / afternoon / night), west2 = 2-3 zones west (day / night), east1, west1. Baseline = same-time-zone visitors.
- Outcomes: visitor margin, 1H / 2H / Q4 margin, margin vs the market spread.

## Models
- "vs ratings": team-season strength for each side estimated jointly (signed fixed effects, partialled out with sparse LSQR), plus log travel, rest difference, division, playoff, roof and season controls.
- "vs spread": the same controls without ratings, on the margin against the line.
- SEs clustered by home team (NFL) or host venue (CFB). Wild-cluster bootstrap (Rademacher, 999 draws) p-values for the headline cells.
- Era split: 2000-2011 vs 2012-2025 (CFB 2001-2011 vs 2012-2021).
- Recovery: each NFL team's next regular-season game after a 1,500+ mi or 2+ zone trip.

## Sources
- nflverse schedules and play-by-play: https://github.com/nflverse/nflverse-data/releases
- CollegeFootballData via cfbfastR-data: https://github.com/sportsdataverse/cfbfastR-data
- ESPN college play-by-play (sportsdataverse): https://github.com/sportsdataverse/sportsdataverse-data/releases
- Stadium coordinates: Wikipedia infoboxes, elevation from the USGS EPQS service.

## Rerun
    python3 -I -W ignore analysis.py <scratchpad dir with shared/nfl_games.parquet and panel.parquet> out
    python3 -I make_spec.py out travel-circadian.json

## Gaps
Actual flight and arrival times, sleep and practice schedules, and international games are not covered.
NFL lines are nflverse spread_line and CFB lines the SBR archive (2006-2019); neither documents capture time.
