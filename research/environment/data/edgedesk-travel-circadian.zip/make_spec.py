"""Travel & Circadian results -> EdgeDesk study spec JSON. All numbers are read from out/ files."""
import json, sys, numpy as np, pandas as pd
O = sys.argv[1]; OUT = sys.argv[2]
r = json.load(open(f'{O}/results.json'))
M = {m['label']: m for m in r['models']}
games = pd.read_csv(f'{O}/travel_games.csv.gz')

def co(label, term): return M[label]['coefs'][term]
def f1(x): v = f'{x:+.1f}'; return '0.0' if v in ('+0.0', '-0.0') else v
def ci(b, se): return f'{f1(b)} [{f1(b-1.96*se)}, {f1(b+1.96*se)}]'
def CI(label, term): return ci(*co(label, term))
def wp(label, term): return M[label]['wild'].get(term)
def pf(x): return '–' if x is None else (f'{x:.3f}' if x < 0.01 else f'{x:.2f}')
def pct(x): return f'{100*x:.1f}%'
def cover(d):
    a = d.v_ats.dropna(); a = a[a != 0]
    return (a > 0).mean() if len(a) else np.nan, len(a)

cov = r['coverage']
nfl, cfb = games[games.sport == 'NFL'], games[games.sport == 'CFB']
cell = lambda d: d[(d.east2 == 1) & (d.ko_body < 11.5)]
SEA = {}
for sp, d in [('NFL', nfl), ('CFB', cfb)]:
    for era, de in [('all', d), ('pre', d[d.season < 2012]), ('post', d[d.season >= 2012])]:
        SEA[(sp, era)] = (len(cell(de)),) + cover(cell(de))

# 1. classic cell table
rows = []
for sp, yrs in [('NFL', {'all': '2000–2025', 'pre': '2000–2011', 'post': '2012–2025'}), ('CFB', {'all': '2001–2021', 'pre': '2001–2011', 'post': '2012–2021'})]:
    for era in ['all', 'pre', 'post']:
        lm = f'{sp}|market|v_ats' if era == 'all' else f'{sp}|market|{era}|v_ats'
        lf = f'{sp}|FE|v_margin' if era == 'all' else f'{sp}|FE+controls|{era}|v_margin'
        n, cv, nl = SEA[(sp, era)]
        rows.append([f'{sp} {yrs[era]}', f'{n}', f'{pct(cv)} of {nl}', CI(lm, 'east2_early'), pf(wp(lm, 'east2_early')), CI(lf, 'east2_early')])
t1 = {'cols': ['League, seasons', 'Games', 'Raw cover %', 'Vs spread, adjusted', 'p', 'Margin vs ratings, adjusted'], 'rows': rows, 'num': [1, 2, 3, 4, 5],
      'caption': 'Visitor two or three time zones west of the venue, kicking off before 11:30 a.m. on its own body clock (the 1:00 p.m. ET window for a Pacific team). '
                 '"Vs spread" is the visitor’s margin against the market line relative to same-time-zone visitors in day games, with travel, rest, division, playoff, roof and season controls. '
                 '"Margin vs ratings" swaps the line for team-season strength ratings. Points with 95% intervals; p from a wild-cluster bootstrap.'}

# 2. matched distance east vs west
rows = []
for sp in ['NFL', 'CFB']:
    for c in r['cells'][sp]:
        rows.append([f'{sp} · {c["dist"]}', 'East' if c['dir'] == 'east' else 'West', f'{c["n"]:,}', f'{c["v_margin"]:+.1f}', f'{c["n_lines"]:,}', pct(c['cover']), f'{c["v_ats"]:+.2f}'])
t2 = {'cols': ['League · distance', 'Direction', 'Games', 'Visitor margin', 'Lines', 'Cover %', 'Margin vs line'], 'rows': rows, 'num': [2, 3, 4, 5, 6],
      'caption': 'Raw visitor results by trip length and direction of the clock change. Same-time-zone trips are excluded. CFB lines cover 2006–2019 only.'}

# 3. all cells, adjusted
names = [('east2_early', 'Went 2–3 zones east, early body-clock kickoff'), ('east2_day', 'Went 2–3 zones east, afternoon'), ('east2_night', 'Went 2–3 zones east, night game'),
         ('west2_day', 'Went 2–3 zones west, day game'), ('west2_night', 'Went 2–3 zones west, night game'), ('east1', 'Went 1 zone east'), ('west1', 'Went 1 zone west')]
rows = []
for k, lab in names:
    rows.append([lab, f'{M["NFL|market|v_ats"]["cell_n"].get(k, 0):,}', CI('NFL|market|v_ats', k), CI('NFL|FE|v_margin', k),
                 f'{M["CFB|FE|v_margin"]["cell_n"].get(k, 0):,}', CI('CFB|market|v_ats', k), CI('CFB|FE|v_margin', k)])
t3 = {'cols': ['Visitor travel cell', 'NFL games', 'NFL vs spread', 'NFL vs ratings', 'CFB games', 'CFB vs spread', 'CFB vs ratings'], 'rows': rows, 'num': [1, 2, 3, 4, 5, 6],
      'caption': 'Each cell is compared with same-time-zone visitors (night cells with same-time-zone night games). CFB spread models use 2006–2019. Night = kickoff 7:00 p.m. ET or later.'}

# forest: NFL vs spread, pre vs post
fp = [('east2_early', 'East, early kickoff'), ('east2_day', 'East, afternoon'), ('east2_night', 'East, night'), ('west2_day', 'West, day'), ('west2_night', 'West, night'), ('east1', '1 zone east'), ('west1', '1 zone west')]
W_, rowh, left, right = 680, 34, 150, 24
H = 40 + rowh * len(fp) + 30; lo, hi = -9, 9
X = lambda v: left + (min(max(v, lo), hi) - lo) / (hi - lo) * (W_ - left - right)
s = [f'<svg viewBox="0 0 {W_} {H}" role="img" aria-label="NFL visitor margin against the spread by travel cell, 2000-2011 versus 2012-2025" class="forest">']
for t in range(-8, 9, 2):
    s.append(f'<line x1="{X(t):.1f}" x2="{X(t):.1f}" y1="28" y2="{H-26}" class="{"zero" if t == 0 else "grid"}"/>')
    s.append(f'<text x="{X(t):.1f}" y="{H-8}" class="tick" text-anchor="middle">{t:+d}</text>')
s.append(f'<text x="{left}" y="16" class="axl">NFL visitor points vs the spread (orange 2000–2011, teal 2012–2025)</text>')
for i, (k, lab) in enumerate(fp):
    y = 44 + i * rowh
    s.append(f'<text x="{left-12}" y="{y+4}" text-anchor="end" class="lab">{lab}</text>')
    for era, dy, cls in [('pre', -6, ' b'), ('post', 6, '')]:
        b, se = co(f'NFL|market|{era}|v_ats', k)
        s.append(f'<line x1="{X(b-1.96*se):.1f}" x2="{X(b+1.96*se):.1f}" y1="{y+dy}" y2="{y+dy}" class="ci{cls}"/><circle cx="{X(b):.1f}" cy="{y+dy}" r="4.5" class="pt{cls}"/>')
s.append('</svg>')
svg = ''.join(s)

# 4. night + recovery + halves
nd = lambda l: (2 * co(l, 'night_pair_diff')[0], 2 * co(l, 'night_pair_diff')[1])
rows = [['NFL, east-minus-west night gap vs spread', ci(*nd('NFL|pair_market|v_ats')), pf(wp('NFL|pair_market|v_ats', 'night_pair_diff'))],
        ['CFB, east-minus-west night gap vs spread', ci(*nd('CFB|pair_market|v_ats')), pf(wp('CFB|pair_market|v_ats', 'night_pair_diff'))],
        ['NFL, east-minus-west night gap vs ratings', ci(*nd('NFL|pair_FE|v_margin')), pf(wp('NFL|pair_FE|v_margin', 'night_pair_diff'))],
        ['CFB, east-minus-west night gap vs ratings', ci(*nd('CFB|pair_FE|v_margin')), pf(wp('CFB|pair_FE|v_margin', 'night_pair_diff'))]]
rec_m, rec_a = co('NFL|recovery|margin', 'prev_long'), co('NFL|recovery|ats', 'prev_long')
rows += [[f'NFL, game after a 1,500+ mi or 2+ zone trip ({M["NFL|recovery|ats"]["cell_n"]["prev_long"]:,} team-games), vs spread', ci(*rec_a), '–'],
         ['NFL, game after a long trip, vs ratings', ci(*rec_m), '–']]
t4 = {'cols': ['Test', 'Points [95% CI]', 'p'], 'rows': rows, 'num': [1, 2],
      'caption': 'Night gap: visitors who travelled east to a night game (playing earlier on their body clock) minus visitors who travelled west to one. A positive number favours the westerners. '
                 'Recovery: the team’s next regular-season game after a long trip, with team-season and opponent-season effects (ratings version) or the line (spread version).'}
halves = [['First half', CI('NFL|FE|v_margin_1h', 'east2_early'), CI('CFB|FE|v_margin_1h', 'east2_early')],
          ['Second half', CI('NFL|FE|v_margin_2h', 'east2_early'), CI('CFB|FE|v_margin_2h', 'east2_early')],
          ['Fourth quarter', CI('NFL|FE|v_margin_q4', 'east2_early'), CI('CFB|FE|v_margin_q4', 'east2_early')]]
t5 = {'cols': ['Period', 'NFL', 'CFB'], 'rows': halves, 'num': [1, 2],
      'caption': 'Early-kickoff eastbound visitors, margin by period against team ratings. A first-half "slow start" would show as a larger first-half number.'}

pre_n, pre_cv, pre_nl = SEA[('NFL', 'pre')]; post_n, post_cv, post_nl = SEA[('NFL', 'post')]
b_pre, b_post = co('NFL|market|pre|v_ats', 'east2_early')[0], co('NFL|market|post|v_ats', 'east2_early')[0]
fe_pre, fe_post = co('NFL|FE+controls|pre|v_margin', 'east2_early')[0], co('NFL|FE+controls|post|v_margin', 'east2_early')[0]
spec = {
 'slug': 'travel-circadian', 'module': 'Travel & Circadian', 'status': 'null', 'status_label': 'Priced by the market since 2012',
 'title': 'The early-kickoff body clock: the line caught up',
 'question': 'Does a West Coast team traveling east for a 1:00 p.m. ET kickoff perform differently from a team traveling the same distance west?',
 'lede': f'NFL West Coast teams in the early Eastern window score about {abs(co("NFL|FE|v_margin","east2_early")[0]):.1f} points below their ratings, with a wide interval. Through 2011 the spread missed it and they covered {pct(pre_cv)} of the time. Since 2012 the line has priced it and the edge is gone.',
 'scope': f'NFL {cov["NFL"]["seasons"][0]}–{cov["NFL"]["seasons"][1]} · CFB {cov["CFB"]["seasons"][0]}–{cov["CFB"]["seasons"][1]}', 'updated': '2026-10-17',
 'findings': [
   f'NFL visitors who travel two or three zones east for an early body-clock kickoff land **{abs(co("NFL|FE|v_margin","east2_early")[0]):.1f} points** below their ratings ({CI("NFL|FE|v_margin","east2_early")}, p = {pf(wp("NFL|FE|v_margin","east2_early"))}, {SEA[("NFL","all")][0]} games). The interval is wide but the estimate is stable: {fe_pre:+.1f} before 2012 and {fe_post:+.1f} after.',
   f'Against the spread, those teams finished **{abs(b_pre):.1f} points** worse than the line from 2000 to 2011 (p = {pf(wp("NFL|market|pre|v_ats","east2_early"))}) and covered {pct(pre_cv)} of {pre_nl}. From 2012 to 2025 the gap is {abs(b_post):.1f} points (p = {pf(wp("NFL|market|post|v_ats","east2_early"))}) and the cover rate is {pct(post_cv)} of {post_nl}.',
   f'Matched for distance, the direction of travel does not show a clean asymmetry against the line in either league. NFL 2–3 zone east trips in the afternoon: {CI("NFL|market|v_ats","east2_day")}; west trips by day: {CI("NFL|market|v_ats","west2_day")}.',
   f'Night games point the classic way in the NFL (westerners playing earlier on their body clock do better, gap {ci(*nd("NFL|pair_market|v_ats"))} vs the spread, p = {pf(wp("NFL|pair_market|v_ats","night_pair_diff"))}) but the opposite way in college ({ci(*nd("CFB|pair_market|v_ats"))}), so it is not a stable signal.',
   f'College shows no early-kickoff effect against the spread ({CI("CFB|market|v_ats","east2_early")}) or ratings ({CI("CFB|FE|v_margin","east2_early")}), on only {SEA[("CFB","all")][0]} games.',
   f'There is no hangover in the NFL game after a long trip: {ci(*rec_a)} points vs the spread.'],
 'sections': [
   {'h': 'The classic case: West Coast team, early Eastern kickoff', 'p': ['The body-clock effect is strongest when a team kicks off at what feels like 10:00 a.m. The performance cost has held steady for 25 years. What changed is the price.'], 'table': t1},
   {'h': 'Same distance, opposite direction', 'p': ['Raw results for trips of similar length, split by whether the visitor’s clock moved forward (east) or back (west).'], 'table': t2},
   {'h': 'Every travel cell, adjusted', 'p': ['The chart compares the NFL spread results before and after 2012. The early eastbound row is the only one that moved from clearly negative to zero.'], 'svg': svg, 'table': t3},
   {'h': 'Night games, recovery and timing within the game', 'table': t4, 'tables': [t5]}],
 'model_verdict': 'Not a betting edge. The early-kickoff effect is real on the field but has been priced by NFL closing lines since 2012. It enters the combined environment model as a candidate input to the fair margin (signed body-clock kickoff and eastbound time-zone shift), where it must beat the closing line out of sample before it can move any EdgeDesk number. The night-game asymmetry is not stable across leagues and is not carried forward.',
 'data': [['NFL games', f'{cov["NFL"]["games"]:,} regular and postseason games at a home stadium, 2000–2025 (1999 has no kickoff times). Neutral and international games excluded.'],
          ['CFB games', f'{cov["CFB"]["games"]:,} non-neutral FBS-vs-FBS games 2001–2021 at their verified venue; {cov["CFB"]["lines"]:,} with spreads (2006–2019).'],
          ['Time zones', 'Venue and visitor home-stadium IANA time zones, converted on the game date so daylight-saving changes and Arizona are handled.'],
          ['Kickoff', 'NFL: nflverse kickoff time (Eastern). CFB: CollegeFootballData start time (UTC).'],
          ['Lines', 'NFL: nflverse spread_line. CFB: SBR archive, Pinnacle where available. Neither is a licensed closing feed with a documented capture time.'],
          ['Strength', 'Team-season rating for each side estimated jointly with the travel effects; SEs clustered by home team (NFL) or host venue (CFB).']],
 'gaps': [['Actual travel', 'Departure day, flight time and hotel arrival are not public. Distance and time zones stand in for them.'],
          ['Sleep and practice schedules', 'Teams that fly a day early or keep home-clock schedules cannot be identified.'],
          ['CFB kickoff placeholders', f'About 9% of CFB kickoffs sit at exactly 00:00 UTC. Excluding them changes the main estimate little ({CI("CFB|FE|nomid|v_margin","east2_early")} vs {CI("CFB|FE|v_margin","east2_early")}).'],
          ['International games', 'London, Germany and Mexico City games are excluded; three of those stadiums lack verified coordinates.']],
 'sources': [['nflverse schedules and play-by-play', 'https://github.com/nflverse/nflverse-data/releases'],
             ['CollegeFootballData via cfbfastR-data', 'https://github.com/sportsdataverse/cfbfastR-data'],
             ['sportsdataverse ESPN college play-by-play', 'https://github.com/sportsdataverse/sportsdataverse-data/releases'],
             ['USGS Elevation Point Query Service (stadium coordinates check)', 'https://epqs.nationalmap.gov/v1/json']],
 'zip': 'edgedesk-travel-circadian.zip'}
txt = json.dumps(spec)
assert '—' not in txt, 'em dash found'
json.dump(spec, open(OUT, 'w'), indent=1)
print('ok')
