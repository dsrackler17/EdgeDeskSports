"""Study 6 — Weather Adaptation models.

Game-level outcomes (visitor perspective): margin, 2H margin, Q4 margin, margin vs spread;
game total vs closing total. Team strength: team-season fixed effects (signed for margins:
+1 home team-season, -1 visitor; additive for totals: +1 both), partialled out by
Frisch-Waugh-Lovell with sparse LSQR. Cluster-robust SEs by stadium; wild-cluster
bootstrap p-values for the headline terms.
Team-game outcomes (offense EPA/play, pass EPA/play, success, turnovers, FG%): two rows
per game, team-season and opponent-season FE via pyfixest, clustered by stadium.
"""
import sys, json, numpy as np, pandas as pd, scipy.sparse as sp
from scipy.sparse.linalg import lsqr
import pyfixest as pf

P, S, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
g = pd.read_parquet(P)
u = g[g.usable].copy().reset_index(drop=True)
u['v_margin'] = -u.result
u['v_margin_h2'] = -u.home_margin_h2
u['v_margin_q4'] = -u.home_margin_q4
u['v_ats'] = -(u.result - u.spread_line)          # visitor margin vs the number
u['v_cover'] = np.where(u.v_ats > 0, 1.0, np.where(u.v_ats < 0, 0.0, np.nan))
u['over'] = np.where(u.over_margin > 0, 1.0, np.where(u.over_margin < 0, 0.0, np.nan))
f = lambda c: c.astype(float)
for side in ['away', 'home']:
    cl = u[f'{side}_class']
    u[f'{side}_warm_cold'] = f((cl == 'warm') & u.cold)
    u[f'{side}_dome_cold'] = f((cl == 'dome') & u.cold)
    u[f'{side}_coldteam_cold'] = f((cl == 'cold') & u.cold)
    sh = u[f'{side}_shock'].fillna(0)
    u[f'{side}_cold_shock'] = (-sh).clip(lower=0) / 10      # per 10°F colder than the team's normal
    u[f'{side}_heat_shock'] = sh.clip(lower=0) / 10         # per 10°F warmer than normal
    u[f'{side}_heat_shock_early'] = u[f'{side}_heat_shock'] * f(u.early)
    u[f'{side}_dome_heat'] = f((cl == 'dome') & u.heat)
    u[f'{side}_dome_rain'] = f((cl == 'dome') & u.precip_g)
    u[f'{side}_warm_rain'] = f((cl == 'warm') & u.precip_g)
u['precip'] = f(u.precip_g); u['snow'] = f(u.snow_g)
u['humid_heat'] = f((u.hum_g >= 70) & (u.temp_g >= 80))
u['wind10'] = u.wind_g.fillna(0) / 10
u['div'] = u.div_game.astype(float)
for b in u.temp_bin.cat.categories[1:]:
    u[f'tb_{b}'] = f(u.temp_bin == b)
TB = [f'tb_{b}' for b in u.temp_bin.cat.categories[1:]]
yr = pd.get_dummies(u.season, prefix='yr', drop_first=True, dtype=float); u = pd.concat([u, yr], axis=1); YR = list(yr.columns)
u['wk'] = u.week.astype(float)
BASE = TB + ['wind10', 'precip', 'snow', 'div', 'wk'] + YR

RES, WILD = [], {}

def cluster_ols(y, X, cl, ka):
    n, k = X.shape; XtX = np.linalg.pinv(X.T @ X); b = XtX @ X.T @ y; e = y - X @ b
    uc, inv = np.unique(cl, return_inverse=True); G = len(uc)
    Sm = np.zeros((G, k)); np.add.at(Sm, inv, X * e[:, None])
    V = G / (G - 1) * (n - 1) / max(n - k - ka, 1) * XtX @ (Sm.T @ Sm) @ XtX
    return b, np.sqrt(np.diag(V)), G

def wild_p(y, X, j, cl, B=499, seed=5):
    rng = np.random.default_rng(seed); uc, inv = np.unique(cl, return_inverse=True); G = len(uc)
    def t(yy):
        XtX = np.linalg.pinv(X.T @ X); b = XtX @ X.T @ yy; e = yy - X @ b
        Sm = np.zeros((G, X.shape[1])); np.add.at(Sm, inv, X * e[:, None]); V = XtX @ (Sm.T @ Sm) @ XtX
        return b[j] / np.sqrt(V[j, j])
    t0 = t(y); Xr = np.delete(X, j, 1); fit = Xr @ np.linalg.lstsq(Xr, y, rcond=None)[0]; e = y - fit
    ts = np.array([t(fit + e * rng.choice([-1., 1.], G)[inv]) for _ in range(B)])
    return float((np.abs(ts) >= abs(t0)).mean())

def fe_model(d, yv, xs, label, fe='signed', wild=()):
    d = d.dropna(subset=[yv] + xs).reset_index(drop=True)
    y = d[yv].to_numpy(float); X = d[xs].to_numpy(float); X = X - X.mean(0); X = np.column_stack([np.ones(len(d)), X]); ka = 0
    if fe:
        ht = d.home_team + '_' + d.season.astype(str); at = d.away_team + '_' + d.season.astype(str)
        cats = pd.Index(pd.unique(pd.concat([ht, at]))); r = np.arange(len(d))
        sgn = -1.0 if fe == 'signed' else 1.0
        Z = sp.csr_matrix((np.r_[np.ones(len(d)), sgn * np.ones(len(d))], (np.r_[r, r], np.r_[cats.get_indexer(ht), cats.get_indexer(at)])), shape=(len(d), len(cats)))
        res = lambda v: v - Z @ lsqr(Z, v, atol=1e-10, btol=1e-10, iter_lim=20000)[0]
        y = res(y); X = np.column_stack([res(X[:, j]) for j in range(X.shape[1])]); ka = len(cats) - 1
    cl = d.stadium_id.to_numpy()
    b, se, G = cluster_ols(y, X, cl, ka)
    co = {nm: [float(bb), float(ss)] for nm, bb, ss in zip(['intercept'] + xs, b, se)}
    rec = dict(model=label, outcome=yv, n=len(d), clusters=G, coefs=co)
    for w in wild:
        rec.setdefault('wild', {})[w] = wild_p(y, X, 1 + xs.index(w), cl)
    RES.append(rec)
    return rec

CLASS = ['away_warm_cold', 'away_dome_cold', 'home_warm_cold', 'home_dome_cold']
SHOCK = ['away_cold_shock', 'home_cold_shock', 'away_heat_shock', 'home_heat_shock', 'away_dome_cold', 'home_dome_cold', 'away_dome_heat', 'home_dome_heat']
HEAT = ['away_heat_shock_early', 'home_heat_shock_early', 'humid_heat', 'away_dome_heat', 'home_dome_heat']
RAIN = ['away_dome_rain', 'home_dome_rain', 'away_warm_rain', 'home_warm_rain']
for yv in ['v_margin', 'v_margin_h2', 'v_margin_q4', 'v_ats']:
    fe_model(u, yv, CLASS + BASE, 'class_x_cold', wild=('away_warm_cold', 'away_dome_cold') if yv in ('v_margin', 'v_ats') else ())
    fe_model(u, yv, SHOCK + BASE, 'temp_shock', wild=('away_cold_shock',) if yv in ('v_margin', 'v_ats') else ())
    fe_model(u, yv, HEAT + BASE, 'heat_early', wild=('away_heat_shock_early',) if yv == 'v_margin' else ())
    fe_model(u, yv, RAIN + BASE, 'rain_x_class', wild=('away_dome_rain',) if yv == 'v_margin' else ())
for xs, lab in [(CLASS, 'class_x_cold'), (SHOCK, 'temp_shock')]:
    fe_model(u, 'v_ats', xs + BASE, lab + '_noFE', fe=None)
# totals: additive FE
for xs, lab in [(CLASS, 'class_x_cold'), (SHOCK, 'temp_shock'), (RAIN, 'rain_x_class')]:
    fe_model(u, 'over_margin', xs + BASE, lab + '_totals', fe='additive')
    fe_model(u, 'total', xs + BASE, lab + '_totals', fe='additive')

# ---------- team-game offense outcomes ----------
tg = pd.read_parquet(f'{S}/nfl_team_games.parquet')
tg['fg_pct'] = tg.fgm / tg.fga.replace(0, np.nan)
rows = []
for side, opp in [('away', 'home'), ('home', 'away')]:
    d = u[['game_id', 'season', 'stadium_id', 'temp_bin', 'wind10', 'precip', 'snow', 'cold', 'wk',
           f'{side}_team', f'{opp}_team', f'{side}_class', f'{side}_cold_shock', f'{side}_heat_shock']].copy()
    d.columns = ['game_id', 'season', 'stadium_id', 'temp_bin', 'wind10', 'precip', 'snow', 'cold', 'wk', 'team', 'opp', 'cls', 'cold_shock', 'heat_shock']
    d['is_away'] = 1.0 if side == 'away' else 0.0
    rows.append(d)
L = pd.concat(rows, ignore_index=True)
L = L.merge(tg[['game_id', 'team', 'epa', 'epa_pass', 'succ', 'to', 'fg_pct', 'fga', 'plays', 'dropbacks']], on=['game_id', 'team'], how='inner')
L['warm_cold'] = f((L.cls == 'warm') & L.cold); L['dome_cold'] = f((L.cls == 'dome') & L.cold)
L.loc[L.cls == 'dome', ['cold_shock', 'heat_shock']] = 0
L['ts'] = L.team + '_' + L.season.astype(str); L['os'] = L.opp + '_' + L.season.astype(str)
L['tbin'] = L.temp_bin.astype(str)
for yv, w in [('epa', 'plays'), ('epa_pass', 'dropbacks'), ('succ', 'plays'), ('to', None), ('fg_pct', 'fga')]:
    for nm, rhs in [('class_x_cold', 'is_away + warm_cold + dome_cold'), ('temp_shock', 'is_away + cold_shock + heat_shock + dome_cold')]:
        d = L.dropna(subset=[yv])
        fit = pf.feols(f'{yv} ~ {rhs} + wind10 + precip + snow + C(tbin) | ts + os', data=d, vcov={'CRV1': 'stadium_id'}, weights=w)
        tb = fit.tidy()
        RES.append(dict(model=nm + '_offense', outcome=yv, n=int(fit._N), clusters=int(d.stadium_id.nunique()),
                        coefs={k: [float(tb.loc[k, 'Estimate']), float(tb.loc[k, 'Std. Error'])] for k in tb.index if not k.startswith('C(')}))

# ---------- descriptive tables ----------
desc = u.groupby(['temp_bin', 'away_class'], observed=True).agg(n=('game_id', 'size'), v_margin=('v_margin', 'mean'),
        n_lines=('v_cover', lambda s: s.notna().sum()), v_cover=('v_cover', 'mean'), v_ats=('v_ats', 'mean'),
        over=('over', 'mean'), over_margin=('over_margin', 'mean')).reset_index()
desc.to_csv(f'{OUT}/desc_tempbin_awayclass.csv', index=False)
# cold games: cluster bootstrap CIs for visitor cover rate by class
rng = np.random.default_rng(3); boot = {}
cg = u[u.cold & u.v_cover.notna()]
for c in ['cold', 'warm', 'dome']:
    d = cg[cg.away_class == c]; vs = d.stadium_id.unique(); by = {v: d[d.stadium_id == v].v_cover.to_numpy() for v in vs}
    st = [np.concatenate([by[v] for v in rng.choice(vs, len(vs))]).mean() for _ in range(2000)]
    boot[c] = [float(d.v_cover.mean()), float(np.percentile(st, 2.5)), float(np.percentile(st, 97.5)), int(len(d)), int(len(vs)),
               float(d.v_margin.mean()), float(d.v_ats.mean())]
# rain totals
rain = u.groupby('precip_g').agg(n=('game_id', 'size'), total=('total', 'mean'), total_line=('total_line', 'mean'),
        over=('over', 'mean'), over_margin=('over_margin', 'mean')).reset_index()
rain.to_csv(f'{OUT}/desc_rain_totals.csv', index=False)
cov = dict(games_home_site=int(len(g)), outdoor=int(g.outdoor.sum()), usable=int(len(u)),
           seasons=[int(u.season.min()), int(u.season.max())],
           temp_from_text=int((g.temp_src == 'gamebook text').sum()),
           cold_games=int(u.cold.sum()), class_counts=u.away_class.value_counts().to_dict(),
           cold_by_class=u[u.cold].away_class.value_counts().to_dict(),
           heat_early_games=int((u.heat & u.early).sum()), precip_games=int(u.precip_g.sum()),
           humid_heat_games=int(u.humid_heat.sum()), lines=int(u.v_ats.notna().sum()),
           team_game_rows=int(len(L)))
json.dump(dict(models=RES, boot_cold=boot, coverage=cov), open(f'{OUT}/results.json', 'w'), indent=1, default=str)
u.drop(columns=YR).to_csv(f'{OUT}/panel.csv.gz', index=False)
print('done', len(RES)); print(cov); print(boot)
