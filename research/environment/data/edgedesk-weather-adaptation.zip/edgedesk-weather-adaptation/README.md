# EdgeDesk Study 6: Weather Adaptation (NFL)

Does an unusually cold, hot, humid or wet road game hurt a team more when it is far from the conditions it normally plays in?

## Run order
```
python3 build.py    <shared_dir> panel.parquet              # game panel + prior-season team climate normals
python3 models.py   panel.parquet <shared_dir> out/          # all models -> out/results.json
python3 robust.py   panel.parquet <shared_dir> out/          # era splits, cell counts -> out/robust.json
python3 make_spec.py out/ panel.parquet spec.json features.parquet
```
`<shared_dir>` holds `nfl_games.parquet` and `nfl_team_games.parquet` from the EdgeDesk shared layer (`build_nfl.py`, nflverse inputs).

## Definitions
- Team normal: mean kickoff temp of the team's outdoor home games in the same calendar month over the previous 5 seasons (>=3 games; else same part of season). No current-season data.
- Dome team: >=50% of home games indoors over the previous 3 seasons. Warm-climate team: outdoor team with Nov-Jan home normal >=55F.
- Cold shock: degrees colder than the visitor's normal, per 10F.

## Files
- `panel.csv.gz` game-level dataset used in every model (5,146 usable games, 2000-2025)
- `results.json` all coefficients, SEs, clusters, wild-bootstrap p-values, cold-game cover bootstraps
- `robust.json` era splits and cell counts
- `desc_*.csv` descriptive tables

## Caveats
Weather is kickoff-recorded (NFL gamebook), not the pre-game forecast. Lines are nflverse consensus spreads/totals, capture time undocumented. No CFB weather available. Team codes in play-by-play were remapped to the schedule's OAK/SD/STL codes (checked).
