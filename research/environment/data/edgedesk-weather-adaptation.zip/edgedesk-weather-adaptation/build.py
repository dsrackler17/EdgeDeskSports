"""Study 6 — Weather Adaptation (NFL). Build the game-level analysis panel.

Game weather: nflverse `temp`/`wind` (NFL gamebook, at kickoff). Where those are blank
(mostly 2022-2023) the same gamebook text in play-by-play `weather` is parsed; the two agree
within 1°F on 96.7% of games where both exist.

Team "normal" conditions are built only from PRIOR seasons (no leakage):
  normal_temp(team, season, month) = mean kickoff temp of that team's outdoor HOME games
  in the same calendar month over the previous 5 seasons (>= 3 games), falling back to the
  team's prior-5-season home mean for Sep-Oct or Nov-Jan blocks.
  dome team (season s) = >= 50% of the team's home games in seasons s-3..s-1 were indoors
  (dome / closed roof). For a dome team, "home normal" is indoor climate control.
  warm-climate team = outdoor team whose prior-season normal for Nov-Jan home games >= 55°F.
Shock = game temp - team normal for that month (negative = colder than usual).
"""
import sys, re, numpy as np, pandas as pd

S, OUT = sys.argv[1], sys.argv[2]
g = pd.read_parquet(f'{S}/nfl_games.parquet')
g = g[g.location == 'Home'].copy()          # neutral-site games excluded
g['month'] = g.gameday.dt.month
g['outdoor'] = ~g.indoor
txt = g.weather_text.fillna('')
t_txt = txt.str.extract(r'Temp:\s*(-?\d+)\s*°')[0].astype(float)
w_txt = txt.str.extract(r'Wind:\s*(?:[A-Za-z\-]+\s*)?(\d+)\s*mph', flags=re.I)[0].astype(float)
g['temp_src'] = np.where(g.temp.notna(), 'schedule', np.where(t_txt.notna() & g.outdoor, 'gamebook text', None))
g['temp_g'] = np.where(g.outdoor, g.temp.fillna(t_txt), np.nan)
g['wind_g'] = np.where(g.outdoor, g.wind.fillna(w_txt), 0.0)
g['hum_g'] = np.where(g.outdoor, g.humidity, np.nan)
g['precip_g'] = g.precip.fillna(False).astype(bool) & g.outdoor
g['snow_g'] = g.snow.fillna(False).astype(bool) & g.outdoor

# ---------- team home history ----------
hh = g[['season', 'month', 'home_team', 'indoor', 'temp_g']].rename(columns={'home_team': 'team'})
def blk(m): return 'early' if m in (8, 9, 10) else 'late'
hh['blk'] = hh.month.map(blk)
teams = sorted(set(g.home_team) | set(g.away_team))
recs = []
for team in teams:
    th = hh[hh.team == team]
    for s in range(g.season.min(), g.season.max() + 1):
        prior = th[(th.season < s) & (th.season >= s - 5)]
        prior3 = th[(th.season < s) & (th.season >= s - 3)]
        r = dict(team=team, season=s, n_prior=len(prior),
                 dome_share=prior3.indoor.mean() if len(prior3) else np.nan)
        out = prior[~prior.indoor & prior.temp_g.notna()]
        late = out[out.blk == 'late'].temp_g
        r['late_normal'] = late.mean() if len(late) >= 3 else np.nan
        for m in [8, 9, 10, 11, 12, 1, 2]:
            x = out[out.month == m].temp_g
            if len(x) >= 3:
                r[f'n{m}'] = x.mean()
            else:
                xb = out[out.blk == blk(m)].temp_g
                r[f'n{m}'] = xb.mean() if len(xb) >= 3 else np.nan
        recs.append(r)
clim = pd.DataFrame(recs)
clim['dome_team'] = clim.dome_share >= 0.5
clim['warm_team'] = (~clim.dome_team) & (clim.late_normal >= 55)

def attach(side):
    c = clim.add_prefix(f'{side}_').rename(columns={f'{side}_team': f'{side}_team', f'{side}_season': 'season'})
    return c
for side in ['home', 'away']:
    g = g.merge(attach(side), on=[f'{side}_team', 'season'], how='left')
    g[f'{side}_normal'] = [r[f'{side}_n{m}'] if f'{side}_n{m}' in r else np.nan for (_, r), m in zip(g.iterrows(), g.month)]
    g[f'{side}_shock'] = g.temp_g - g[f'{side}_normal']        # outdoor teams only
    g.loc[g[f'{side}_dome_team'] == True, f'{side}_shock'] = np.nan
    g[f'{side}_class'] = np.select([g[f'{side}_dome_team'] == True, g[f'{side}_warm_team'] == True,
                                    g[f'{side}_late_normal'].notna()], ['dome', 'warm', 'cold'], 'unknown')
# usable: prior history exists (drops each franchise's first 3 seasons in the data and relocation edge cases)
g['usable'] = g.outdoor & g.temp_g.notna() & (g.home_class != 'unknown') & (g.away_class != 'unknown')
g['temp_bin'] = pd.cut(g.temp_g, [-100, 32, 45, 60, 75, 85, 200], labels=['≤32°F', '33–45°F', '46–60°F', '61–75°F', '76–85°F', '>85°F'])
g['cold'] = g.temp_g <= 40
g['heat'] = (g.temp_g >= 85)
g['early'] = g.month.isin([8, 9])
g['home_margin'] = g.result
g.to_parquet(OUT)
u = g[g.usable]
print(len(g), 'usable', len(u))
print(u.groupby(['away_class']).size().to_dict(), u.groupby('home_class').size().to_dict())
print(pd.crosstab(u.temp_bin, u.away_class))
print('temp source', g[g.outdoor].temp_src.value_counts(dropna=False).to_dict())
print(clim[clim.season == 2015][['team', 'dome_team', 'warm_team', 'late_normal', 'n12']].round(1).to_string())
