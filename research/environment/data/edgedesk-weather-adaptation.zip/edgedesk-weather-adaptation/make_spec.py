"""Study 6 results -> EdgeDesk study spec + feature file. Every number is read from model output."""
import sys, json, numpy as np, pandas as pd
O, P, SPEC, FEAT = sys.argv[1:5]
r = json.load(open(f'{O}/results.json')); rb = json.load(open(f'{O}/robust.json'))
M = {(m['model'], m['outcome']): m for m in r['models']}
cov, boot = r['coverage'], r['boot_cold']
def c(m, o, t): return M[(m, o)]['coefs'][t]
def ci(v, k=1.0, d=2): b, s = v; return f'{b*k:+.{d}f} [{(b-1.96*s)*k:+.{d}f}, {(b+1.96*s)*k:+.{d}f}]'
def cio(v, k=1.0, d=2): b, s = v; return f'{(b-1.96*s)*k:+.{d}f} to {(b+1.96*s)*k:+.{d}f}'
def wp(m, o, t): return M[(m, o)].get('wild', {}).get(t)
pct = lambda x: f'{100*x:.1f}%'
desc = pd.read_csv(f'{O}/desc_tempbin_awayclass.csv')
cls_lab = {'cold': 'Cold-climate visitor', 'warm': 'Warm-climate visitor', 'dome': 'Dome visitor'}

# ---- figure: cold-game cover rate by visitor class, 95% CI ----
W, left, right, rowh = 640, 190, 30, 40
H = 50 + rowh * 3 + 30; lo, hi = 0.30, 0.60
X = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
s = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Visitor cover rate in games at 40°F or colder, by visitor home climate, with 95% intervals" class="forest">']
for t in [0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60]:
    s.append(f'<line x1="{X(t):.1f}" x2="{X(t):.1f}" y1="30" y2="{H-26}" class="{"zero" if abs(t-0.5)<1e-9 else "grid"}"/>')
    s.append(f'<text x="{X(t):.1f}" y="{H-8}" class="tick" text-anchor="middle">{int(t*100)}%</text>')
s.append(f'<text x="{left}" y="18" class="axl">Visitor cover rate vs the spread, games at 40°F or colder</text>')
for i, k in enumerate(['cold', 'dome', 'warm']):
    y = 52 + i * rowh; m, l, h, n = boot[k][0], boot[k][1], boot[k][2], boot[k][3]
    s.append(f'<text x="{left-12}" y="{y+4}" text-anchor="end" class="lab">{cls_lab[k]} (n={n})</text>')
    s.append(f'<line x1="{X(l):.1f}" x2="{X(h):.1f}" y1="{y}" y2="{y}" class="ci{" b" if k=="warm" else ""}"/>')
    s.append(f'<circle cx="{X(m):.1f}" cy="{y}" r="5" class="pt{" b" if k=="warm" else ""}"/>')
s.append('</svg>'); fig = ''.join(s)

# ---- tables ----
bins = ['≤32°F', '33–45°F', '46–60°F', '61–75°F', '76–85°F', '>85°F']
rows = []
for b in bins:
    row = [b]
    for k in ['cold', 'warm', 'dome']:
        d = desc[(desc.temp_bin == b) & (desc.away_class == k)]
        row.append(f'{int(d.n.iloc[0])} · {d.v_margin.iloc[0]:+.1f} · {pct(d.v_cover.iloc[0])}' if len(d) else '–')
    rows.append(row)
adj = []
for lab, (m, o, t, k) in [('Warm-climate visitor in a game at 40°F or colder', ('class_x_cold', 'v_margin', 'away_warm_cold', 1)),
                          ('Dome visitor in a game at 40°F or colder', ('class_x_cold', 'v_margin', 'away_dome_cold', 1)),
                          ('Visitor, per 10°F colder than its normal', ('temp_shock', 'v_margin', 'away_cold_shock', 1)),
                          ('Visitor, per 10°F warmer than its normal (Aug–Sep)', ('heat_early', 'v_margin', 'away_heat_shock_early', 1)),
                          ('Dome visitor in rain', ('rain_x_class', 'v_margin', 'away_dome_rain', 1)),
                          ('Warm-climate visitor in rain', ('rain_x_class', 'v_margin', 'away_warm_rain', 1))]:
    ats_m = m
    p1 = wp(m, 'v_margin', t)
    adj.append([lab, ci(c(m, 'v_margin', t)), ci(c(m, 'v_margin_h2', t)), ci(c(ats_m, 'v_ats', t)), f'{p1:.2f}' if p1 is not None else '–'])
off = []
for lab, (m, t, o, k, u) in [('Offense EPA/play, per 10°F colder than normal', ('temp_shock_offense', 'cold_shock', 'epa', 1, '')),
                             ('Pass EPA/dropback, per 10°F colder than normal', ('temp_shock_offense', 'cold_shock', 'epa_pass', 1, '')),
                             ('Turnovers, per 10°F colder than normal', ('temp_shock_offense', 'cold_shock', 'to', 1, '')),
                             ('Field-goal %, dome team at 40°F or colder (pp)', ('class_x_cold_offense', 'dome_cold', 'fg_pct', 100, '')),
                             ('Success rate, warm-climate team at 40°F or colder (pp)', ('class_x_cold_offense', 'warm_cold', 'succ', 100, '')),
                             ('Offense EPA/play in rain (any team)', ('temp_shock_offense', 'precip', 'epa', 1, ''))]:
    mm = M[(m, o)]
    off.append([lab, ci(mm['coefs'][t], k, 3 if k == 1 else 1), f'{mm["n"]:,}'])
e1, e2 = rb['2000-2012'], rb['2013-2025']
rob = [['Visitor ATS margin, per 10°F colder than normal', ci(c('temp_shock', 'v_ats', 'away_cold_shock')), ci(e1['away_cold_shock_ats']), ci(e2['away_cold_shock_ats'])],
       ['Game total vs closing total, rain at kickoff', ci(c('rain_x_class_totals', 'over_margin', 'precip')), ci(e1['precip_over']), ci(e2['precip_over'])]]
pr, dr = rb['precip_over_rate'], rb['dry_over_rate']
cs_m, cs_a = c('temp_shock', 'v_margin', 'away_cold_shock'), c('temp_shock', 'v_ats', 'away_cold_shock')
wc = boot['warm']; cc = boot['cold']
spec = {
 'slug': 'weather-adaptation', 'module': 'Weather Adaptation', 'status': 'experimental', 'status_label': 'Two candidates, unvalidated',
 'title': 'Weather shock: do road teams struggle in conditions they never play in?',
 'question': 'Does an unusually cold, hot, humid or wet road game hurt a team more when it is far from the conditions it normally plays in?',
 'lede': f'Across {cov["usable"]:,} NFL games at outdoor stadiums, a visitor playing colder than its own normal does slightly worse, and the spread does not fully adjust. The effect is small, it mostly comes from the last 13 seasons, and it needs an out-of-sample test before it can mean anything.',
 'scope': f'NFL · outdoor games {cov["seasons"][0]}–{cov["seasons"][1]}', 'updated': '2026-10-17',
 'findings': [
   f'Each 10°F a game is colder than the visitor’s own normal for that month costs the visitor **{cs_m[0]:+.2f} points** (95% CI {cio(cs_m)}, wild-bootstrap p = {wp("temp_shock","v_margin","away_cold_shock"):.2f}) after team-season strength, generic temperature, wind, rain, division and season controls.',
   f'The spread misses most of it: visitor margin against the number moves {cs_a[0]:+.2f} points per 10°F of cold shock (95% CI {cio(cs_a)}, p = {wp("temp_shock","v_ats","away_cold_shock"):.2f}). The estimate is {e1["away_cold_shock_ats"][0]:+.2f} in 2000–2012 and {e2["away_cold_shock_ats"][0]:+.2f} in 2013–2025, so it is not stable across eras.',
   f'The famous version, a warm-climate team in a freezing road game, looks bad in raw numbers: warm-climate visitors covered {pct(wc[0])} of {wc[3]} games at 40°F or colder (95% CI {pct(wc[1])} to {pct(wc[2])}) versus {pct(cc[0])} for cold-climate visitors. After controls the class effect is {ci(c("class_x_cold","v_margin","away_warm_cold"))} points, p = {wp("class_x_cold","v_margin","away_warm_cold"):.2f}, so the raw gap is mostly team quality and luck.',
   f'Dome teams are not hurt in cold games overall ({ci(c("class_x_cold","v_margin","away_dome_cold"))} points), but their field-goal percentage changes by {ci(M[("class_x_cold_offense","fg_pct")]["coefs"]["dome_cold"],100,1)} percentage points at 40°F or colder.',
   f'Early-season heat shows nothing: {ci(c("heat_early","v_margin","away_heat_shock_early"))} points per 10°F warmer than the visitor’s normal in August and September ({rb["heat_early"]} games at 85°F or hotter).',
   f'Rain matters for totals, not sides. Games with rain or snow noted at kickoff went over {pct(pr[0])} of the time (95% CI {pct(pr[1])} to {pct(pr[2])}, n = {pr[3]}) versus {pct(dr[0])} in dry games, finishing {ci(c("rain_x_class_totals","over_margin","precip"))} points against the closing total. The precipitation flag comes from kickoff conditions, which the market only knew as a forecast.'],
 'sections': [
   {'h': 'How a team’s normal is defined', 'p': [
      'For every team and season, EdgeDesk takes the kickoff temperatures of that team’s outdoor home games in the same calendar month over the previous five seasons (at least three games, otherwise the same part of the season). Nothing from the current season or the game itself is used, so the figure was knowable before kickoff.',
      'Teams that played at least half their home games indoors over the previous three seasons are classed as dome teams. Outdoor teams whose late-season home normal is 55°F or warmer are warm-climate teams. Everyone else is a cold-climate team. Cold shock is how many degrees colder the game is than the visitor’s normal for that month.'],
    'table': {'cols': ['Game temperature', 'Cold-climate visitors: games · margin · cover', 'Warm-climate visitors', 'Dome visitors'], 'rows': rows, 'num': [1, 2, 3],
              'caption': 'Unadjusted. Margin is the visitor’s average final margin; cover is the visitor’s cover rate against the spread, pushes excluded.'}},
   {'h': 'Cold games by visitor home climate', 'svg': fig,
    'after': [f'Bars are 95% intervals from a bootstrap that resamples host stadiums. Warm-climate visitors sit below 50%, but the interval is wide and the gap mostly disappears once team strength is modeled.']},
   {'h': 'After controls', 'p': ['Each team-season gets its own rating, so a weak warm-weather team is compared with its own other games. Every model includes temperature bands, wind, rain, snow, division game, week and season. Standard errors cluster by stadium (41 outdoor venues).'],
    'table': {'cols': ['Visitor condition', 'Full-game margin', 'Second-half margin', 'Margin vs spread', 'p (full game)'], 'rows': adj, 'num': [1, 2, 3, 4],
              'caption': 'Points from the visitor’s side with 95% intervals. Negative means the visitor did worse. p-values are wild-cluster bootstrap. Small cells: 99 dome visitors and 78 warm-climate visitors played in rain.'}},
   {'h': 'What changes on the field', 'p': ['Team-game models with separate team-season ratings for the offense and its opponent.'],
    'table': {'cols': ['Outcome', 'Estimate [95% CI]', 'Team-games'], 'rows': off, 'num': [1, 2],
              'caption': 'EPA is expected points added per play. Cold shock is measured against each team’s own normal; dome teams are scored by the dome-in-cold indicator instead.'}},
   {'h': 'Stability check', 'p': ['The two effects that survived controls were re-estimated separately on each half of the sample. An effect that only exists in one era is more likely to be noise or a market that has since changed.'],
    'table': {'cols': ['Effect', 'All seasons', '2000–2012', '2013–2025'], 'rows': rob, 'num': [1, 2, 3],
              'caption': 'Roughly 50 coefficients are reported across this study, so one or two with p near 0.04 are expected by chance. Neither effect is validated until the combined model tests it out of sample.'}}],
 'model_verdict': 'Not added to the model yet. Cold shock against the visitor’s normal and kickoff rain on totals are the two candidates. Both go into the combined environment model, which tests them on later seasons it never trained on and against the closing number. Until then they appear in game research as observed context only: game temperature, the visitor’s normal for that month, and the forecast.',
 'data': [['Games', f'{cov["usable"]:,} NFL games at outdoor or open-roof stadiums, {cov["seasons"][0]}–{cov["seasons"][1]}, where both teams had at least three prior seasons of home history. Neutral-site games excluded.'],
          ['Weather', f'Kickoff temperature, wind and conditions from the NFL gamebook via nflverse. {cov["temp_from_text"]} games with a blank temperature field (mostly 2022–2023) were filled from the same gamebook text, which matches the field within 1°F on 96.7% of games where both exist.'],
          ['Lines', 'nflverse spread and total for every game. nflverse does not document when the line was captured, so it is treated as a near-close consensus, not a licensed closing feed.'],
          ['Play-by-play', f'nflverse play-by-play, {cov["team_game_rows"]:,} team-games, with franchise codes matched to the schedule (checked after a shared-layer fix for OAK/SD/STL).']],
 'gaps': [['College football', 'No historical CFB game weather was reachable, so this study is NFL only.'],
          ['Forecast vs actual', 'Weather is what was recorded at kickoff. The market priced the forecast, which is very close for temperature and much less reliable for rain.'],
          ['Practice climate', 'A team’s normal is built from its home games. Where it practices, including indoor facilities, is not recorded.'],
          ['Heat index and dew point', 'Humidity exists from 2001 on, but only 73 games were 80°F+ with 70%+ humidity, too few to model separately.'],
          ['Wind direction', 'Recorded as a compass point without the field’s orientation, so crosswind cannot be computed.']],
 'sources': [['nflverse schedules and lines', 'https://github.com/nflverse/nflverse-data/releases/tag/schedules'],
             ['nflverse play-by-play', 'https://github.com/nflverse/nflverse-data/releases/tag/pbp']],
 'zip': 'edgedesk-weather-adaptation.zip'}
txt = json.dumps(spec)
assert '—' not in txt, 'em dash found'
json.dump(spec, open(SPEC, 'w'), indent=1, ensure_ascii=False)

# ---- feature file (pre-game: knowable from schedule history; weather is kickoff-recorded, see caveat) ----
g = pd.read_parquet(P)
fe = pd.DataFrame({'sport': 'NFL', 'game_id': g.game_id, 'season': g.season,
                   'wx_outdoor': g.outdoor, 'wx_temp': g.temp_g, 'wx_humidity': g.hum_g, 'wx_wind': g.wind_g, 'wx_precip': g.precip_g,
                   'wx_snow': g.snow_g, 'home_temp_normal': g.home_normal, 'away_temp_normal': g.away_normal,
                   'home_temp_shock': g.home_shock, 'away_temp_shock': g.away_shock,
                   'away_cold_shock_10f': (-g.away_shock).clip(lower=0) / 10, 'home_cold_shock_10f': (-g.home_shock).clip(lower=0) / 10,
                   'away_dome_team': g.away_dome_team == True, 'away_warm_climate': g.away_warm_team == True,
                   'home_dome_team': g.home_dome_team == True, 'home_warm_climate': g.home_warm_team == True,
                   'wx_usable': g.usable,
                   'wx_note': 'kickoff-recorded weather (gamebook), not the pre-game forecast'})
fe.to_parquet(FEAT, index=False)
print('spec ok; features', fe.shape)
