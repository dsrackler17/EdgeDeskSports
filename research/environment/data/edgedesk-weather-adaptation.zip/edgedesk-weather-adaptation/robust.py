"""Study 6 robustness: era splits for the two candidate effects, cell counts, rain-total bootstrap."""
import sys, json, numpy as np, pandas as pd, importlib.util
P, S, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
# reuse the model module's prepared frame and fe_model without re-running its full suite
src = open(__file__.replace('robust.py', 'models.py')).read()
head = src.split("CLASS = ['away_warm_cold'")[0]
ns = {'__name__': 'robust', 'sys': sys}
sys.argv = [sys.argv[0], P, S, OUT]
exec(compile(head, 'models_head', 'exec'), ns)
u, fe_model, RES = ns['u'], ns['fe_model'], ns['RES']
SHOCK = ['away_cold_shock', 'home_cold_shock', 'away_heat_shock', 'home_heat_shock', 'away_dome_cold', 'home_dome_cold', 'away_dome_heat', 'home_dome_heat']
RAIN = ['away_dome_rain', 'home_dome_rain', 'away_warm_rain', 'home_warm_rain']
BASE = ns['BASE']
out = {}
for lab, d in [('2000-2012', u[u.season <= 2012]), ('2013-2025', u[u.season >= 2013])]:
    yrs = [c for c in BASE if not c.startswith('yr_') or d[c].sum() > 0]
    a = fe_model(d, 'v_ats', SHOCK + yrs, f'temp_shock_{lab}')
    b = fe_model(d, 'over_margin', RAIN + yrs, f'rain_totals_{lab}', fe='additive')
    c = fe_model(d, 'over_margin', RAIN + yrs, f'rain_totals_noFE_{lab}', fe=None)
    out[lab] = dict(n=len(d), away_cold_shock_ats=a['coefs']['away_cold_shock'], precip_over=b['coefs']['precip'],
                    precip_over_noFE=c['coefs']['precip'], n_precip=int(d.precip.sum()))
# rain, market only (no team FE): over_margin on precip + wind + temp bins + season
r = fe_model(u, 'over_margin', ['precip', 'snow', 'wind10'] + ns['TB'] + ns['YR'], 'rain_totals_market_only', fe=None)
out['precip_over_market_only'] = r['coefs']['precip']
# bootstrap over stadiums for precip over-rate
rng = np.random.default_rng(9); d = u[u.precip_g & u.over.notna()]; vs = d.stadium_id.unique()
by = {v: d[d.stadium_id == v].over.to_numpy() for v in vs}
st = [np.concatenate([by[v] for v in rng.choice(vs, len(vs))]).mean() for _ in range(2000)]
out['precip_over_rate'] = [float(d.over.mean()), float(np.percentile(st, 2.5)), float(np.percentile(st, 97.5)), int(len(d)), int(len(vs))]
dd = u[~u.precip_g & u.over.notna()]; out['dry_over_rate'] = [float(dd.over.mean()), int(len(dd))]
# cell counts
out['cells'] = {c: int(u[c].sum()) for c in ['away_warm_cold', 'away_dome_cold', 'home_warm_cold', 'home_dome_cold', 'away_dome_heat',
                                             'home_dome_heat', 'away_dome_rain', 'home_dome_rain', 'away_warm_rain', 'home_warm_rain', 'humid_heat']}
out['heat_early'] = int((u.heat & u.early).sum())
out['shock_dist'] = u.away_shock.describe().round(2).to_dict()
out['dome_kick_cold_fga'] = None
json.dump(out, open(f'{OUT}/robust.json', 'w'), indent=1, default=str)
print(json.dumps(out, indent=1, default=str))
