"""Defensive Fatigue: defense-game workload table for NFL (nflverse) and CFB (ESPN via sportsdataverse).

One row per defense per game:
  workload (1st half): snaps_h1 = opponent scrimmage plays faced, long_h1 = opponent drives of 10+ plays,
                       own3o_h1 = own-offense three-and-outs (drive of <=3 scrimmage plays ending in a punt),
                       ownplays_h1 = own-offense scrimmage plays, nh_h1 = no-huddle snaps faced (NFL only)
  outcomes (competitive plays only, offense win prob 0.10-0.90):
                       epa_h1/epa_h2/epa_q4 = EPA per play allowed, succ_*, expl_* (explosive rate allowed)
Explosive = run of 10+ yards or pass of 20+ yards (NFL); run 15+ or pass 20+ (CFB, matching the altitude study).
"""
import sys, numpy as np, pandas as pd, pyarrow.parquet as pq

S, OUT = sys.argv[1], sys.argv[2]

def defense_games(p, sport):
    """p: standardized play frame with game_id, season, off, deff, home, away, qtr, sc, epa, succ, wp, yds, is_rush,
       is_pass, drive, drive_result_punt, nh, hs, as_ (running home/away score)."""
    p = p[p.off.notna() & p.deff.notna()].copy()
    p['h1'] = p.qtr <= 2; p['h2'] = p.qtr.isin([3, 4]); p['q4'] = p.qtr == 4
    expl_run = 10 if sport == 'NFL' else 15
    p['expl'] = p.sc & ((p.is_rush & (p.yds >= expl_run)) | (p.is_pass & (p.yds >= 20)))
    p['comp'] = p.sc & p.wp.between(0.10, 0.90)
    # drives: scrimmage plays per drive and how they ended
    dr = p[p.sc].groupby(['game_id', 'off', 'drive']).agg(n=('sc', 'size'), h1=('h1', 'first'), punt=('drive_result_punt', 'max')).reset_index()
    dr['three_out'] = (dr.n <= 3) & dr.punt
    d1 = dr[dr.h1]
    off_h1 = d1.groupby(['game_id', 'off']).agg(own3o_h1=('three_out', 'sum'), ownplays_h1=('n', 'sum'), owndrives_h1=('n', 'size')).reset_index()
    faced_h1 = d1.groupby(['game_id', 'off']).agg(long_h1=('n', lambda s: (s >= 10).sum()), opp_drives_h1=('n', 'size')).reset_index()
    base = p[p.sc].groupby(['game_id', 'deff']).agg(season=('season', 'first'), off=('off', 'first'), home=('home', 'first'), away=('away', 'first'),
            snaps=('sc', 'size'), snaps_h1=('h1', 'sum'), snaps_h2=('h2', 'sum'), nh_h1=('nh_h1', 'sum')).reset_index()
    for half in ['h1', 'h2', 'q4']:
        m = p[p.comp & p[half]]
        a = m.groupby(['game_id', 'deff']).agg(**{f'epa_{half}': ('epa', 'mean'), f'succ_{half}': ('succ', 'mean'),
                                                   f'expl_{half}': ('expl', 'mean'), f'n_{half}': ('sc', 'size')}).reset_index()
        base = base.merge(a, on=['game_id', 'deff'], how='left')
    allc = p[p.comp].groupby(['game_id', 'deff']).agg(epa_all=('epa', 'mean'), n_all=('sc', 'size')).reset_index()
    base = base.merge(allc, on=['game_id', 'deff'], how='left')
    base = base.merge(off_h1.rename(columns={'off': 'deff'}), on=['game_id', 'deff'], how='left')
    base = base.merge(faced_h1.rename(columns={'off': 'off'}), on=['game_id', 'off'], how='left')
    # halftime score margin from the defense's perspective
    ht = p[p.qtr <= 2].groupby('game_id')[['hs', 'as_']].max()
    base = base.merge(ht.reset_index(), on='game_id', how='left')
    base['def_is_home'] = base.deff == base.home
    base['half_margin'] = np.where(base.def_is_home, base.hs - base.as_, base.as_ - base.hs)
    for c in ['own3o_h1', 'ownplays_h1', 'owndrives_h1', 'long_h1', 'opp_drives_h1']:
        base[c] = base[c].fillna(0)
    base['sport'] = sport
    return base.drop(columns=['hs', 'as_'])

# ---------------- NFL ----------------
nfl = []
GMAP = pd.read_csv(f'{S}/nfl/games.csv', usecols=['game_id', 'home_team', 'away_team']).set_index('game_id')
cols =['game_id', 'season', 'posteam', 'defteam', 'home_team', 'away_team', 'qtr', 'play_type', 'epa', 'success', 'wp',
        'yards_gained', 'qb_kneel', 'qb_spike', 'fixed_drive', 'fixed_drive_result', 'no_huddle', 'total_home_score', 'total_away_score', 'season_type']
for y in range(1999, 2026):
    avail = set(pq.read_schema(f'{S}/nfl/pbp/{y}.parquet').names)
    p = pd.read_parquet(f'{S}/nfl/pbp/{y}.parquet', columns=[c for c in cols if c in avail])
    p = p[p.season_type == 'REG'] if 'season_type' in p else p
    # pbp uses current franchise codes (LV/LAC/LA) in every season; remap to games.csv codes by home/away role
    gh, ga = p.game_id.map(GMAP.home_team), p.game_id.map(GMAP.away_team)
    p = p.assign(posteam=np.where(p.posteam == p.home_team, gh, np.where(p.posteam == p.away_team, ga, None)),
                 defteam=np.where(p.defteam == p.home_team, gh, np.where(p.defteam == p.away_team, ga, None)),
                 home_team=gh, away_team=ga)
    q = pd.DataFrame({'game_id': p.game_id, 'season': p.season, 'off': p.posteam, 'deff': p.defteam, 'home': p.home_team, 'away': p.away_team,
                      'qtr': p.qtr, 'epa': p.epa, 'succ': p.success, 'wp': p.wp, 'yds': p.yards_gained,
                      'is_rush': p.play_type == 'run', 'is_pass': p.play_type == 'pass', 'drive': p.fixed_drive,
                      'drive_result_punt': p.fixed_drive_result == 'Punt',
                      'hs': p.total_home_score, 'as_': p.total_away_score})
    q['sc'] = q.is_rush | q.is_pass
    q['sc'] &= (p.qb_kneel.fillna(0) == 0) & (p.qb_spike.fillna(0) == 0)
    q['nh_h1'] = q.sc & (p.no_huddle.fillna(0) == 1) & (q.qtr <= 2)
    nfl.append(defense_games(q, 'NFL'))
    print('NFL', y, flush=True)
nfl = pd.concat(nfl, ignore_index=True)

# ---------------- CFB ----------------
cfb = []
ccols = ['game_id', 'season', 'pos_team_id', 'def_pos_team_id', 'homeTeamId', 'awayTeamId', 'period', 'EPA', 'EPA_success', 'wp_before',
         'statYardage', 'rush', 'pass', 'sack', 'scrimmage_play', 'kneel_down', 'drive.id', 'drive.result', 'end.homeScore', 'end.awayScore', 'seasonType',
         'penalty_no_play']
for y in range(2004, 2026):
    f = f'{S}/dl/pbp/espn_{y}.parquet'
    avail = set(pq.read_schema(f).names)
    p = pd.read_parquet(f, columns=[c for c in ccols if c in avail])
    rush = p.rush.fillna(False).astype(bool); pas = p['pass'].fillna(False).astype(bool) | p.sack.fillna(False).astype(bool)
    sc = (rush | pas) & ~p.kneel_down.fillna(False).astype(bool) & ~p.penalty_no_play.fillna(False).astype(bool)
    q = pd.DataFrame({'game_id': p.game_id, 'season': p.season, 'off': pd.to_numeric(p.pos_team_id, errors='coerce'),
                      'deff': pd.to_numeric(p.def_pos_team_id, errors='coerce'), 'home': pd.to_numeric(p.homeTeamId, errors='coerce'),
                      'away': pd.to_numeric(p.awayTeamId, errors='coerce'), 'qtr': p.period, 'epa': p.EPA,
                      'succ': pd.to_numeric(p.EPA_success, errors='coerce'), 'wp': p.wp_before, 'yds': pd.to_numeric(p.statYardage, errors='coerce'),
                      'is_rush': rush, 'is_pass': pas, 'drive': p['drive.id'], 'drive_result_punt': p['drive.result'] == 'PUNT',
                      'hs': p['end.homeScore'], 'as_': p['end.awayScore'], 'sc': sc})
    q['nh_h1'] = False
    cfb.append(defense_games(q, 'CFB'))
    print('CFB', y, flush=True)
cfb = pd.concat(cfb, ignore_index=True)
for c in ['deff', 'off', 'home', 'away']:
    cfb[c] = cfb[c].astype('Int64').astype(str)
dg = pd.concat([nfl, cfb], ignore_index=True)
dg['game_id'] = dg.game_id.astype(str)
dg.to_parquet(f'{OUT}/defense_games.parquet')
print(dg.groupby('sport').size(), dg.groupby('sport')[['snaps_h1', 'epa_h1', 'epa_h2', 'own3o_h1']].mean().round(3))
