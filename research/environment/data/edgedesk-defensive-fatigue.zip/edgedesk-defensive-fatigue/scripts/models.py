"""Defensive Fatigue models. Unit = defense-game. FE = defense team-season + offense team-season.
SEs clustered by defense team-season. Outcomes use competitive plays (offense win prob 0.10-0.90).

M_bins : 2H (and Q4) EPA allowed on 1H snaps-faced bins, controlling 1H EPA allowed (regression to the mean),
         halftime margin bins, season.
M_lin  : same with linear snaps_h1 (per 5 snaps).
M_diff : within-game change (2H minus 1H) on bins, same controls minus 1H EPA.
IV     : snaps_h1 instrumented by own-offense 1H three-and-outs (workload driven by the defense's own offense).
M_cum  : full-game competitive EPA allowed on previous-game snaps faced (pre-game knowable).
MARKET : home ATS margin and over margin on home/away previous-game defensive snaps (NFL nflverse lines, CFB SBR 2006-2019).
"""
import sys, json, numpy as np, pandas as pd, pyfixest as pf

S, OUT = sys.argv[1], sys.argv[2]
dg = pd.read_parquet(f'{S}/fatigue/defense_games.parquet')
dg['def_ts'] = dg.sport + '_' + dg.deff + '_' + dg.season.astype(str)
dg['off_ts'] = dg.sport + '_' + dg.off + '_' + dg.season.astype(str)
cnt_d = dg.groupby('def_ts').size(); cnt_o = dg.groupby('off_ts').size()
dg = dg[dg.def_ts.map(cnt_d).ge(5) & dg.off_ts.map(cnt_o).ge(5)].copy()
dg['bin'] = pd.cut(dg.snaps_h1, [-1, 24, 29, 34, 39, 200], labels=['<25', '25-29', '30-34', '35-39', '40+']).astype(str)
dg['hm_bin'] = pd.cut(dg.half_margin.clip(-40, 40), [-41, -14, -7, -1, 0, 7, 14, 41]).astype(str)
dg['snaps5'] = dg.snaps_h1 / 5
dg['d_epa'] = dg.epa_h2 - dg.epa_h1
dg['d_succ'] = dg.succ_h2 - dg.succ_h1

R = {'models': [], 'desc': {}}
def tidy(fit, keep):
    t = fit.tidy()
    return {k: [float(t.loc[k, 'Estimate']), float(t.loc[k, 'Std. Error']), float(t.loc[k, 'Pr(>|t|)'])] for k in t.index if any(k.startswith(x) for x in keep)}
def run(name, sport, fml, d, keep, w=None):
    fit = pf.feols(fml, data=d, vcov={'CRV1': 'def_ts'}, weights=w)
    R['models'].append(dict(name=name, sport=sport, formula=fml, n=int(fit._N), coefs=tidy(fit, keep)))
    return fit

for sport in ['NFL', 'CFB']:
    d = dg[(dg.sport == sport)].dropna(subset=['epa_h1', 'epa_h2', 'n_h1', 'n_h2'])
    d = d[(d.n_h1 >= 10) & (d.n_h2 >= 10)]
    dq = d.dropna(subset=['epa_q4', 'n_q4']); dq = dq[dq.n_q4 >= 5]
    # descriptive dose-response
    desc = d.groupby('bin').agg(n=('game_id', 'size'), snaps=('snaps_h1', 'mean'), epa_h1=('epa_h1', 'mean'), epa_h2=('epa_h2', 'mean'),
                                d_epa=('d_epa', 'mean'), succ_h1=('succ_h1', 'mean'), succ_h2=('succ_h2', 'mean'),
                                expl_h1=('expl_h1', 'mean'), expl_h2=('expl_h2', 'mean'))
    q4d = dq.groupby('bin').agg(epa_q4=('epa_q4', 'mean'), n_q4=('game_id', 'size'))
    desc = desc.join(q4d)
    R['desc'][sport] = desc.reset_index().to_dict('records')
    ctrl = 'epa_h1 + C(hm_bin)'
    run('bins_h2', sport, f"epa_h2 ~ C(bin, Treatment('30-34')) + {ctrl} | def_ts + off_ts", d, ['C(bin'], 'n_h2')
    run('bins_q4', sport, f"epa_q4 ~ C(bin, Treatment('30-34')) + {ctrl} | def_ts + off_ts", dq, ['C(bin'], 'n_q4')
    run('lin_h2', sport, f"epa_h2 ~ snaps5 + {ctrl} | def_ts + off_ts", d, ['snaps5'], 'n_h2')
    run('lin_q4', sport, f"epa_q4 ~ snaps5 + {ctrl} | def_ts + off_ts", dq, ['snaps5'], 'n_q4')
    run('lin_succ_h2', sport, f"succ_h2 ~ snaps5 + succ_h1 + C(hm_bin) | def_ts + off_ts", d, ['snaps5'], 'n_h2')
    run('lin_expl_h2', sport, f"expl_h2 ~ snaps5 + expl_h1 + C(hm_bin) | def_ts + off_ts", d, ['snaps5'], 'n_h2')
    run('long_h2', sport, f"epa_h2 ~ long_h1 + {ctrl} | def_ts + off_ts", d, ['long_h1'], 'n_h2')
    run('diff_bins', sport, f"d_epa ~ C(bin, Treatment('30-34')) + C(hm_bin) | def_ts + off_ts", d, ['C(bin'])
    # own-offense three-and-outs: reduced form and IV
    run('rf_own3o_h2', sport, f"epa_h2 ~ own3o_h1 + {ctrl} | def_ts + off_ts", d, ['own3o_h1'], 'n_h2')
    run('fs_own3o', sport, f"snaps5 ~ own3o_h1 + {ctrl} | def_ts + off_ts", d, ['own3o_h1'])
    fit = pf.feols(f"epa_h2 ~ {ctrl} | def_ts + off_ts | snaps5 ~ own3o_h1", data=d, vcov={'CRV1': 'def_ts'})
    R['models'].append(dict(name='iv_h2', sport=sport, n=int(fit._N), coefs=tidy(fit, ['snaps5'])))
    fit = pf.feols(f"epa_q4 ~ {ctrl} | def_ts + off_ts | snaps5 ~ own3o_h1", data=dq, vcov={'CRV1': 'def_ts'})
    R['models'].append(dict(name='iv_q4', sport=sport, n=int(fit._N), coefs=tidy(fit, ['snaps5'])))
    if sport == 'NFL':
        dn = d.assign(nh5=d.nh_h1 / 5)
        run('nohuddle_h2', sport, f"epa_h2 ~ nh5 + snaps5 + {ctrl} | def_ts + off_ts", dn, ['nh5', 'snaps5'], 'n_h2')

# ---------- cumulative workload (previous game) ----------
dg = dg.sort_values(['sport', 'deff', 'season', 'game_id'])
# order games by date proxy: NFL game_id sorts by season_week; CFB ESPN ids increase over a season
dg['prev_snaps'] = dg.groupby(['sport', 'deff', 'season']).snaps.shift()
dg['std_snaps'] = dg.groupby(['sport', 'deff', 'season']).snaps.transform(lambda s: s.shift().expanding().mean())
dg['prev_snaps10'] = dg.prev_snaps / 10
for sport in ['NFL', 'CFB']:
    d = dg[(dg.sport == sport)].dropna(subset=['epa_all', 'prev_snaps'])
    run('cum_prev', sport, "epa_all ~ prev_snaps10 | def_ts + off_ts", d, ['prev_snaps10'], 'n_all')

# ---------- market ----------
G = pd.read_parquet(f'{S}/shared/nfl_games.parquet')
G = G[G.game_type == 'REG']
nd = dg[dg.sport == 'NFL'].set_index(['game_id', 'deff'])
G['h_prev'] = [nd.prev_snaps.get((g, h), np.nan) for g, h in zip(G.game_id, G.home_team)]
G['a_prev'] = [nd.prev_snaps.get((g, a), np.nan) for g, a in zip(G.game_id, G.away_team)]
G['prev_diff10'] = (G.h_prev - G.a_prev) / 10
G['prev_sum10'] = (G.h_prev + G.a_prev) / 10
m = G.dropna(subset=['prev_diff10', 'home_ats', 'over_margin'])
for nm, y, x in [('mkt_ats', 'home_ats', 'prev_diff10'), ('mkt_total', 'over_margin', 'prev_sum10')]:
    fit = pf.feols(f'{y} ~ {x} + C(season)', data=m, vcov={'CRV1': 'home_team'})
    R['models'].append(dict(name=nm, sport='NFL', n=int(fit._N), coefs=tidy(fit, [x])))
    m2 = m.assign(cover=(m[y] > 0).astype(float)); m2 = m2[m[y] != 0]
    hi = m2[m2[x] >= m2[x].quantile(0.9)] if nm == 'mkt_ats' else m2[m2[x] >= m2[x].quantile(0.9)]
    R['desc'][f'NFL_{nm}_top_decile'] = dict(n=int(len(hi)), rate=float(hi.cover.mean()))
P = pd.read_parquet(f'{S}/panel.parquet')
P = P[P['sample'] == 'verified_venue_2001_2021'].dropna(subset=['v_ats'])
cd = dg[dg.sport == 'CFB'].set_index(['game_id', 'deff'])
P['gid'] = P.game_id.astype('int64').astype(str)
P['h_prev'] = [cd.prev_snaps.get((g, str(int(h))), np.nan) for g, h in zip(P.gid, P.home_id)]
P['a_prev'] = [cd.prev_snaps.get((g, str(int(a))), np.nan) for g, a in zip(P.gid, P.away_id)]
P['prev_diff10'] = (P.h_prev - P.a_prev) / 10
P['home_ats'] = -P.v_ats
mc = P.dropna(subset=['prev_diff10'])
fit = pf.feols('home_ats ~ prev_diff10 + C(season)', data=mc, vcov={'CRV1': 'venue_id'})
R['models'].append(dict(name='mkt_ats', sport='CFB', n=int(fit._N), coefs=tidy(fit, ['prev_diff10'])))

# ---------- pre-game feature file ----------
nfl_pace = []
tg = pd.read_parquet(f'{S}/shared/nfl_team_games.parquet').sort_values(['team', 'season', 'game_id'])
tg['std_pace'] = tg.groupby(['team', 'season']).plays.transform(lambda s: s.shift().expanding().mean())
tg['std_nh_rate'] = (tg.groupby(['team', 'season']).nh.transform(lambda s: s.shift().expanding().sum()) /
                     tg.groupby(['team', 'season']).plays.transform(lambda s: s.shift().expanding().sum()))
tgi = tg.set_index(['game_id', 'team'])
ndg = dg[dg.sport == 'NFL'].set_index(['game_id', 'deff'])
F = G[['game_id', 'season', 'home_team', 'away_team']].copy()
for side, col in [('home', 'home_team'), ('away', 'away_team')]:
    F[f'{side}_prev_def_snaps'] = [ndg.prev_snaps.get((g, t), np.nan) for g, t in zip(F.game_id, F[col])]
    F[f'{side}_std_def_snaps'] = [ndg.std_snaps.get((g, t), np.nan) for g, t in zip(F.game_id, F[col])]
    F[f'{side}_std_off_pace'] = [tgi.std_pace.get((g, t), np.nan) for g, t in zip(F.game_id, F[col])]
    F[f'{side}_std_nohuddle_rate'] = [tgi.std_nh_rate.get((g, t), np.nan) for g, t in zip(F.game_id, F[col])]
F['sport'] = 'NFL'
# CFB: from defense_games (snaps as offense pace = opponent's snaps faced)
c = dg[dg.sport == 'CFB'].copy()
c['off_plays'] = c.groupby('game_id').snaps.transform('sum') - c.snaps
c = c.sort_values(['deff', 'season', 'game_id'])
c['std_off_pace'] = c.groupby(['deff', 'season']).off_plays.transform(lambda s: s.shift().expanding().mean())
ci_ = c.set_index(['game_id', 'deff'])
games = c.drop_duplicates('game_id')[['game_id', 'season', 'home', 'away']]
CF = games.rename(columns={'home': 'home_team', 'away': 'away_team'}).copy()
for side, col in [('home', 'home_team'), ('away', 'away_team')]:
    CF[f'{side}_prev_def_snaps'] = [ci_.prev_snaps.get((g, t), np.nan) for g, t in zip(CF.game_id, CF[col])]
    CF[f'{side}_std_def_snaps'] = [ci_.std_snaps.get((g, t), np.nan) for g, t in zip(CF.game_id, CF[col])]
    CF[f'{side}_std_off_pace'] = [ci_.std_off_pace.get((g, t), np.nan) for g, t in zip(CF.game_id, CF[col])]
    CF[f'{side}_std_nohuddle_rate'] = np.nan
CF['sport'] = 'CFB'
feat = pd.concat([F, CF], ignore_index=True)
feat['game_id'] = feat.game_id.astype(str)
feat.to_parquet(sys.argv[3])
dg.to_parquet(f'{OUT}/defense_games_final.parquet')
R['n'] = {s: int((dg.sport == s).sum()) for s in ['NFL', 'CFB']}
R['seasons'] = {s: [int(dg[dg.sport == s].season.min()), int(dg[dg.sport == s].season.max())] for s in ['NFL', 'CFB']}
json.dump(R, open(f'{OUT}/results.json', 'w'), indent=1, default=float)
print('done', len(R['models']))
