"""Defensive Fatigue results -> EdgeDesk study spec (all numbers read from results.json)."""
import sys, json, pandas as pd
R = json.load(open(sys.argv[1])); OUT = sys.argv[2]
M = {(m['sport'], m['name']): m for m in R['models']}
def co(s, n, k=None):
    c = M[(s, n)]['coefs']; k = k or next(iter(c)); return c[k]
def ci(v, k=1, d=3): b, se = v[0] * k, v[1] * k; return f'{b:+.{d}f} [{b-1.96*se:+.{d}f}, {b+1.96*se:+.{d}f}]'
def p(v): return f'{v[2]:.2f}'
def binkey(s, n, b):
    return next(k for k in M[(s, n)]['coefs'] if k.endswith(f'[T.{b}]'))
bins = ['<25', '25-29', '35-39', '40+']

# dose-response SVG: adjusted 2H EPA allowed vs the 30-34 bin, NFL (teal) and CFB (amber)
W, left, right, rowh = 680, 120, 24, 40
H = 50 + rowh * 5 + 30
lo, hi = -0.06, 0.06
X = lambda v: left + (v - lo) / (hi - lo) * (W - left - right)
s = [f'<svg viewBox="0 0 {W} {H}" class="forest" role="img" aria-label="Adjusted second-half EPA per play allowed by first-half snaps faced">']
for t in [-0.06, -0.04, -0.02, 0, 0.02, 0.04, 0.06]:
    s.append(f'<line x1="{X(t):.1f}" x2="{X(t):.1f}" y1="34" y2="{H-26}" class="{"zero" if t == 0 else "grid"}"/>')
    s.append(f'<text x="{X(t):.1f}" y="{H-8}" class="tick" text-anchor="middle">{t:+.2f}</text>')
s.append(f'<text x="{left}" y="18" class="axl">2nd-half EPA/play allowed vs 30–34 first-half snaps (positive = defense worse)</text>')
order = ['<25', '25-29', '30-34', '35-39', '40+']
for i, b in enumerate(order):
    y = 52 + i * rowh
    s.append(f'<text x="{left-12}" y="{y+4}" text-anchor="end" class="lab">{b.replace("<", "&lt;")} snaps</text>')
    for sp, dy, cls in [('NFL', -6, ''), ('CFB', 6, ' b')]:
        if b == '30-34':
            s.append(f'<circle cx="{X(0):.1f}" cy="{y+dy}" r="4" class="pt{cls}"/>'); continue
        v = M[(sp, 'bins_h2')]['coefs'][binkey(sp, 'bins_h2', b)]
        s.append(f'<line x1="{X(max(lo, v[0]-1.96*v[1])):.1f}" x2="{X(min(hi, v[0]+1.96*v[1])):.1f}" y1="{y+dy}" y2="{y+dy}" class="ci{cls}"/>')
        s.append(f'<circle cx="{X(v[0]):.1f}" cy="{y+dy}" r="4.5" class="pt{cls}"/>')
s.append(f'<text x="{W-right}" y="18" class="axl" text-anchor="end">● NFL  ● CFB</text></svg>')
svg = ''.join(s).replace('● NFL  ● CFB', 'teal NFL · amber CFB')

def desc_rows(sp):
    d = pd.DataFrame(R['desc'][sp]).set_index('bin').loc[order]
    return [[f'{b} snaps', f'{int(r.n):,}', f'{r.epa_h1:+.3f}', f'{r.epa_h2:+.3f}', f'{r.d_epa:+.3f}', f'{r.epa_q4:+.3f}',
             f'{100*r.succ_h1:.1f}% → {100*r.succ_h2:.1f}%'] for b, r in d.iterrows()]

adj_rows = []
for lab, n, k, scale, d in [('2H EPA allowed, per +5 first-half snaps', 'lin_h2', None, 1, 3), ('Q4 EPA allowed, per +5 snaps', 'lin_q4', None, 1, 3),
                            ('2H success rate allowed, per +5 snaps (pp)', 'lin_succ_h2', None, 100, 2), ('2H explosive rate allowed, per +5 snaps (pp)', 'lin_expl_h2', None, 100, 2),
                            ('2H EPA allowed, per extra 10+ play drive faced', 'long_h2', None, 1, 3),
                            ('IV: 2H EPA, per +5 snaps caused by own three-and-outs', 'iv_h2', None, 1, 3), ('IV: Q4 EPA, per +5 snaps caused by own three-and-outs', 'iv_q4', None, 1, 3),
                            ('Next game: EPA allowed per +10 snaps faced last game', 'cum_prev', None, 1, 3)]:
    adj_rows.append([lab, ci(co('NFL', n), scale, d), p(co('NFL', n)), ci(co('CFB', n), scale, d), p(co('CFB', n))])
nh = M[('NFL', 'nohuddle_h2')]['coefs']['nh5']

fs_n, fs_c = co('NFL', 'fs_own3o'), co('CFB', 'fs_own3o')
mk_ats, mk_tot, mk_cfb = co('NFL', 'mkt_ats'), co('NFL', 'mkt_total'), co('CFB', 'mkt_ats')
nn, nc = M[('NFL', 'lin_h2')]['n'], M[('CFB', 'lin_h2')]['n']
dn = pd.DataFrame(R['desc']['NFL']).set_index('bin'); dc = pd.DataFrame(R['desc']['CFB']).set_index('bin')

spec = {
 'slug': 'defensive-fatigue', 'module': 'Defensive Fatigue', 'status': 'null', 'status_label': 'No effect after controls',
 'title': 'Do tired defenses break late?',
 'question': 'Does a defense that faces a heavy first-half workload become measurably more vulnerable in the second half and fourth quarter?',
 'lede': f'Across {nn:,} NFL and {nc:,} college defensive performances, a big first-half workload does not make a defense worse after halftime once you account for who is playing and the score. The apparent "fatigue" in raw numbers is the reverse: busy defenses were having bad halves and simply regressed.',
 'scope': f'NFL {R["seasons"]["NFL"][0]}–{R["seasons"]["NFL"][1]} regular season · CFB {R["seasons"]["CFB"][0]}–{R["seasons"]["CFB"][1]}', 'updated': '2026-10-17',
 'findings': [
   f'Raw numbers suggest defenses get **better** after a heavy first half: NFL defenses facing 40+ first-half snaps allowed {dn.loc["40+"].epa_h1:+.3f} EPA/play before halftime and {dn.loc["40+"].epa_h2:+.3f} after. That is regression to the mean. Defenses face many snaps because the opponent is moving the ball well, and that does not persist.',
   f'After controlling for first-half performance, halftime score, defense team-season and offense team-season, each extra 5 first-half snaps changes 2nd-half EPA allowed by {ci(co("NFL","lin_h2"))} in the NFL and {ci(co("CFB","lin_h2"))} in CFB. Both are near zero, and the intervals rule out anything larger than about 0.01 EPA per play.',
   f'Fourth-quarter EPA shows the same: {ci(co("NFL","lin_q4"))} (NFL) and {ci(co("CFB","lin_q4"))} (CFB) per 5 snaps.',
   f'Using workload created by the defense’s own offense going three-and-out (which adds {fs_n[0]*5:.1f} NFL and {fs_c[0]*5:.1f} CFB first-half snaps per three-and-out) gives 2nd-half effects of {ci(co("NFL","iv_h2"))} (NFL) and {ci(co("CFB","iv_h2"))} (CFB) per 5 snaps. Neither is distinguishable from zero.',
   f'Facing no-huddle tempo in the first half does not matter either: {ci(nh)} 2nd-half EPA per 5 no-huddle snaps faced (NFL).',
   f'Last week’s workload does not carry into this week: {ci(co("NFL","cum_prev"))} (NFL) and {ci(co("CFB","cum_prev"))} (CFB) EPA per play per 10 extra snaps faced in the previous game.',
   f'Against the market, last week’s workload gap does not predict covers (NFL {ci(mk_ats,1,2)} pts per 10 snaps, p = {p(mk_ats)}; CFB {ci(mk_cfb,1,2)}, p = {p(mk_cfb)}). Combined previous-game snaps lean toward the over by {mk_tot[0]:+.2f} points per 10 snaps (p = {p(mk_tot)}), a single result among about 30 tests that needs out-of-sample confirmation.'],
 'sections': [
   {'h': 'Raw pattern by first-half snaps faced (NFL)', 'p': ['EPA per play allowed on competitive plays only (offense win probability between 10% and 90%), so garbage time is excluded. Positive EPA is good for the offense.'],
    'table': {'cols': ['First-half snaps faced', 'Defense-games', '1H EPA allowed', '2H EPA allowed', 'Change', 'Q4 EPA allowed', 'Success rate allowed 1H → 2H'],
              'rows': desc_rows('NFL'), 'num': [1, 2, 3, 4, 5], 'caption': 'The "change" column falls as workload rises because heavy first halves are unusually bad halves for the defense, not because rested defenses fade.'}},
   {'h': 'Raw pattern by first-half snaps faced (CFB)', 'table': {'cols': ['First-half snaps faced', 'Defense-games', '1H EPA allowed', '2H EPA allowed', 'Change', 'Q4 EPA allowed', 'Success rate allowed 1H → 2H'],
              'rows': desc_rows('CFB'), 'num': [1, 2, 3, 4, 5], 'caption': 'Games where either team played fewer than five tracked games that season (mostly FCS opponents) are excluded.'}},
   {'h': 'Adjusted dose-response', 'p': ['Second-half EPA allowed relative to defenses that faced 30–34 first-half snaps, controlling for the defense’s own first-half EPA, halftime margin and team-season effects for both sides. Bars are 95% intervals with standard errors clustered by defense team-season.'],
    'svg': svg},
   {'h': 'All adjusted estimates', 'table': {'cols': ['Effect on the defense', 'NFL [95% CI]', 'NFL p', 'CFB [95% CI]', 'CFB p'], 'rows': adj_rows, 'num': [1, 2, 3, 4],
     'caption': 'Positive values mean the defense allowed more. Models are weighted by plays and include defense and offense team-season fixed effects. The IV rows use own-offense first-half three-and-outs as the source of extra workload, which is less tied to the defense’s own quality.'}}],
 'model_verdict': 'Not added to the model. First-half workload, tempo faced and last week’s workload show no measurable effect on later defensive performance after controls, in either the NFL or college football. The previous-game workload fields are kept as observed context and passed to the combined model, where the small totals lean will be tested out of sample before anything changes.',
 'data': [['NFL', f'nflverse play-by-play, regular season {R["seasons"]["NFL"][0]}–{R["seasons"]["NFL"][1]}; {R["n"]["NFL"]:,} defense-games built, {nn:,} with at least 10 competitive plays in each half.'],
          ['CFB', f'ESPN play-by-play via sportsdataverse, {R["seasons"]["CFB"][0]}–{R["seasons"]["CFB"][1]}; {R["n"]["CFB"]:,} defense-games built, {nc:,} used.'],
          ['Workload', 'Opponent scrimmage plays faced (team-level snaps), opponent drives of 10+ plays, own-offense three-and-outs, no-huddle snaps faced (NFL).'],
          ['Market', 'NFL: nflverse spread and total lines. CFB: SBR archive spreads 2006–2019 (Pinnacle where present). Neither is a licensed closing feed.']],
 'gaps': [['Missed tackles', 'Not recorded in any public play-by-play, so not measured.'],
          ['Player snap counts', 'Available for the NFL only from 2012; this study uses team-level snaps faced. Rotation depth was not tested.'],
          ['Second-half lines', 'No historical 2H or live lines, so the market test uses full-game spreads and totals with pre-game workload.'],
          ['Time between drives', 'Real-time rest between a defense’s series is not reliably recorded; own-offense three-and-outs stand in for short rest.']],
 'sources': [['nflverse play-by-play and schedules', 'https://github.com/nflverse/nflverse-data/releases'],
             ['sportsdataverse ESPN college play-by-play', 'https://github.com/sportsdataverse/sportsdataverse-data/releases'],
             ['CollegeFootballData / cfbfastR-data (SBR lines)', 'https://github.com/sportsdataverse/cfbfastR-data']],
 'zip': 'edgedesk-defensive-fatigue.zip'}
json.dump(spec, open(OUT, 'w'), indent=1, ensure_ascii=False)
print('ok')
