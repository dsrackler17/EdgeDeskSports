# EdgeDesk study: Defensive Fatigue

Question: does a defense that faces a heavy first-half workload get worse after halftime?

## Files
- `data/defense_games.csv.gz`: one row per defense per game (NFL 1999-2025 regular season, CFB 2004-2025). Workload fields (snaps_h1, long_h1, own3o_h1, ownplays_h1, nh_h1), outcomes on competitive plays (epa_h1/h2/q4, succ_*, expl_*), halftime margin, previous-game snaps.
- `data/pregame_features.parquet`: pre-game knowable features only (previous-game and season-to-date defensive snaps faced, season-to-date offensive pace, NFL no-huddle rate). No outcomes.
- `results/results.json`: every model (coefficient, SE, p, n) and the descriptive dose-response tables.
- `results/study_spec.json`: the published page content.
- `scripts/build.py` -> `scripts/models.py` -> `scripts/make_spec.py`.

## Reproduce
Inputs: nflverse play-by-play and games (github.com/nflverse/nflverse-data releases), ESPN college play-by-play (sportsdataverse-data releases `espn_cfb_pbp`), the EdgeDesk shared NFL tables (`nfl_games.parquet`, `nfl_team_games.parquet`) and the altitude study panel (CFB SBR lines).
1. `python3 build.py <data_dir> <work_dir>`
2. `python3 models.py <data_dir> <work_dir>/out <features_out.parquet>`
3. `python3 make_spec.py <work_dir>/out/results.json <spec.json>`

## Method
Competitive plays only (offense win probability 0.10-0.90). Fixed effects for defense team-season and offense team-season; SEs clustered by defense team-season; regressions weighted by plays. Second-half outcome models control for the defense's own first-half EPA (regression to the mean) and halftime margin. IV: first-half snaps instrumented by own-offense three-and-outs.

## Not available
Missed tackles (not in public play-by-play), reliable clock time between a defense's series, historical second-half lines. Player snap counts exist for the NFL from 2012 but were not used (team-level snaps instead).
