"""Rest & Recovery: build NFL and CFB analysis panels.

NFL rest days come from nflverse (away_rest/home_rest). Week 1 rest is coded as 7 for every team
(a placeholder), so week 1 is excluded from rest categories. Categories (days since previous game):
  short  <= 5   (Thursday after Sunday = 4)
  mnf6   == 6   (Monday night to Sunday, or Sunday to Saturday)
  normal 7-9
  mini   10-12  (off a Thursday game)
  bye    >= 13
CFB: rest from the CFBD schedule (all opponents); bye >= 13, short <= 5, normal 6-12. First game excluded.
Consecutive road: number of straight games (including this one) played away from home
(true road or neutral) for the visiting team.
"""
import sys, numpy as np, pandas as pd

S, OUT = sys.argv[1], sys.argv[2]

# ---------------- NFL ----------------
g = pd.read_parquet(f'{S}/shared/nfl_games.parquet')
g = g.sort_values(['gameday', 'game_id']).reset_index(drop=True)
long = pd.concat([
    g[['game_id', 'season', 'gameday', 'week', 'home_team', 'overtime', 'location', 'away_travel_mi']].assign(team=g.home_team, home=g.location == 'Home', travel=g.home_travel_mi),
    g[['game_id', 'season', 'gameday', 'week', 'home_team', 'overtime', 'location', 'away_travel_mi']].assign(team=g.away_team, home=False, travel=g.away_travel_mi)])
long = long.sort_values(['team', 'season', 'gameday'])
long['prev_ot'] = long.groupby(['team', 'season']).overtime.shift().fillna(0)
long['prev_travel'] = long.groupby(['team', 'season']).travel.shift()
long['away_flag'] = (~long.home).astype(int)
def streak(s):
    out, c = [], 0
    for v in s:
        c = c + 1 if v else 0
        out.append(c)
    return out
long['consec_away'] = long.groupby(['team', 'season']).away_flag.transform(lambda s: pd.Series(streak(s.to_numpy()), index=s.index))
L = long.set_index(['game_id', 'team'])
for side in ['home', 'away']:
    key = list(zip(g.game_id, g[f'{side}_team']))
    g[f'{side}_prev_ot'] = L.prev_ot.reindex(key).to_numpy()
    g[f'{side}_prev_travel'] = L.prev_travel.reindex(key).to_numpy()
    g[f'{side}_consec_away'] = L.consec_away.reindex(key).to_numpy()
for side in ['home', 'away']:
    r = g[f'{side}_rest'].astype(float).where(g.week > 1)
    g[f'{side}_rest_c'] = r
    g[f'{side}_cat'] = pd.cut(r, [0, 5, 6, 9, 12, 99], labels=['short', 'mnf6', 'normal', 'mini', 'bye'])
g['rest_diff'] = (g.home_rest_c.clip(upper=15) - g.away_rest_c.clip(upper=15))
g['sport'] = 'NFL'
g['era'] = np.where(g.season <= 2010, '1999-2010', '2011-2025')
g.to_parquet(f'{OUT}/nfl_rest_panel.parquet')

# ---------------- CFB ----------------
c = pd.read_parquet(f'{S}/panel.parquet')
c = c[c['sample'] == 'verified_venue_2001_2021'].copy()
sch = pd.concat([pd.read_csv(f'{S}/dl/sched/{y}.csv', low_memory=False) for y in range(2001, 2022)], ignore_index=True)
sch = sch.dropna(subset=['home_points', 'away_points'])
sch['date'] = pd.to_datetime(sch.start_date, utc=True).dt.tz_convert('America/Chicago').dt.normalize()
lc = pd.concat([sch[['game_id', 'season', 'date', 'home_id']].rename(columns={'home_id': 'team'}).assign(away=sch.neutral_site == True),
                sch[['game_id', 'season', 'date', 'away_id']].rename(columns={'away_id': 'team'}).assign(away=True)])
lc = lc.sort_values(['team', 'season', 'date'])
lc['consec_away'] = lc.groupby(['team', 'season']).away.transform(lambda s: pd.Series(streak(s.to_numpy()), index=s.index))
LC = lc.drop_duplicates(['game_id', 'team']).set_index(['game_id', 'team'])
for side in ['home', 'away']:
    key = list(zip(c.game_id, c[f'{side}_id'].astype(int)))
    c[f'{side}_consec_away'] = LC.consec_away.reindex(key).to_numpy()
    r = c[f'{side}_rest'].astype(float)
    c[f'{side}_rest_c'] = r
    c[f'{side}_cat'] = pd.cut(r, [0, 5, 12, 999], labels=['short', 'normal', 'bye'])
# overtime from ESPN play-by-play periods (2004+)
ot = []
for y in range(2004, 2022):
    p = pd.read_parquet(f'{S}/dl/pbp/espn_{y}.parquet', columns=['game_id', 'period'])
    ot.append(p.groupby('game_id').period.max().gt(4).rename('ot').reset_index())
ot = pd.concat(ot); ot['game_id'] = pd.to_numeric(ot.game_id, errors='coerce')
sch = sch.merge(ot, on='game_id', how='left')
lo = pd.concat([sch[['game_id', 'season', 'date', 'home_id', 'ot']].rename(columns={'home_id': 'team'}),
                sch[['game_id', 'season', 'date', 'away_id', 'ot']].rename(columns={'away_id': 'team'})]).sort_values(['team', 'season', 'date'])
lo['prev_ot'] = lo.groupby(['team', 'season']).ot.shift()
LO = lo.drop_duplicates(['game_id', 'team']).set_index(['game_id', 'team'])
for side in ['home', 'away']:
    c[f'{side}_prev_ot'] = LO.prev_ot.reindex(list(zip(c.game_id, c[f'{side}_id'].astype(int)))).astype(float).to_numpy()
c['rest_diff'] = c.home_rest_c.clip(upper=21) - c.away_rest_c.clip(upper=21)
c['result'] = c.home_points - c.away_points
c['home_ats'] = -c.v_ats
c['sport'] = 'CFB'
c['era'] = np.where(c.season <= 2010, '2001-2010', '2011-2021')
c.to_parquet(f'{OUT}/cfb_rest_panel.parquet')

# ---------------- feature file (pre-game only) ----------------
fn = pd.DataFrame({'sport': 'NFL', 'game_id': g.game_id.astype(str), 'season': g.season,
                   'home_rest': g.home_rest_c, 'away_rest': g.away_rest_c, 'rest_diff': g.rest_diff,
                   'home_off_bye': (g.home_cat == 'bye').astype(float), 'away_off_bye': (g.away_cat == 'bye').astype(float),
                   'home_short_week': (g.home_cat == 'short').astype(float), 'away_short_week': (g.away_cat == 'short').astype(float),
                   'home_mini_bye': (g.home_cat == 'mini').astype(float), 'away_mini_bye': (g.away_cat == 'mini').astype(float),
                   'away_consec_road': g.away_consec_away, 'home_prev_ot': g.home_prev_ot, 'away_prev_ot': g.away_prev_ot})
fc = pd.DataFrame({'sport': 'CFB', 'game_id': c.game_id.astype('int64').astype(str), 'season': c.season,
                   'home_rest': c.home_rest_c, 'away_rest': c.away_rest_c, 'rest_diff': c.rest_diff,
                   'home_off_bye': (c.home_cat == 'bye').astype(float), 'away_off_bye': (c.away_cat == 'bye').astype(float),
                   'home_short_week': (c.home_cat == 'short').astype(float), 'away_short_week': (c.away_cat == 'short').astype(float),
                   'home_mini_bye': np.nan, 'away_mini_bye': np.nan,
                   'away_consec_road': c.away_consec_away, 'home_prev_ot': c.home_prev_ot, 'away_prev_ot': c.away_prev_ot})
for f, cat in [(fn, g), (fc, c)]:
    na = cat.home_rest_c.isna().to_numpy() | cat.away_rest_c.isna().to_numpy()
    for col in ['home_off_bye', 'away_off_bye', 'home_short_week', 'away_short_week']:
        f.loc[na, col] = np.nan
feat = pd.concat([fn, fc], ignore_index=True)
feat.to_parquet(sys.argv[3])
print('NFL', g.shape, 'CFB', c.shape, 'features', feat.shape)
print(pd.crosstab(g.home_cat, g.away_cat))
print(pd.crosstab(c.home_cat, c.away_cat))
print('NFL consec away', g.away_consec_away.value_counts().sort_index().to_dict())
print('CFB consec away', c.away_consec_away.value_counts().sort_index().to_dict())
print('CFB prev OT coverage', c.away_prev_ot.notna().mean().round(3))
