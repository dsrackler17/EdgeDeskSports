"""Rest & Recovery results -> EdgeDesk study spec (all numbers read from results.json)."""
import sys, json, pandas as pd
O, OUT = sys.argv[1], sys.argv[2]
r = json.load(open(f'{O}/results.json'))
M = {(m['sport'], m['model'], m['outcome']): m for m in r['models']}; W = r['wild']; cov = r['coverage']
sit = pd.DataFrame(r['situations'])
def c(sp, m, o, t): return M[(sp, m, o)]['coefs'][t]
def ci(v): b, se = v; return f'{b:+.2f} [{b-1.96*se:+.2f}, {b+1.96*se:+.2f}]'
def p(sp, m, o, t):
    v = W.get(f'{sp}|{m}|{o}|{t}'); return '–' if v is None else f'{v:.2f}'
def pct(x): return f'{100*x:.1f}%'
def n(sp, m, o, t): return M[(sp, m, o)]['counts'].get(t, 0)

nfl_terms = [('bye_diff', 'Off a bye (13+ days)'), ('mini_diff', 'Off a Thursday game (10–12 days)'), ('mnf6_diff', 'Six days (off Monday night)'),
             ('short_diff', 'Short week (5 days or fewer)'), ('v_road2', 'Visitor on 2nd straight road game'), ('v_road3', 'Visitor on 3rd+ straight road game'),
             ('ot_diff', 'Previous game went to overtime')]
nfl_rows = [[lab, f'{n("NFL","margin_FE","result",t):,}', ci(c('NFL', 'margin_FE', 'result', t)), p('NFL', 'margin_FE', 'result', t),
             ci(c('NFL', 'spread_FE', 'spread', t)), ci(c('NFL', 'ats_noFE', 'home_ats', t)), p('NFL', 'ats_noFE', 'home_ats', t)] for t, lab in nfl_terms]
cfb_terms = [('bye_diff', 'Off a bye (13+ days)'), ('short_diff', 'Short week (5 days or fewer)'), ('v_road2', 'Visitor on 2nd straight away game'),
             ('v_road3', 'Visitor on 3rd+ straight away game')]
cfb_rows = [[lab, f'{n("CFB","margin_FE","result",t):,}', ci(c('CFB', 'margin_FE', 'result', t)), p('CFB', 'margin_FE', 'result', t),
             ci(c('CFB', 'ats_noFE', 'home_ats', t)), p('CFB', 'ats_noFE', 'home_ats', t)] for t, lab in cfb_terms]
ot_c = c('CFB', 'margin_FE_ot', 'result', 'ot_diff')
cfb_rows.append(['Previous game went to overtime (2005+)', f'{n("CFB","margin_FE_ot","result","ot_diff"):,}', ci(ot_c), p('CFB', 'margin_FE_ot', 'result', 'ot_diff'), '–', '–'])

sit_rows = [[s.sport, s.situation, f'{s.n:,}', f'{s.margin:+.1f}', f'{s.spread_implied:+.1f}', f'{s.ats:+.2f}',
             f'{pct(s.cover)} [{pct(s.cover_lo)}, {pct(s.cover_hi)}]'] for s in sit.itertuples()]

era = []
for sp, eras in [('NFL', ['1999-2010', '2011-2025']), ('CFB', ['2001-2010', '2011-2021'])]:
    for e in eras:
        mm = M[(sp, f'margin_FE_{e}', 'result')]
        era.append([f'{sp} {e}', f'{mm["counts"]["bye_diff"]:,}', ci(mm['coefs']['bye_diff']), p(sp, f'margin_FE_{e}', 'result', 'bye_diff'),
                    ci(c(sp, f'ats_noFE_{e}', 'home_ats', 'bye_diff')), p(sp, f'ats_noFE_{e}', 'home_ats', 'bye_diff')])

byeN = c('NFL', 'margin_FE', 'result', 'bye_diff'); byeS = c('NFL', 'spread_FE', 'spread', 'bye_diff'); byeA = c('NFL', 'ats_noFE', 'home_ats', 'bye_diff')
shortN = c('NFL', 'margin_FE', 'result', 'short_diff')
byeC = c('CFB', 'margin_FE', 'result', 'bye_diff'); byeCA = c('CFB', 'ats_noFE', 'home_ats', 'bye_diff')
inter = c('NFL', 'margin_FE_era_interaction', 'result', 'bye_diff_late')
linN = c('NFL', 'margin_FE_linear', 'result', 'rest_diff'); linA = c('NFL', 'ats_linear', 'home_ats', 'rest_diff')
s_bye = sit[(sit.sport == 'NFL') & (sit.situation == 'Off bye vs opponent on normal rest')].iloc[0]
s_byec = sit[(sit.sport == 'CFB') & (sit.situation == 'Off bye vs opponent on normal rest')].iloc[0]
s_po = sit[sit.situation.str.startswith('Playoffs')].iloc[0]
r3 = c('NFL', 'margin_FE', 'result', 'v_road3')

def sig(v, pv):
    return 'distinguishable from zero' if pv != '–' and float(pv) < 0.05 else 'not distinguishable from zero'

spec = {
 'slug': 'rest-recovery', 'module': 'Rest & Recovery', 'status': 'null', 'status_label': 'Priced by the market',
 'title': 'The bye edge is real, and the market caught up',
 'question': 'Is the advantage of extra rest real, or has the betting market already priced it in?',
 'lede': f'Across {cov["nfl_reg_games"]:,} NFL regular-season games and {cov["cfb_games"]:,} FBS games, we measured byes, short weeks, Thursday mini-byes, road trips and overtime hangovers against team strength and against the closing spread.',
 'scope': f'NFL {cov["nfl_seasons"][0]}–{cov["nfl_seasons"][1]} · CFB {cov["cfb_seasons"][0]}–{cov["cfb_seasons"][1]}', 'updated': '2026-10-17',
 'findings': [
   f'An NFL team off a bye beats its strength-adjusted expectation by **{byeN[0]:+.2f} points** against a normally rested opponent (95% CI {ci(byeN)[6:]}, p = {p("NFL","margin_FE","result","bye_diff")}). The spread moves by {byeS[0]:+.2f} points for the same situation.',
   f'Against the market the bye edge is {ci(byeA)} points ATS (p = {p("NFL","ats_noFE","home_ats","bye_diff")}). Teams off a bye covered {pct(s_bye.cover)} of {s_bye.n_graded:,} graded games ({pct(s_bye.cover_lo)} to {pct(s_bye.cover_hi)}).',
   f'By era, the NFL bye was worth {ci(c("NFL","margin_FE_1999-2010","result","bye_diff"))} points in 1999–2010 and beat the spread by {ci(c("NFL","ats_noFE_1999-2010","home_ats","bye_diff"))} (p = {p("NFL","ats_noFE_1999-2010","home_ats","bye_diff")}). In 2011–2025 it is {ci(c("NFL","margin_FE_2011-2025","result","bye_diff"))} on the scoreboard and {ci(c("NFL","ats_noFE_2011-2025","home_ats","bye_diff"))} against the spread.',
   f'The bye effect on the scoreboard changed by {ci(inter)} points from 1999–2010 to 2011–2025 (p = {p("NFL","margin_FE_era_interaction","result","bye_diff_late")}). The decline points the way the shrinking-bye claim says, but it is not statistically clear on its own.',
   f'Short weeks barely exist as a mismatch: Thursday games are short week against short week, so only {n("NFL","margin_FE","result","short_diff")} NFL games put a short-rested team against a rested one and the estimate ({ci(shortN)}) is uninformative. Six-day teams (off Monday night) are {ci(c("NFL","margin_FE","result","mnf6_diff"))} points.',
   f'Road trips and overtime: a 3rd straight road game is {ci(r3)} points for the NFL visitor; coming off overtime is {ci(c("NFL","margin_FE","result","ot_diff"))}. Both are small samples.',
   f'College: a bye is worth {ci(byeC)} points against expectation and {ci(byeCA)} points against the spread (p = {p("CFB","ats_noFE","home_ats","bye_diff")}). Teams off a bye covered {pct(s_byec.cover)} of {s_byec.n_graded:,} games.',
   f'Each extra day of rest differential is worth {ci(linN)} NFL points on the scoreboard and {ci(linA)} against the spread.'],
 'sections': [
   {'h': 'NFL: real effect versus what the spread already charged',
    'p': ['Every team-season gets its own strength rating (added for the home team, subtracted for the visitor), so a good team that happens to be rested is compared with its own other games. Rest terms are home minus away, so +1 means the home team has the situation and the visitor does not. Controls: season, divisional game, neutral site, visitor travel and time-zone shift. Week 1 is excluded because nflverse codes every team as 7 days rested.',
     'The spread column regresses the market spread itself on the same terms. When the margin effect and the spread effect match, the market has priced the situation and the ATS column sits near zero.'],
    'table': {'cols': ['Situation', 'Games with it', 'Margin effect (pts)', 'p', 'Spread moved (pts)', 'ATS effect (pts)', 'p (ATS)'], 'rows': nfl_rows, 'num': [1, 2, 3, 4, 5, 6],
              'caption': 'Regular season, week 2 on. 95% intervals; standard errors clustered by home team; p-values from a wild-cluster bootstrap.'}},
   {'h': 'College football', 'p': ['Same design, with host-stadium clusters and conference-game, travel and time-zone controls. A bye is 13+ days since the last game against any opponent.'],
    'table': {'cols': ['Situation', 'Games with it', 'Margin effect (pts)', 'p', 'ATS effect (pts)', 'p (ATS)'], 'rows': cfb_rows, 'num': [1, 2, 3, 4, 5],
              'caption': f'FBS vs FBS, non-neutral, 2001–2021; spreads 2006–2019 ({cov["cfb_lines"]:,} graded games). Overtime from play-by-play periods, 2004+.'}},
   {'h': 'Has the bye edge shrunk?', 'table': {'cols': ['Era', 'Games with a bye edge', 'Margin effect (pts)', 'p', 'ATS effect (pts)', 'p (ATS)'], 'rows': era, 'num': [1, 2, 3, 4, 5],
     'caption': 'Same model fit separately by era. The 2011 CBA cut padded practices; Thursday Night Football became a weekly fixture in 2012, creating the 10–12 day mini-bye.'}},
   {'h': 'Situations from the rested team’s side', 'p': ['Raw averages, no strength adjustment. Margin is over all games in the row; spread, ATS and cover use the games with a graded line. Both are from the perspective of the team in the situation (for road-trip rows, the visitor). The ATS column is margin minus what the spread expected.'],
    'table': {'cols': ['Sport', 'Situation', 'Games', 'Margin', 'Spread expected', 'ATS margin', 'Cover % [95% CI]'], 'rows': sit_rows, 'num': [2, 3, 4, 5, 6],
              'caption': f'Cover intervals bootstrap over seasons. Playoff divisional-round byes: {s_po.n} games, covered {pct(s_po.cover)}.'}}],
 'model_verdict': 'The early-era ATS edge on byes is one test among dozens here and has not held since 2011, so it is treated as history, not a signal. Rest differential stays in the EdgeDesk research card as observed context. It does not get its own adjustment to the fair spread, because the market spread already moves by about the measured amount and the ATS residual is not distinguishable from zero. The combined environment model tests it jointly with travel, body clock and weather before any adjustment is allowed.',
 'data': [['NFL games', f'{cov["nfl_reg_games"]:,} regular-season games, week 2 on, {cov["nfl_seasons"][0]}–{cov["nfl_seasons"][1]}, from nflverse schedules (rest days, results, spread_line).'],
          ['NFL lines', 'nflverse spread_line, a consensus number close to kickoff. It is not a licensed closing feed and its capture time is not documented.'],
          ['CFB games', f'{cov["cfb_games"]:,} FBS-vs-FBS non-neutral games with rest known for both teams; rest from the full CFBD schedule including FCS opponents.'],
          ['CFB lines', 'SBR odds archive 2006–2019, Pinnacle where present.']],
 'gaps': [['Practice and injury load', 'Not available. Rest is calendar days only.'], ['CFB 2022–2025 rest', 'No full schedule with venues in the sources used.'],
          ['Line timing', 'Neither source records when the number was captured, so opening-to-close movement on byes cannot be studied.'],
          ['NFL week 1', 'Excluded: every team is coded 7 days rested.']],
 'sources': [['nflverse schedules (games.csv)', 'https://github.com/nflverse/nflverse-data/releases/tag/schedules'],
             ['CollegeFootballData via cfbfastR-data', 'https://github.com/sportsdataverse/cfbfastR-data'],
             ['sportsdataverse ESPN play-by-play', 'https://github.com/sportsdataverse/sportsdataverse-data/releases']],
 'zip': 'edgedesk-rest-recovery.zip'}
json.dump(spec, open(OUT, 'w'), indent=1)
print('ok')
