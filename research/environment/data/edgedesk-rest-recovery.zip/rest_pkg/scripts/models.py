"""Rest & Recovery models.

Margin models (is the effect real?): home margin on home-minus-away rest indicators with signed
team-season fixed effects (+1 home team-season, -1 visitor team-season, partialled out by
FWL/LSQR), season dummies, divisional game, neutral site, log visitor travel and time-zone shift.
Market models (is it priced?): home margin minus the market spread (ATS margin) on the same
indicators, without and with team-season FE. SEs clustered by home team (NFL) / host venue (CFB);
headline p-values from a wild-cluster bootstrap (Rademacher, null imposed, 999 draws).
"""
import sys, json, numpy as np, pandas as pd, scipy.sparse as sp
from scipy.sparse.linalg import lsqr

S, OUT = sys.argv[1], sys.argv[2]
RES, WILD = [], {}

def cluster_ols(y, X, cl, ka):
    n, k = X.shape
    XtX_inv = np.linalg.pinv(X.T @ X); b = XtX_inv @ X.T @ y; u = y - X @ b
    ucl, inv = np.unique(cl, return_inverse=True); G = len(ucl)
    Sg = np.zeros((G, k)); np.add.at(Sg, inv, X * u[:, None])
    adj = G / (G - 1) * (n - 1) / max(n - k - ka, 1)
    V = adj * XtX_inv @ (Sg.T @ Sg) @ XtX_inv
    return b, np.sqrt(np.diag(V)), G

def wild_p(y, X, j, cl, B=999, seed=11):
    rng = np.random.default_rng(seed); ucl, inv = np.unique(cl, return_inverse=True); G = len(ucl)
    XtX_inv = np.linalg.pinv(X.T @ X)
    def t(yy):
        b = XtX_inv @ X.T @ yy; u = yy - X @ b
        Sg = np.zeros((G, X.shape[1])); np.add.at(Sg, inv, X * u[:, None])
        V = XtX_inv @ (Sg.T @ Sg) @ XtX_inv
        return b[j] / np.sqrt(V[j, j])
    t0 = t(y); Xr = np.delete(X, j, axis=1); br = np.linalg.lstsq(Xr, y, rcond=None)[0]; f = Xr @ br; ur = y - f
    ts = np.array([t(f + ur * rng.choice([-1.0, 1.0], G)[inv]) for _ in range(B)])
    return float((np.abs(ts) >= abs(t0)).mean())

def fit(d, y, xs, label, sport, fe=True, wild=(), home='home_key', away='away_key', cl='cluster'):
    d = d.dropna(subset=[y] + xs).reset_index(drop=True)
    Y = d[y].to_numpy(float); X = d[xs].to_numpy(float); X = X - X.mean(0)
    X = np.column_stack([np.ones(len(d)), X]); ka = 0
    if fe:
        hts, ats = d[home].astype(str), d[away].astype(str)
        cats = pd.Index(pd.unique(pd.concat([hts, ats]))); r = np.arange(len(d))
        Z = sp.csr_matrix((np.r_[np.ones(len(d)), -np.ones(len(d))], (np.r_[r, r], np.r_[cats.get_indexer(hts), cats.get_indexer(ats)])), shape=(len(d), len(cats)))
        res = lambda v: v - Z @ lsqr(Z, v, atol=1e-10, btol=1e-10, iter_lim=20000)[0]
        Y = res(Y); X = np.column_stack([res(X[:, j]) for j in range(X.shape[1])]); ka = len(cats) - 1
    b, se, G = cluster_ols(Y, X, d[cl].to_numpy(), ka)
    out = dict(sport=sport, model=label, outcome=y, n=len(d), clusters=G, coefs={})
    for nm, bb, ss in zip(['intercept'] + xs, b, se):
        out['coefs'][nm] = [float(bb), float(ss)]
    for nm in wild:
        if nm in xs:
            WILD[f'{sport}|{label}|{y}|{nm}'] = wild_p(Y, X, 1 + xs.index(nm), d[cl].to_numpy())
    out['counts'] = {x: int((d[x] != 0).sum()) for x in xs if not x.startswith('yr_')}
    RES.append(out); return out

# ---------------- NFL ----------------
g = pd.read_parquet(f'{S}/rest/nfl_rest_panel.parquet')
g['home_key'] = g.home_team + '_' + g.season.astype(str); g['away_key'] = g.away_team + '_' + g.season.astype(str)
g['cluster'] = g.home_team
g['neutral'] = (g.location == 'Neutral').astype(float)
g['log_travel'] = np.log1p(g.away_travel_mi.fillna(g.away_travel_mi.median()))
g['tz_abs'] = g.away_tz_shift.abs().fillna(0)
g['div'] = g.div_game.astype(float)
for cat in ['short', 'mnf6', 'mini', 'bye']:
    g[f'{cat}_diff'] = (g.home_cat == cat).astype(float) - (g.away_cat == cat).astype(float)
g['v_road2'] = (g.away_consec_away == 2).astype(float); g['v_road3'] = (g.away_consec_away >= 3).astype(float)
g['ot_diff'] = g.home_prev_ot.fillna(0) - g.away_prev_ot.fillna(0)
g['bye_diff_late'] = g.bye_diff * (g.season >= 2011)
reg = g[(g.game_type == 'REG') & (g.week > 1)].copy()
yr = pd.get_dummies(reg.season, prefix='yr', drop_first=True, dtype=float); reg = pd.concat([reg, yr], axis=1); YR = list(yr.columns)
ctrl = ['neutral', 'div', 'log_travel', 'tz_abs'] + YR
X_CAT = ['short_diff', 'mnf6_diff', 'mini_diff', 'bye_diff', 'v_road2', 'v_road3', 'ot_diff']
H = ['short_diff', 'mnf6_diff', 'mini_diff', 'bye_diff', 'v_road2', 'v_road3', 'ot_diff']
fit(reg, 'result', X_CAT + ctrl, 'margin_FE', 'NFL', True, H)
fit(reg, 'home_ats', X_CAT + ctrl, 'ats_noFE', 'NFL', False, H)
fit(reg, 'home_ats', X_CAT + ctrl, 'ats_FE', 'NFL', True, ())
fit(reg, 'result', ['rest_diff'] + ctrl, 'margin_FE_linear', 'NFL', True, ['rest_diff'])
fit(reg, 'home_ats', ['rest_diff'] + ctrl, 'ats_linear', 'NFL', False, ['rest_diff'])
fit(reg, 'over_margin', ['short_diff', 'bye_diff'] + ctrl, 'total_noFE', 'NFL', False, ())
# era split
for era in ['1999-2010', '2011-2025']:
    e = reg[reg.era == era]
    fit(e, 'result', X_CAT + ctrl, f'margin_FE_{era}', 'NFL', True, ['bye_diff'] if era else ())
    fit(e, 'home_ats', X_CAT + ctrl, f'ats_noFE_{era}', 'NFL', False, ['bye_diff'])
fit(reg, 'result', X_CAT + ['bye_diff_late'] + ctrl, 'margin_FE_era_interaction', 'NFL', True, ['bye_diff_late'])
# market's implied pricing: how much does the spread itself move with bye_diff (team-season FE)?
reg['spread'] = reg.spread_line
fit(reg, 'spread', X_CAT + ctrl, 'spread_FE', 'NFL', True, ())

# raw situation table (regular season, week>1): perspective team = the rested / tired team
def sit_rows(d, sport):
    rows = []
    def add(name, mask, sign):
        x = d[mask]
        marg = sign * x.result; ats = sign * x.home_ats
        cover = np.where(ats > 0, 1.0, np.where(ats < 0, 0.0, np.nan))
        # cluster bootstrap by season
        cs = pd.Series(cover, index=x.index)
        seas = x.season.to_numpy(); us = np.unique(seas); rng = np.random.default_rng(3); bs = []
        by = {s: cs[seas == s].dropna().to_numpy() for s in us}
        for _ in range(2000):
            pick = rng.choice(us, len(us)); arr = np.concatenate([by[s] for s in pick]); bs.append(arr.mean() if len(arr) else np.nan)
        rows.append(dict(sport=sport, situation=name, n=int(len(x)), margin=float(marg.mean()), spread_implied=float((sign * x.spread_line).mean()) if 'spread_line' in x else float((-sign * x.home_spread).mean()),
                         ats=float(ats.mean()), cover=float(np.nanmean(cover)), cover_lo=float(np.nanpercentile(bs, 2.5)), cover_hi=float(np.nanpercentile(bs, 97.5)),
                         n_graded=int(np.isfinite(cover).sum())))
    return add, rows
add, rows_nfl = sit_rows(reg, 'NFL')
hb, ab = reg.home_cat == 'bye', reg.away_cat == 'bye'
add('Team off bye vs opponent on normal rest', (hb & (reg.away_cat == 'normal')), 1)
add('Team off bye vs opponent on normal rest', (ab & (reg.home_cat == 'normal')), -1)
rows_nfl = [r for r in rows_nfl]
# merge the two halves (home-bye and away-bye) into one by recomputing jointly
def joint(d, cond_home, cond_away, name, sport):
    a = d[cond_home].assign(m=lambda x: x.result, a=lambda x: x.home_ats, s=lambda x: x.spread_line)
    b = d[cond_away].assign(m=lambda x: -x.result, a=lambda x: -x.home_ats, s=lambda x: -x.spread_line)
    x = pd.concat([a, b]); cov = np.where(x.a > 0, 1.0, np.where(x.a < 0, 0.0, np.nan))
    us = x.season.unique(); rng = np.random.default_rng(5); bs = []
    by = {s: cov[(x.season == s).to_numpy()] for s in us}
    for _ in range(2000):
        pick = rng.choice(us, len(us)); arr = np.concatenate([by[s] for s in pick]); bs.append(np.nanmean(arr))
    return dict(sport=sport, situation=name, n=int(len(x)), margin=float(x.m.mean()), spread_implied=float(x.s.mean()), ats=float(x.a.mean()),
                cover=float(np.nanmean(cov)), cover_lo=float(np.percentile(bs, 2.5)), cover_hi=float(np.percentile(bs, 97.5)), n_graded=int(np.isfinite(cov).sum()))
SIT = []
R = reg
SIT.append(joint(R, (R.home_cat == 'bye') & (R.away_cat == 'normal'), (R.away_cat == 'bye') & (R.home_cat == 'normal'), 'Off bye vs opponent on normal rest', 'NFL'))
SIT.append(joint(R, (R.home_cat == 'mini') & (R.away_cat == 'normal'), (R.away_cat == 'mini') & (R.home_cat == 'normal'), 'Off Thursday game (10-12 days) vs normal rest', 'NFL'))
SIT.append(joint(R, (R.home_cat == 'mnf6') & (R.away_cat == 'normal'), (R.away_cat == 'mnf6') & (R.home_cat == 'normal'), 'Six days (off Monday night) vs normal rest', 'NFL'))
SIT.append(joint(R, (R.home_cat == 'bye') & (R.away_cat == 'bye'), R.index != R.index, 'Both teams off bye (home side)', 'NFL'))
SIT.append(joint(R, (R.home_cat == 'short') & (R.away_cat == 'short'), R.index != R.index, 'Both on short week, Thursday (home side)', 'NFL'))
SIT.append(joint(R, R.index != R.index, (R.away_consec_away == 2), 'Visitor on 2nd straight road game', 'NFL'))
SIT.append(joint(R, R.index != R.index, (R.away_consec_away >= 3), 'Visitor on 3rd+ straight road game', 'NFL'))
SIT.append(joint(R, (R.home_prev_ot == 1) & (R.away_prev_ot == 0), (R.away_prev_ot == 1) & (R.home_prev_ot == 0), 'Coming off overtime vs opponent who did not', 'NFL'))
for era in ['1999-2010', '2011-2025']:
    E = R[R.era == era]
    SIT.append(joint(E, (E.home_cat == 'bye') & (E.away_cat == 'normal'), (E.away_cat == 'bye') & (E.home_cat == 'normal'), f'Off bye vs normal rest, {era}', 'NFL'))
# playoffs: home team off a bye (top seeds in divisional round)
P = g[g.game_type.isin(['DIV']) & (g.home_rest >= 13) & (g.away_rest <= 8)]
SIT.append(joint(P, P.index == P.index, P.index != P.index, 'Playoffs: home team off first-round bye (divisional round)', 'NFL'))

# ---------------- CFB ----------------
c = pd.read_parquet(f'{S}/rest/cfb_rest_panel.parquet')
c['home_key'] = c.home_id.astype(int).astype(str) + '_' + c.season.astype(str); c['away_key'] = c.away_id.astype(int).astype(str) + '_' + c.season.astype(str)
c['cluster'] = c.venue_id
for cat in ['short', 'bye']:
    c[f'{cat}_diff'] = (c.home_cat == cat).astype(float) - (c.away_cat == cat).astype(float)
c['v_road2'] = (c.away_consec_away == 2).astype(float); c['v_road3'] = (c.away_consec_away >= 3).astype(float)
c['ot_diff'] = c.home_prev_ot.fillna(0) - c.away_prev_ot.fillna(0)
c['log_travel'] = np.log1p(c.travel_mi); c['tz_abs'] = c.tz_cross.fillna(0); c['conf'] = c.conference_game.astype(float)
c = c.dropna(subset=['home_rest_c', 'away_rest_c'])
yrc = pd.get_dummies(c.season, prefix='yr', drop_first=True, dtype=float); c = pd.concat([c, yrc], axis=1); YRC = list(yrc.columns)
ctrlc = ['conf', 'log_travel', 'tz_abs'] + YRC
XC = ['short_diff', 'bye_diff', 'v_road2', 'v_road3']
fit(c, 'result', XC + ctrlc, 'margin_FE', 'CFB', True, XC)
fit(c, 'home_ats', XC + ctrlc, 'ats_noFE', 'CFB', False, XC)
fit(c, 'home_ats', XC + ctrlc, 'ats_FE', 'CFB', True, ())
cot = c[c.season >= 2005]
fit(cot, 'result', XC + ['ot_diff'] + ctrlc, 'margin_FE_ot', 'CFB', True, ['ot_diff'])
fit(c, 'result', ['rest_diff'] + ctrlc, 'margin_FE_linear', 'CFB', True, ['rest_diff'])
for era in ['2001-2010', '2011-2021']:
    e = c[c.era == era]
    fit(e, 'result', XC + ctrlc, f'margin_FE_{era}', 'CFB', True, ['bye_diff'])
    fit(e, 'home_ats', XC + ctrlc, f'ats_noFE_{era}', 'CFB', False, ['bye_diff'])
c['spread_line'] = -c.home_spread
C = c
SIT.append(joint(C, (C.home_cat == 'bye') & (C.away_cat == 'normal'), (C.away_cat == 'bye') & (C.home_cat == 'normal'), 'Off bye vs opponent on normal rest', 'CFB'))
SIT.append(joint(C, (C.home_cat == 'short') & (C.away_cat == 'normal'), (C.away_cat == 'short') & (C.home_cat == 'normal'), 'Short week (5 days or fewer) vs normal rest', 'CFB'))
SIT.append(joint(C, (C.home_cat == 'bye') & (C.away_cat == 'bye'), C.index != C.index, 'Both teams off bye (home side)', 'CFB'))
SIT.append(joint(C, C.index != C.index, (C.away_consec_away == 2), 'Visitor on 2nd straight away game', 'CFB'))
SIT.append(joint(C, C.index != C.index, (C.away_consec_away >= 3), 'Visitor on 3rd+ straight away game', 'CFB'))
cc = C[C.season >= 2005]
SIT.append(joint(cc, (cc.home_prev_ot == 1) & (cc.away_prev_ot == 0), (cc.away_prev_ot == 1) & (cc.home_prev_ot == 0), 'Coming off overtime vs opponent who did not', 'CFB'))

json.dump(dict(models=RES, wild=WILD, situations=SIT,
               coverage=dict(nfl_reg_games=int(len(reg)), nfl_seasons=[int(reg.season.min()), int(reg.season.max())],
                             cfb_games=int(len(c)), cfb_lines=int(c.home_ats.notna().sum()), cfb_seasons=[int(c.season.min()), int(c.season.max())],
                             nfl_playoff_bye_games=int(len(P)))), open(f'{OUT}/results.json', 'w'), indent=1)
pd.DataFrame(SIT).to_csv(f'{OUT}/situations.csv', index=False)
print('done', len(RES))
