# EdgeDesk study: Rest & Recovery

Question: is the advantage of extra rest real, or has the betting market already priced it in?

Run order (S = folder holding shared/, panel.parquet, dl/):
1. python3 scripts/build.py $S $S/rest features.parquet   -> NFL and CFB rest panels, pre-game feature file
2. python3 scripts/models.py $S $S/rest                  -> results.json, situations.csv
3. python3 scripts/make_spec.py $S/rest spec.json        -> page spec for the EdgeDesk site

Inputs: nflverse schedules (rest days, spread_line, results), CollegeFootballData schedules and the
altitude-study CFB panel (venues, SBR spreads 2006-2019), ESPN play-by-play for CFB overtime.

Definitions: NFL short <=5 days, six days, normal 7-9, mini-bye 10-12, bye >=13; week 1 excluded
(nflverse codes all teams 7). CFB short <=5, normal 6-12, bye >=13.
Margin models use signed team-season fixed effects; ATS models test residual vs the market spread.
SEs clustered by home team (NFL) / host venue (CFB); p-values from wild-cluster bootstrap.

Data notes: NFL team codes taken from nflverse games.csv (OAK/SD/STL in their seasons). Lines are
nflverse spread_line (consensus near kickoff, capture time undocumented) and SBR archive for CFB;
neither is a licensed closing feed.
