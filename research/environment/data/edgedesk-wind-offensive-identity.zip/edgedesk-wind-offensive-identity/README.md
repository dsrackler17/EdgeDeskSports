# EdgeDesk study: Wind & Offensive Identity (NFL 1999-2025)

Question: does high wind hurt a pass-heavy offense more than a run-heavy one, and does the market price it?

## Run
1. `python3 scripts/build_nfl.py <nflverse_dir> <shared_dir>` builds nfl_games.parquet and nfl_team_games.parquet
   from nflverse games.csv, play-by-play 1999-2025 and stadium_geo.csv.
2. `python3 scripts/analysis.py <scratch_dir> <out_dir> <features.parquet>` (expects <scratch_dir>/shared and <scratch_dir>/nfl/pbp).
3. `python3 scripts/make_spec.py <out_dir> spec.json` writes the page content; every number comes from results.json.

## Files
- data/dataset_team_games.csv.gz: outdoor offense-games with pre-game identity, wind, outcomes
- data/dataset_games.csv.gz: outdoor games with lines, totals and both teams' identity
- data/fg_attempts.csv.gz: outdoor field goal attempts with distance and weather
- data/features.parquet: pre-game features for the combined model (all games; wind 0 indoors)
- results/results.json: every model (coefficient, SE, p), coverage, market bins, eras
- results/wind_bins.csv, results/fg_by_wind.csv: raw tables

## Definitions
- Identity: neutral-situation (win prob 20-80%, Q1-Q3) dropback rate from prior games only (season to date with 3+ games, else prior season), minus the league mean that week.
- Models: pyfixest OLS, offense team-season and defense team-season fixed effects, temp/rain/snow controls, SEs clustered by stadium.
- Wind above 45 mph treated as a data error (2 games). Open retractable roofs excluded (no reading).

## Limits
- No crosswind: compass direction only, no field orientation.
- Game-time measured weather, not forecasts. Market gaps are an upper bound.
- NFL only; no CFB weather source was reachable.
- nflverse line capture time is undocumented.
