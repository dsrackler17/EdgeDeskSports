"""Wind study results -> EdgeDesk study spec (all numbers read from result files)."""
import sys, json, pandas as pd
O, OUT = sys.argv[1], sys.argv[2]
r = json.load(open(f'{O}/results.json')); M = r['models']; C = r['coverage']
wb = pd.read_csv(f'{O}/wind_bins.csv'); fgw = pd.read_csv(f'{O}/fg_by_wind.csv')

def co(model, term):
    return M[model]['coefs'][term]
def ci(b, se, k=1.0, d=2):
    return f'{b*k:+.{d}f} [{(b-1.96*se)*k:+.{d}f}, {(b+1.96*se)*k:+.{d}f}]'
def cc(model, term, k=1.0, d=2):
    b, se, p = co(model, term); return ci(b, se, k, d)
def pv(model, term):
    p = co(model, term)[2]; return '<0.001' if p < 0.001 else f'{p:.3f}'
pct = lambda x: f'{100*x:.1f}%'

T = {"Q('w_run-heavy')": 'run-heavy', 'w_balanced': 'balanced', "Q('w_pass-heavy')": 'pass-heavy'}
terc_rows = []
for y, lab, k, d in [('epa_pass', 'EPA per dropback', 1, 3), ('comp_rate', 'Completion rate (pp)', 100, 1), ('points', 'Points scored', 1, 2),
                     ('expl_rate', 'Explosive-play rate (pp)', 100, 2), ('fg40_rate', 'FG% from 40+ (pp)', 100, 1)]:
    row = [lab] + [cc(f'terc|{y}', t, k, d) for t in T] + [cc(f'cont|{y}', 'w_x_ident', k, d), pv(f'cont|{y}', 'w_x_ident')]
    terc_rows.append(row)

cont_rows = []
for y, lab, k, d in [('epa_pass', 'EPA per dropback', 1, 3), ('comp_rate', 'Completion rate (pp)', 100, 1), ('air', 'Air yards per attempt', 1, 2),
                     ('epa_rush', 'EPA per rush', 1, 3), ('expl_rate', 'Explosive-play rate (pp)', 100, 2), ('to', 'Turnovers', 1, 3),
                     ('points', 'Points scored', 1, 2), ('fg_rate', 'FG% (pp)', 100, 1), ('fg40_rate', 'FG% from 40+ (pp)', 100, 1), ('xp_rate', 'XP% (pp)', 100, 1)]:
    cont_rows.append([lab, f'{M[f"cont|{y}"]["n"]:,}', cc(f'cont|{y}', 'w10', k, d), pv(f'cont|{y}', 'w10')])

raw_rows = []
for _, x in wb.iterrows():
    raw_rows.append([f'{x.wind_bin} mph · {x.ident_terc}', f'{int(x.team_games):,}', f'{x.epa_pass:+.3f}', pct(x.comp_rate), f'{x.points:.1f}'])

mk_rows = [[f'{b["bin"]} mph', f'{b["games"]:,}', f'{b["avg_total_line"]:.1f}', f'{b["avg_total"]:.1f}', f'{b["avg_over_margin"]:+.1f}',
            f'{pct(b["under_rate"])} [{pct(b["under_lo"])}, {pct(b["under_hi"])}]'] for b in r['market_bins']]
era_rows = [[e['era'], f'{e["games"]:,}', ci(e['line_b'], e['line_se']), ci(e['over_b'], e['over_se']), f'{pct(e["under15"])} of {e["n15"]}'] for e in r['eras']]
fgb = [[f'{x.wind_bin} mph', 'Under 40' if not x.long else '40+', f'{int(x.n):,}', pct(x.pct)] for _, x in fgw.iterrows()]

line10 = co('market|total_line_on_wind', 'w10'); tot10 = co('game|total_points', 'w10'); om10 = co('market|over_margin', 'w10')
pe = co('cont|epa_pass', 'w10'); px = co('cont|epa_pass', 'w_x_ident')
cov22 = C['outdoor_wind_coverage_by_season']
spec = {
 'slug': 'wind-offensive-identity', 'module': 'Wind & Offensive Identity', 'status': 'experimental', 'status_label': 'Candidate signal, unvalidated',
 'title': 'Wind hits pass-heavy offenses harder, and totals lag behind',
 'question': 'Does a 20 mph wind hurt a pass-heavy offense more than a run-heavy one, and does the betting market already account for it?',
 'lede': f'In {C["outdoor_with_wind"]:,} outdoor NFL games, every 10 mph of wind costs passing efficiency, costs pass-heavy offenses more, and lowers scoring by more than the total line moves.',
 'scope': 'NFL · 1999–2025 · outdoor games', 'updated': '2026-10-17',
 'findings': [
   f'Each 10 mph of wind lowers EPA per dropback by {abs(pe[0]):.3f} for a team with a league-average passing identity (95% CI {abs(pe[0]+1.96*pe[1]):.3f} to {abs(pe[0]-1.96*pe[1]):.3f}).',
   f'The penalty grows with pass-heaviness: a further {abs(px[0]):.3f} EPA per dropback per 10 mph for each 10 points of neutral-situation pass rate above league (p {('= '+pv("cont|epa_pass","w_x_ident")) if not pv("cont|epa_pass","w_x_ident").startswith('<') else pv("cont|epa_pass","w_x_ident").replace('<','< ')}). Pass-heavy teams score {abs(co("terc|points","Q(\'w_pass-heavy\')")[0]):.1f} fewer points per 10 mph of wind; run-heavy teams score {abs(co("terc|points","Q(\'w_run-heavy\')")[0]):.1f} fewer.',
   f'Rushing efficiency barely moves ({cc("cont|epa_rush","w10",1,3)} EPA per rush per 10 mph). Turnovers show no clear change.',
   f'Field goals: holding kicker-season and distance fixed, 20+ mph winds lower the make rate by {abs(co("fg_play_bins|made","Q(\'b_20+\')")[0]*100):.1f} percentage points relative to 0 to 9 mph games (95% CI {abs((co("fg_play_bins|made","Q(\'b_20+\')")[0]+1.96*co("fg_play_bins|made","Q(\'b_20+\')")[1])*100):.1f} to {abs((co("fg_play_bins|made","Q(\'b_20+\')")[0]-1.96*co("fg_play_bins|made","Q(\'b_20+\')")[1])*100):.1f}). The extra effect at 40+ yards is not separately clear.',
   f'Market: combined scoring falls {abs(tot10[0]):.1f} points per 10 mph but the total line falls only {abs(line10[0]):.1f}, so games finish {abs(om10[0]):.1f} points further under the line per 10 mph (p {pv("market|over_margin","w10").replace("<","< ") if pv("market|over_margin","w10").startswith("<") else "= "+pv("market|over_margin","w10")}). The gap appears in each of three eras.',
   'This uses wind measured at the game, which a bettor only sees as a forecast. The market gap is an upper bound on what a forecast could capture.'],
 'sections': [
   {'h': 'Wind and pass-heaviness', 'p': ['Each offense is classified before the game by its neutral-situation dropback rate in earlier games that season (falling back to the prior season), relative to the league that week. Models hold the offense team-season and the opposing defense team-season fixed and control for temperature, rain and snow. Standard errors cluster by stadium.'],
    'table': {'cols': ['Outcome, per 10 mph', 'Run-heavy', 'Balanced', 'Pass-heavy', 'Extra per +10 pp pass rate', 'p'], 'rows': terc_rows, 'num': [1, 2, 3, 4, 5],
              'caption': 'Effects of 10 mph of wind by identity tercile, with 95% intervals. The last two columns come from the continuous interaction model.'}},
   {'h': 'Every outcome, average team', 'table': {'cols': ['Outcome', 'Team-games', 'Per 10 mph [95% CI]', 'p'], 'rows': cont_rows, 'num': [1, 2, 3],
     'caption': 'Wind slope at a league-average passing identity. Kicking rates are weighted by attempts.'}},
   {'h': 'Raw numbers by wind and identity', 'table': {'cols': ['Wind · identity', 'Team-games', 'EPA per dropback', 'Completion %', 'Points'], 'rows': raw_rows, 'num': [1, 2, 3, 4],
     'caption': 'Unadjusted. Pass-heavy teams are better passers in every wind band, so the comparison that matters is how far each row falls as wind rises.'}},
   {'h': 'Field goals by wind', 'table': {'cols': ['Wind', 'Distance', 'Attempts', 'Made'], 'rows': fgb, 'num': [2, 3], 'caption': 'Unadjusted outdoor field goals 1999–2025.'}},
   {'h': 'What the total line does with wind', 'p': [f'The line falls with wind, but not as far as scoring does. Under rates rise from the calm band to the 10–19 mph bands. The 20+ band is small ({r["market_bins"][-1]["graded"]} graded games) and noisy.'],
    'table': {'cols': ['Wind', 'Games', 'Avg total line', 'Avg total', 'Avg vs line', 'Under rate [95% CI]'], 'rows': mk_rows, 'num': [1, 2, 3, 4, 5],
              'caption': 'Pushes excluded from under rates; intervals are a bootstrap over games.'},
    'tables': [{'cols': ['Era', 'Games', 'Line move per 10 mph', 'Result vs line per 10 mph', 'Under rate at 15+ mph'], 'rows': era_rows, 'num': [1, 2, 3],
                'caption': 'Same model fitted separately in three periods. A gap that held in every period is more credible than one found in the pooled sample alone.'}],
    'after': [f'The spread shows a weaker version: when the home offense is the pass-heavier side, it does worse against the spread as wind rises ({cc("market|home_ats","w_x_diff")} points per 10 mph per 10 pp identity gap, p = {pv("market|home_ats","w_x_diff")}). With many tests in this study, treat that one as a lead, not a finding.']}],
 'model_verdict': 'Candidate for the combined model, not deployed. Wind and wind × pass identity go into the Phase 3 test against the closing total and spread, with a time-ordered holdout. Live use would rely on forecast wind, which needs its own historical forecast data before any adjustment can be validated.',
 'data': [['Games', f'{C["games_total"]:,} NFL games 1999–2025; {C["outdoor_with_wind"]:,} outdoor games with a wind reading; {C["indoor_games"]:,} dome or closed-roof games used as the no-wind reference in a robustness check.'],
          ['Team-games', f'{C["team_games_analysis"]:,} outdoor offense-games with a pre-game identity ({C["ident_src"].get("season_to_date",0):,} from season-to-date, {C["ident_src"].get("prior_season",0):,} from the prior season).'],
          ['Weather', 'Stadium-reported temperature and wind (nflverse). Rain and snow parsed from the game weather text. Two readings above 45 mph were treated as errors.'],
          ['Lines', f'nflverse total_line and spread_line for {C["market_games"]:,} games. Capture time is not documented; treated as a near-close consensus, not a licensed closing feed.'],
          ['Field goals', f'{C["fg_attempts_outdoor"]:,} outdoor attempts, play level, with kicker-season fixed effects.']],
 'gaps': [['Crosswind', 'Wind direction is a compass reading and stadium field orientation is not in the data, so crosswind versus headwind cannot be computed.'],
          ['College football', 'No historical CFB game weather was reachable from this environment. The study is NFL only.'],
          ['Wind coverage', f'Outdoor games with a wind reading dropped to {cov22["2022"][1]*100:.0f}% in 2022 and {cov22["2023"][1]*100:.0f}% in 2023, against 93–100% in other seasons.'],
          ['Forecasts', 'The study uses measured game wind. Historical forecasts, which is what a bettor actually has, were not available.'],
          ['Retractable roofs', f'{C["open_roof_games_excluded"]} games with an open retractable roof have no wind reading and were excluded.']],
 'sources': [['nflverse schedules and lines (games.csv)', 'https://github.com/nflverse/nflverse-data/releases/tag/schedules'],
             ['nflverse play-by-play', 'https://github.com/nflverse/nflverse-data/releases/tag/pbp']],
 'zip': 'edgedesk-wind-offensive-identity.zip'}
json.dump(spec, open(OUT, 'w'), indent=1)
print('ok')
