"""Study 2: Wind & Offensive Identity (NFL 1999-2025).

Question: does high wind hurt a pass-heavy offense more than a run-heavy one, and does the
market (total_line / spread_line) already price it?

Inputs (S = scratchpad):
  S/shared/nfl_games.parquet, S/shared/nfl_team_games.parquet (built by common/build_nfl.py)
  S/nfl/pbp/<year>.parquet (field-goal attempts, play level)
Outputs (OUT): results.json, wind_bins.csv, dataset_team_games.csv.gz, dataset_games.csv.gz,
               fg_attempts.csv.gz, features parquet

Definitions
  outdoor   : roof == 'outdoors' with a reported wind. 'open' retractable roofs have no wind
              reading in nflverse and are excluded; dome/closed games are the indoor reference.
  wind      : stadium-reported mph (nflverse games.csv). Values > 45 mph are treated as data
              errors (two games: 70 and 71 mph where the weather text says 21 / implausible).
  identity  : neutral-situation dropback rate (win prob 20-80%, quarters 1-3) from the team's
              PRIOR games only: season-to-date before this game when >= 3 prior games, else the
              team's full prior season. Expressed relative to the mean identity of all teams
              that same week (pre-game knowable). Positive = pass-heavier than league.
  tercile   : identity terciles within season (run-heavy / balanced / pass-heavy).
Models: pyfixest OLS with offense team-season and opponent-defense team-season fixed effects,
controls temp, precip, snow; SEs clustered by stadium.
"""
import sys, json, numpy as np, pandas as pd, pyfixest as pf
import pyarrow.parquet as pq

S, OUT = sys.argv[1], sys.argv[2]
g = pd.read_parquet(f'{S}/shared/nfl_games.parquet')
t = pd.read_parquet(f'{S}/shared/nfl_team_games.parquet')

g['wind_clean'] = g.wind.where(g.wind <= 45)
g['outdoor'] = g.roof == 'outdoors'
g['weather_ok'] = g.outdoor & g.wind_clean.notna() & g.temp.notna()
g['precip'] = g.precip.fillna(False).astype(float)
g['snow'] = g.snow.fillna(False).astype(float)

# ---------------- identity (pre-game only) ----------------
t = t.merge(g[['game_id', 'gameday', 'home_team', 'away_team', 'home_score', 'away_score']], on='game_id', how='left')
t = t.sort_values(['team', 'gameday'])
t['np_w'] = t.neutral_pass * t.neutral_plays
grp = t.groupby(['team', 'season'])
t['cum_np'] = grp.np_w.cumsum() - t.np_w
t['cum_n'] = grp.neutral_plays.cumsum() - t.neutral_plays
t['n_prior_games'] = grp.cumcount()
season_rate = (t.groupby(['team', 'season']).np_w.sum() / t.groupby(['team', 'season']).neutral_plays.sum()).rename('season_rate').reset_index()
season_rate['season'] += 1  # becomes "prior season" rate for next season
t = t.merge(season_rate.rename(columns={'season_rate': 'prior_season_rate'}), on=['team', 'season'], how='left')
t['ident_raw'] = np.where(t.n_prior_games >= 3, t.cum_np / t.cum_n.replace(0, np.nan), t.prior_season_rate)
t['ident_src'] = np.where(t.n_prior_games >= 3, 'season_to_date', 'prior_season')
t['ident'] = t.ident_raw - t.groupby(['season', 'week']).ident_raw.transform('mean')
t['ident_terc'] = t.groupby('season').ident.transform(lambda s: pd.qcut(s, 3, labels=['run-heavy', 'balanced', 'pass-heavy']) if s.notna().sum() > 10 else np.nan)

t['is_home'] = t.team == t.home_team
t['points'] = np.where(t.is_home, t.home_score, t.away_score)
t['comp_rate'] = t.comp / t.patt.replace(0, np.nan)
t['expl_rate'] = t.expl / t.plays.replace(0, np.nan)
t['fg_rate'] = t.fgm / t.fga.replace(0, np.nan)
t['fg40_rate'] = t.fg40m / t.fg40.replace(0, np.nan)
t['xp_rate'] = t.xpm / t.xpa.replace(0, np.nan)
t['off_ts'] = t.team + '_' + t.season.astype(str)
t['def_ts'] = t.opp + '_' + t.season.astype(str)
gw = g[['game_id', 'wind_clean', 'gust', 'temp', 'precip', 'snow', 'outdoor', 'indoor', 'weather_ok', 'stadium_id', 'roof']]
t = t.merge(gw, on='game_id', how='left')
t['wind_bin'] = pd.cut(t.wind_clean, [-0.1, 9.5, 14.5, 19.5, 100], labels=['0-9', '10-14', '15-19', '20+'])
t['w10'] = t.wind_clean / 10.0
t['ident10'] = t.ident * 10      # per 10 percentage points of neutral dropback rate
t['w_x_ident'] = t.w10 * t.ident10

R = {'models': {}, 'coverage': {}}
tw = t[t.weather_ok & t.ident.notna() & (t.plays >= 30)].copy()

# coverage
gc = g[g.outdoor].groupby('season').agg(n=('game_id', 'size'), wind_cov=('wind_clean', lambda s: s.notna().mean()))
R['coverage']['outdoor_wind_coverage_by_season'] = {int(k): [int(v.n), round(float(v.wind_cov), 3)] for k, v in gc.iterrows()}
R['coverage']['games_total'] = int(len(g)); R['coverage']['outdoor_games'] = int(g.outdoor.sum())
R['coverage']['outdoor_with_wind'] = int(g.weather_ok.sum()); R['coverage']['indoor_games'] = int(g.indoor.sum())
R['coverage']['open_roof_games_excluded'] = int((g.roof == 'open').sum())
R['coverage']['team_games_analysis'] = int(len(tw))
R['coverage']['wind_bin_games'] = g[g.weather_ok].assign(b=pd.cut(g.wind_clean, [-0.1, 9.5, 14.5, 19.5, 100], labels=['0-9', '10-14', '15-19', '20+'])).b.value_counts().sort_index().astype(int).to_dict()
R['coverage']['ident_src'] = tw.ident_src.value_counts().astype(int).to_dict()
R['coverage']['ident_sd_pp'] = round(float(tw.ident.std() * 100), 2)

def fit(fml, d, w=None, name=None, keep=None):
    m = pf.feols(fml, data=d, vcov={'CRV1': 'stadium_id'}, weights=w)
    tb = m.tidy()
    out = {k: [float(tb.loc[k, 'Estimate']), float(tb.loc[k, 'Std. Error']), float(tb.loc[k, 'Pr(>|t|)'])] for k in tb.index if keep is None or k in keep}
    R['models'][name] = dict(n=int(m._N), coefs=out)
    return out

ctrl = 'temp + precip + snow'
outcomes = [('epa_pass', 'dropbacks'), ('comp_rate', 'patt'), ('air', 'patt'), ('epa_rush', None), ('expl_rate', 'plays'),
            ('to', None), ('points', None), ('fg_rate', 'fga'), ('fg40_rate', 'fg40'), ('xp_rate', 'xpa')]
for y, w in outcomes:
    d = tw.dropna(subset=[y])
    if w: d = d[d[w] > 0]
    fit(f'{y} ~ w10 + w_x_ident + {ctrl} | off_ts + def_ts', d, w, f'cont|{y}', keep=['w10', 'w_x_ident'])
    # tercile interaction: wind slope for each identity group
    d = d.dropna(subset=['ident_terc']).copy()
    for lab in ['run-heavy', 'balanced', 'pass-heavy']:
        d[f'w_{lab}'] = d.w10 * (d.ident_terc == lab)
    fit(f'{y} ~ Q("w_run-heavy") + w_balanced + Q("w_pass-heavy") + {ctrl} | off_ts + def_ts', d, w, f'terc|{y}')

# robustness: identity from PROE (2006+), and all games with indoor reference
t['ident_proe'] = np.nan
tt = t.sort_values(['team', 'gameday']).copy()
tt['pw'] = tt.neutral_proe * tt.neutral_plays
gp = tt.groupby(['team', 'season'])
tt['cum_pw'] = gp.pw.cumsum() - tt.pw
tt['ident_proe'] = np.where(tt.n_prior_games >= 3, tt.cum_pw / tt.cum_n.replace(0, np.nan), np.nan) / 100.0
tt['w_x_proe'] = tt.w10 * tt.ident_proe * 10
d = tt[tt.weather_ok & tt.ident_proe.notna() & (tt.dropbacks > 0) & (tt.plays >= 30)]
fit(f'epa_pass ~ w10 + w_x_proe + {ctrl} | off_ts + def_ts', d, 'dropbacks', 'robust_proe|epa_pass', keep=['w10', 'w_x_proe'])
ta = t[(t.weather_ok | t.indoor) & t.ident.notna() & (t.plays >= 30) & (t.dropbacks > 0)].copy()
ta['w10'] = ta.w10.fillna(0); ta['w_x_ident'] = ta.w10 * ta.ident10; ta['indoor_f'] = ta.indoor.astype(float)
ta['temp_f'] = ta.temp.fillna(70)
fit('epa_pass ~ w10 + w_x_ident + indoor_f + temp_f + precip + snow | off_ts + def_ts', ta, 'dropbacks', 'robust_indoor_ref|epa_pass', keep=['w10', 'w_x_ident', 'indoor_f'])

# ---------------- descriptive wind-bin table (raw) ----------------
wb = tw.dropna(subset=['wind_bin', 'ident_terc']).groupby(['wind_bin', 'ident_terc'], observed=True).apply(
    lambda d: pd.Series({'team_games': len(d), 'epa_pass': np.average(d.epa_pass.fillna(0), weights=d.dropbacks.clip(lower=1)),
                         'comp_rate': d.comp.sum() / d.patt.sum(), 'points': d.points.mean()})).reset_index()
wb.to_csv(f'{OUT}/wind_bins.csv', index=False)

# ---------------- field goals, play level ----------------
fg = []
for yr in range(1999, 2026):
    p = pd.read_parquet(f'{S}/nfl/pbp/{yr}.parquet', columns=['game_id', 'season', 'field_goal_attempt', 'field_goal_result', 'kick_distance', 'kicker_player_id'])
    p = p[p.field_goal_attempt == 1]
    fg.append(p)
fg = pd.concat(fg).merge(gw, on='game_id')
fg['made'] = (fg.field_goal_result == 'made').astype(float)
fg = fg[fg.kick_distance.between(18, 70)].copy()
fg['dist_c'] = fg.kick_distance - 40; fg['dist2'] = fg.dist_c ** 2
fg['k_s'] = fg.kicker_player_id.astype(str) + '_' + fg.season.astype(str)
fg['wind_bin'] = pd.cut(fg.wind_clean, [-0.1, 9.5, 14.5, 19.5, 100], labels=['0-9', '10-14', '15-19', '20+'])
fgo = fg[fg.weather_ok].copy(); fgo['w10'] = fgo.wind_clean / 10; fgo['w_x_long'] = fgo.w10 * (fgo.kick_distance >= 40)
fit(f'made ~ w10 + w_x_long + dist_c + dist2 + temp + precip + snow | k_s', fgo, None, 'fg_play|made', keep=['w10', 'w_x_long', 'temp', 'precip'])
fgb = fgo.dropna(subset=['wind_bin']).copy()
for b in ['10-14', '15-19', '20+']:
    fgb[f'b_{b}'] = (fgb.wind_bin == b).astype(float)
fit('made ~ Q("b_10-14") + Q("b_15-19") + Q("b_20+") + dist_c + dist2 + temp + precip + snow | k_s', fgb, None, 'fg_play_bins|made')
fgd = fgo.assign(long=fgo.kick_distance >= 40).groupby(['wind_bin', 'long'], observed=True).agg(n=('made', 'size'), pct=('made', 'mean')).reset_index()
fgd.to_csv(f'{OUT}/fg_by_wind.csv', index=False)
R['coverage']['fg_attempts_outdoor'] = int(len(fgo))

# ---------------- market: totals and spreads ----------------
gg = g[g.weather_ok & g.total_line.notna()].copy()
idt = t[['game_id', 'team', 'ident']]
gg = gg.merge(idt.rename(columns={'team': 'home_team', 'ident': 'h_ident'}), on=['game_id', 'home_team'], how='left')
gg = gg.merge(idt.rename(columns={'team': 'away_team', 'ident': 'a_ident'}), on=['game_id', 'away_team'], how='left')
gg = gg.dropna(subset=['h_ident', 'a_ident'])
gg['w10'] = gg.wind_clean / 10
gg['sum_ident10'] = (gg.h_ident + gg.a_ident) * 10
gg['diff_ident10'] = (gg.h_ident - gg.a_ident) * 10
gg['w_x_sum'] = gg.w10 * gg.sum_ident10; gg['w_x_diff'] = gg.w10 * gg.diff_ident10
gg['yr'] = gg.season.astype(str)
gg['under'] = np.where(gg.over_margin < 0, 1.0, np.where(gg.over_margin > 0, 0.0, np.nan))
fit('total ~ w10 + w_x_sum + sum_ident10 + temp + precip + snow | yr', gg, None, 'game|total_points', keep=['w10', 'w_x_sum'])
fit('over_margin ~ w10 + w_x_sum + sum_ident10 + temp + precip + snow | yr', gg, None, 'market|over_margin', keep=['w10', 'w_x_sum', 'temp', 'precip'])
fit('home_ats ~ w10 + w_x_diff + diff_ident10 + temp + precip + snow | yr', gg.dropna(subset=['home_ats']), None, 'market|home_ats', keep=['w10', 'w_x_diff'])
gg['wind_bin'] = pd.cut(gg.wind_clean, [-0.1, 9.5, 14.5, 19.5, 100], labels=['0-9', '10-14', '15-19', '20+'])
rng = np.random.default_rng(3)
mk = []
for b, d in gg.groupby('wind_bin', observed=True):
    u = d.under.dropna().to_numpy()
    bs = [rng.choice(u, len(u)).mean() for _ in range(2000)]
    mk.append(dict(bin=str(b), games=int(len(d)), avg_total_line=float(d.total_line.mean()), avg_total=float(d.total.mean()),
                   avg_over_margin=float(d.over_margin.mean()), under_rate=float(u.mean()), under_lo=float(np.percentile(bs, 2.5)), under_hi=float(np.percentile(bs, 97.5)), graded=int(len(u))))
R['market_bins'] = mk
# does the market move the total with wind? (line vs wind)
fit('total_line ~ w10 + temp + precip + snow | yr', gg, None, 'market|total_line_on_wind', keep=['w10', 'temp', 'precip', 'snow'])

R['coverage']['market_games'] = int(len(gg))
# stability across eras (a crude out-of-sample check: same model, separate periods)
R['eras'] = []
for lab, d in [('1999-2009', gg[gg.season <= 2009]), ('2010-2017', gg[gg.season.between(2010, 2017)]), ('2018-2025', gg[gg.season >= 2018])]:
    a = pf.feols('over_margin ~ w10 + temp + precip + snow | yr', data=d, vcov={'CRV1': 'stadium_id'}).tidy()
    b = pf.feols('total_line ~ w10 + temp + precip + snow | yr', data=d, vcov={'CRV1': 'stadium_id'}).tidy()
    hi = d[d.wind_clean >= 15].under.dropna()
    R['eras'].append(dict(era=lab, games=int(len(d)), over_b=float(a.loc['w10', 'Estimate']), over_se=float(a.loc['w10', 'Std. Error']),
                          line_b=float(b.loc['w10', 'Estimate']), line_se=float(b.loc['w10', 'Std. Error']),
                          under15=float(hi.mean()), n15=int(len(hi))))
json.dump(R, open(f'{OUT}/results.json', 'w'), indent=1)
tw.drop(columns=['np_w', 'cum_np', 'cum_n']).to_csv(f'{OUT}/dataset_team_games.csv.gz', index=False)
gg.to_csv(f'{OUT}/dataset_games.csv.gz', index=False)
fgo[['game_id', 'season', 'kicker_player_id', 'kick_distance', 'made', 'wind_clean', 'temp', 'precip', 'snow']].to_csv(f'{OUT}/fg_attempts.csv.gz', index=False)

# ---------------- features (pre-game) for the combined model ----------------
fe = g[['game_id', 'season', 'wind_clean', 'gust', 'precip', 'snow', 'temp', 'indoor', 'roof']].copy()
fe = fe.merge(idt.rename(columns={'team': 'home_team', 'ident': 'home_pass_identity'}).merge(g[['game_id', 'home_team']], on=['game_id', 'home_team'])[['game_id', 'home_pass_identity']], on='game_id', how='left')
fe = fe.merge(idt.rename(columns={'team': 'away_team', 'ident': 'away_pass_identity'}).merge(g[['game_id', 'away_team']], on=['game_id', 'away_team'])[['game_id', 'away_pass_identity']], on='game_id', how='left')
fe['wind'] = np.where(fe.indoor, 0.0, fe.wind_clean)
fe['wind_x_home_ident'] = fe.wind * fe.home_pass_identity
fe['wind_x_away_ident'] = fe.wind * fe.away_pass_identity
fe['wind_x_sum_ident'] = fe.wind * (fe.home_pass_identity + fe.away_pass_identity)
fe['sport'] = 'NFL'
fe['weather_note'] = 'game-time stadium-reported weather; pre-game value would be a forecast'
fe = fe[['sport', 'game_id', 'season', 'wind', 'gust', 'precip', 'snow', 'temp', 'indoor', 'home_pass_identity', 'away_pass_identity',
         'wind_x_home_ident', 'wind_x_away_ident', 'wind_x_sum_ident', 'weather_note']]
fe.to_parquet(sys.argv[3])
print('done', len(tw), len(gg), len(fgo))
