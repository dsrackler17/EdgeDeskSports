"""Phase 1 — NFL shared research layer (nflverse).

Outputs (to OUT dir):
  nfl_games.parquet       one row per game: result, market lines, rest, roof, surface, weather
                          (numeric + parsed text), referee, stadium geo, travel/tz for the visitor
  nfl_team_games.parquet  one row per team-game: offense/defense box from play-by-play,
                          quarter/half splits, workload, kicking, penalties

Sources: nflverse games.csv (schedules, lines, rest, roof, temp, wind, referee),
nflverse play-by-play 1999-2025, stadium_geo.csv (Wikipedia coords + USGS elevation).
Market line: nflverse `spread_line` / `total_line` (home-positive spread). nflverse does not
document capture time; it is treated as a near-close consensus line, not a licensed close.
"""
import sys, re, numpy as np, pandas as pd

N, OUT = sys.argv[1], sys.argv[2]
g = pd.read_csv(f'{N}/games.csv')
g = g[(g.season <= 2025) & g.result.notna()].copy()
geo = pd.read_csv(f'{N}/stadium_geo.csv')
for c in ['lat', 'lon', 'elev_ft']:
    geo[c] = pd.to_numeric(geo[c], errors='coerce')

# team home stadium per season = modal stadium of its non-neutral home games
home = g[g.location == 'Home'].groupby(['season', 'home_team']).stadium_id.agg(lambda s: s.mode().iloc[0]).rename('home_stad').reset_index()
g = g.merge(home.rename(columns={'home_team': 'away_team', 'home_stad': 'away_home_stad'}), on=['season', 'away_team'], how='left')
g = g.merge(home.rename(columns={'home_stad': 'home_home_stad'}), on=['season', 'home_team'], how='left')
G = geo.set_index('stadium_id')
def gcol(ids, col): return ids.map(G[col])
g['v_lat'], g['v_lon'], g['v_elev'], g['v_tz'] = [gcol(g.stadium_id, c) for c in ['lat', 'lon', 'elev_ft', 'tz']]
g['a_lat'], g['a_lon'], g['a_elev'], g['a_tz'] = [gcol(g.away_home_stad, c) for c in ['lat', 'lon', 'elev_ft', 'tz']]
g['h_lat'], g['h_lon'], g['h_elev'], g['h_tz'] = [gcol(g.home_home_stad, c) for c in ['lat', 'lon', 'elev_ft', 'tz']]

def hav(la1, lo1, la2, lo2):
    la1, lo1, la2, lo2 = map(np.radians, [la1, lo1, la2, lo2])
    a = np.sin((la2 - la1) / 2) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((lo2 - lo1) / 2) ** 2
    return 2 * 3958.8 * np.arcsin(np.sqrt(a))
g['away_travel_mi'] = hav(g.a_lat, g.a_lon, g.v_lat, g.v_lon)
g['home_travel_mi'] = hav(g.h_lat, g.h_lon, g.v_lat, g.v_lon)

# UTC offsets on the actual game date (DST-aware) for venue and each team's home
from zoneinfo import ZoneInfo
import datetime as dt
def off(tz, day):
    try:
        return ZoneInfo(tz).utcoffset(dt.datetime.combine(day, dt.time(12))).total_seconds() / 3600
    except Exception:
        return np.nan
g['gameday'] = pd.to_datetime(g.gameday)
days = g.gameday.dt.date
g['v_off'] = [off(t, d) if isinstance(t, str) else np.nan for t, d in zip(g.v_tz, days)]
g['a_off'] = [off(t, d) if isinstance(t, str) else np.nan for t, d in zip(g.a_tz, days)]
g['h_off'] = [off(t, d) if isinstance(t, str) else np.nan for t, d in zip(g.h_tz, days)]
g['away_tz_shift'] = g.v_off - g.a_off       # + = visitor travelled EAST (clock moves forward)
g['home_tz_shift'] = g.v_off - g.h_off       # nonzero only for neutral/international games
# kickoff: nflverse gametime is US/Eastern local
et = ZoneInfo('America/New_York')
def ko_utc(day, t):
    try:
        hh, mm = map(int, str(t).split(':'))
        return dt.datetime.combine(day, dt.time(hh, mm), tzinfo=et).astimezone(dt.timezone.utc)
    except Exception:
        return None
g['ko_utc'] = [ko_utc(d, t) for d, t in zip(days, g.gametime)]
ko_h = np.array([np.nan if k is None else k.hour + k.minute / 60 for k in g.ko_utc])
g['ko_venue_local'] = (ko_h + g.v_off) % 24
g['ko_away_body'] = (ko_h + g.a_off) % 24      # kickoff on the visitor's home clock
g['ko_home_body'] = (ko_h + g.h_off) % 24
g['ko_et'] = g.gametime.str.slice(0, 2).astype(float) + g.gametime.str.slice(3, 5).astype(float) / 60

# ---------- weather text (nflverse pbp `weather`, game-level) ----------
wx = []
for y in range(1999, 2026):
    p = pd.read_parquet(f'{N}/pbp/{y}.parquet', columns=['game_id', 'weather'])
    wx.append(p.dropna().drop_duplicates('game_id'))
wx = pd.concat(wx)
def parse(s):
    s = str(s)
    hum = re.search(r'Humidity:\s*(\d+)\s*%', s)
    wd = re.search(r'Wind:\s*([A-Za-z]+)\s*\d', s)
    pre = s.split('Temp:')[0].lower()
    precip = bool(re.search(r'\b(rain|showers?|snow|sleet|drizzle|flurr|storm|wet)', pre)) and not re.search(r'chance|possible|\d+%', pre)
    snow = bool(re.search(r'\b(snow|flurr|sleet)', pre)) and not re.search(r'chance|possible', pre)
    gust = re.search(r'gusts? (?:to|of|up to)?\s*(\d+)', s.lower())
    return (float(hum.group(1)) if hum else np.nan, wd.group(1).upper() if wd else None, precip, snow,
            float(gust.group(1)) if gust else np.nan)
P = wx.weather.map(parse)
wx['humidity'] = [x[0] for x in P]; wx['wind_dir'] = [x[1] for x in P]
wx['precip'] = [x[2] for x in P]; wx['snow'] = [x[3] for x in P]; wx['gust'] = [x[4] for x in P]
g = g.merge(wx.rename(columns={'weather': 'weather_text'}), on='game_id', how='left')
g['indoor'] = g.roof.isin(['dome', 'closed'])
g.loc[g.indoor, ['wind', 'precip', 'snow', 'gust']] = [0, False, False, np.nan]

# ---------- team-game box from play-by-play ----------
cols = ['game_id', 'season', 'week', 'posteam', 'defteam', 'home_team', 'away_team', 'qtr', 'play_type', 'down',
        'ydstogo', 'yards_gained', 'epa', 'success', 'pass', 'rush', 'qb_dropback', 'xpass', 'pass_oe',
        'interception', 'fumble_lost', 'penalty', 'penalty_team', 'penalty_yards', 'field_goal_attempt',
        'field_goal_result', 'kick_distance', 'extra_point_attempt', 'extra_point_result', 'drive', 'fixed_drive',
        'drive_play_count', 'drive_time_of_possession', 'game_seconds_remaining', 'half_seconds_remaining',
        'no_huddle', 'third_down_converted', 'third_down_failed', 'touchdown', 'sack', 'qb_kneel', 'qb_spike',
        'wp', 'score_differential', 'air_yards', 'complete_pass', 'pass_attempt', 'rush_attempt']
rows = []
for y in range(1999, 2026):
    import pyarrow.parquet as pq
    avail = set(pq.read_schema(f'{N}/pbp/{y}.parquet').names)
    p = pd.read_parquet(f'{N}/pbp/{y}.parquet', columns=[c for c in cols if c in avail])
    for c in cols:
        if c not in p.columns:
            p[c] = np.nan
    p = p[p.posteam.notna()]
    # nflverse pbp uses CURRENT franchise codes (LV, LAC, LA) in every season while games.csv uses the
    # code of that season (OAK, SD, STL). Map pbp codes to the schedule's codes by home/away role.
    sch = g[['game_id', 'home_team', 'away_team']].rename(columns={'home_team': 'sh', 'away_team': 'sa'})
    p = p.merge(sch, on='game_id', how='left')
    for col in ['posteam', 'defteam', 'penalty_team']:
        p[col] = np.where(p[col] == p.home_team, p.sh, np.where(p[col] == p.away_team, p.sa, p[col]))
    p['home_team'], p['away_team'] = p.sh, p.sa
    p = p.drop(columns=['sh', 'sa'])
    sc =p.play_type.isin(['pass', 'run']) & (p.qb_kneel.fillna(0) == 0) & (p.qb_spike.fillna(0) == 0)
    p['sc'] = sc
    p['h1'] = p.qtr <= 2; p['h2'] = p.qtr.isin([3, 4]); p['q4'] = p.qtr == 4
    p['expl'] = sc & (((p.play_type == 'run') & (p.yards_gained >= 10)) | ((p.play_type == 'pass') & (p.yards_gained >= 20)))
    p['d3'] = sc & (p.down == 3); p['d3c'] = p.d3 & (p.third_down_converted == 1)
    p['to'] = (p.interception.fillna(0) + p.fumble_lost.fillna(0)) > 0
    p['neutral'] = sc & p.wp.between(0.2, 0.8) & p.qtr.le(3)   # neutral game state for pass-rate identity
    p['dropback'] = p.qb_dropback.fillna(0) == 1
    p['fga'] = p.field_goal_attempt.fillna(0) == 1
    p['fgm'] = p.fga & (p.field_goal_result == 'made')
    p['fg40'] = p.fga & (p.kick_distance >= 40); p['fg40m'] = p.fg40 & p.fgm
    p['xpa'] = p.extra_point_attempt.fillna(0) == 1; p['xpm'] = p.xpa & (p.extra_point_result == 'good')
    p['comp'] = p.complete_pass.fillna(0) == 1; p['patt'] = (p.pass_attempt.fillna(0) == 1) & sc & (p.sack.fillna(0) == 0)
    p['air'] = np.where(p.patt, p.air_yards, np.nan)
    p['epa_sc'] = np.where(sc, p.epa, np.nan)
    p['epa_pass'] = np.where(sc & p.dropback, p.epa, np.nan); p['epa_rush'] = np.where(sc & ~p.dropback, p.epa, np.nan)
    for half in ['h1', 'h2', 'q4']:
        p[f'epa_{half}'] = np.where(sc & p[half], p.epa, np.nan)
        p[f'succ_{half}'] = np.where(sc & p[half], p.success, np.nan)
        p[f'sc_{half}'] = sc & p[half]
        p[f'expl_{half}'] = p.expl & p[half]
    p['succ'] = np.where(sc, p.success, np.nan)
    p['nh'] = sc & (p.no_huddle.fillna(0) == 1)
    agg = p.groupby(['game_id', 'posteam']).agg(
        season=('season', 'first'), week=('week', 'first'), opp=('defteam', 'first'),
        plays=('sc', 'sum'), plays_h1=('sc_h1', 'sum'), plays_h2=('sc_h2', 'sum'), plays_q4=('sc_q4', 'sum'),
        epa=('epa_sc', 'mean'), epa_h1=('epa_h1', 'mean'), epa_h2=('epa_h2', 'mean'), epa_q4=('epa_q4', 'mean'),
        succ=('succ', 'mean'), succ_h1=('succ_h1', 'mean'), succ_h2=('succ_h2', 'mean'), succ_q4=('succ_q4', 'mean'),
        epa_pass=('epa_pass', 'mean'), epa_rush=('epa_rush', 'mean'),
        dropbacks=('dropback', 'sum'), neutral_plays=('neutral', 'sum'),
        expl=('expl', 'sum'), expl_h1=('expl_h1', 'sum'), expl_h2=('expl_h2', 'sum'), expl_q4=('expl_q4', 'sum'),
        d3=('d3', 'sum'), d3c=('d3c', 'sum'), to=('to', 'sum'),
        fga=('fga', 'sum'), fgm=('fgm', 'sum'), fg40=('fg40', 'sum'), fg40m=('fg40m', 'sum'), xpa=('xpa', 'sum'), xpm=('xpm', 'sum'),
        comp=('comp', 'sum'), patt=('patt', 'sum'), air=('air', 'mean'), nh=('nh', 'sum'),
        drives=('fixed_drive', 'nunique')).reset_index().rename(columns={'posteam': 'team'})
    # neutral-state pass rate
    nz = p[p.neutral].groupby(['game_id', 'posteam']).agg(neutral_pass=('dropback', 'mean'), neutral_proe=('pass_oe', 'mean')).reset_index().rename(columns={'posteam': 'team'})
    agg = agg.merge(nz, on=['game_id', 'team'], how='left')
    # penalties committed (accepted, attributed by penalty_team)
    pen = p[(p.penalty.fillna(0) == 1) & p.penalty_team.notna()]
    pen = pen.assign(h2=pen.qtr >= 3, off_pen=pen.penalty_team == pen.posteam)
    pg = pen.groupby(['game_id', 'penalty_team']).agg(pen=('penalty', 'size'), pen_yds=('penalty_yards', 'sum'),
            pen_h2=('h2', 'sum'), pen_off=('off_pen', 'sum')).reset_index().rename(columns={'penalty_team': 'team'})
    agg = agg.merge(pg, on=['game_id', 'team'], how='left')
    # time of possession / longest drives (defensive workload proxies for the opponent)
    dr = p[p.sc].groupby(['game_id', 'posteam', 'fixed_drive']).agg(n=('sc', 'size'), h1=('h1', 'first')).reset_index()
    dl = dr.groupby(['game_id', 'posteam']).agg(drives_10plus=('n', lambda s: (s >= 10).sum()),
            drives_10plus_h1=('n', lambda s: 0)).reset_index().rename(columns={'posteam': 'team'})
    dl['drives_10plus_h1'] = dr[dr.h1].groupby(['game_id', 'posteam']).n.apply(lambda s: (s >= 10).sum()).reindex(
        pd.MultiIndex.from_frame(dl[['game_id', 'team']])).fillna(0).to_numpy()
    agg = agg.merge(dl, on=['game_id', 'team'], how='left')
    rows.append(agg)
    print(y, len(agg), flush=True)
tg = pd.concat(rows, ignore_index=True)
for c in ['pen', 'pen_yds', 'pen_h2', 'pen_off']:
    tg[c] = tg[c].fillna(0)

# quarter scores from pbp cumulative score
qs = []
for y in range(1999, 2026):
    p = pd.read_parquet(f'{N}/pbp/{y}.parquet', columns=['game_id', 'qtr', 'total_home_score', 'total_away_score'])
    q = p.groupby(['game_id', 'qtr'])[['total_home_score', 'total_away_score']].max().unstack('qtr')
    out = pd.DataFrame(index=q.index)
    for k in [1, 2, 3, 4]:
        out[f'h_cum{k}'] = q['total_home_score'].get(k); out[f'a_cum{k}'] = q['total_away_score'].get(k)
    out[['h_cum1', 'h_cum2', 'h_cum3', 'h_cum4', 'a_cum1', 'a_cum2', 'a_cum3', 'a_cum4']] = \
        out[['h_cum1', 'h_cum2', 'h_cum3', 'h_cum4', 'a_cum1', 'a_cum2', 'a_cum3', 'a_cum4']].ffill(axis=1)
    qs.append(out.reset_index())
qs = pd.concat(qs)
g = g.merge(qs, on='game_id', how='left')
g['home_margin_h2'] = (g.home_score - g.away_score) - (g.h_cum2 - g.a_cum2)
g['home_margin_q4'] = (g.h_cum4 - g.a_cum4) - (g.h_cum3 - g.a_cum3)
g['home_margin_h1'] = g.h_cum2 - g.a_cum2
g['home_ats'] = g.result - g.spread_line          # >0 home covered
g['over_margin'] = g.total - g.total_line          # >0 over

g.drop(columns=['ko_utc']).to_parquet(f'{OUT}/nfl_games.parquet')
tg.to_parquet(f'{OUT}/nfl_team_games.parquet')
print(g.shape, tg.shape)
print('geo coverage', g.v_lat.notna().mean().round(3), g.a_lat.notna().mean().round(3))
